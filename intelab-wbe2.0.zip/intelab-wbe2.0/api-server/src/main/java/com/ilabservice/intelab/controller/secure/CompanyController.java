package com.ilabservice.intelab.controller.secure;

import java.util.List;

import com.ilabservice.intelab.check.ParametersAndPermissionsCheck;
import com.ilabservice.intelab.model.*;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.storage.FileUploadService;
import com.ilabservice.intelab.vo.assemblyvo.CompanyVoMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.common.TableResultResponse;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.security.auth.JwtAuthenticationToken;
import com.ilabservice.intelab.security.model.UserContext;
import com.ilabservice.intelab.service.CompanyService;
import com.ilabservice.intelab.service.UserService;
import com.ilabservice.intelab.vo.CompanyContractVo;
import com.ilabservice.intelab.vo.CompanyVo;

/**
 * This controller handles the APIs about company object for authorized client
 * /company
 */
@RestController("secureCompanyController")
@RequestMapping(value = "/api/secure")
public class CompanyController {
    private static Logger logger = LoggerFactory.getLogger(CompanyController.class);
    @Autowired
    CompanyService companyService;
    @Autowired
    UserService userService;
    @Autowired
    UserMapper userMapper;
    @Autowired
    UserRolesMapper userRolesMapper;
    @Autowired
	ParametersAndPermissionsCheck parametersAndPermissionsCheck;
	@Autowired
	FileUploadService fileUploadService;
    @RequestMapping(value="customer/company", method = RequestMethod.GET)
    public RestObject getLoginUserCompanyAndExtraFeatures(JwtAuthenticationToken token){

    	try {
			UserContext context = (UserContext) token.getPrincipal();
			userChecks(context.getId());
        	User user=userService.selectById(context.getId());
        	if(user==null) {
        		throw new UserException(null,ResultErrorCode.USER_NOT_EXIST.getValue(),ResultErrorCode.USER_NOT_EXIST.getCode());
        	}
        	Company company=companyService.selectCompanyAndExtraFeatureById(user.getCompanyId());
        	if(company==null) {
        		throw new UserException(null,ResultErrorCode.COMPANY_NOT_EXIST.getValue(),ResultErrorCode.COMPANY_NOT_EXIST.getCode());
        	}
        	return new RestObject(CompanyVoMapper.getLoginUserCompanyAndExtraFeatures(company),ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
			
		} catch (Exception e) {
			// TODO: handle exception
			throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),e.getMessage(),e.getStackTrace());
		}
    }
    @RequestMapping(value="/admin/company",method=RequestMethod.GET)
    public TableResultResponse<CompanyVo> getAdminCompanyPage(JwtAuthenticationToken token,@RequestParam(value = "limit", required = false,defaultValue = "10") Integer limit,
            @RequestParam(value = "offset", required = false,defaultValue = "0") Integer offset){
    	UserContext context = (UserContext) token.getPrincipal();
    	checks(context.getId());
    	try {
    		 List<Company> companies=companyService.getAdminCompanysPage(limit, offset);
        	 if(companies==null) {
        		 throw new UserException(null,ResultErrorCode.COMPANY_NOT_EXIST.getValue(),ResultErrorCode.COMPANY_NOT_EXIST.getCode());
        	 }
        	 Integer tal=companyService.findCompanyCount();
        	 if(tal==null) {
        		 throw new UserException(null,ResultErrorCode.COMPANY_NOT_EXIST.getValue(),ResultErrorCode.COMPANY_NOT_EXIST.getCode());
        	 }
             return new TableResultResponse<>(tal, CompanyVoMapper.getAdminCompany(companies));
		} catch (Exception e) {
			throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),e.getMessage(),e.getStackTrace());
		}
    }
    @RequestMapping(value="/admin/company",method=RequestMethod.POST)
    public RestObject createCompanyInfo(JwtAuthenticationToken token,@RequestParam(value = "campusImage") MultipartFile file,@RequestParam(value = "extraFeasture[]") List<Integer> featureIdList,CompanyExtend companyExtend) {
    	UserContext context = (UserContext) token.getPrincipal();
		checks(context.getId());
        try {
        	if(companyExtend==null) {
        		throw new UserException(null,ResultErrorCode.DATA_NOT_FOUND.getValue(),ResultErrorCode.DATA_NOT_FOUND.getCode());
        	}
        	Company company=companyService.createCompanyInfo(file,featureIdList, companyExtend);
        	if(company==null) {
        		throw new UserException(null,ResultErrorCode.COMPANY_NOT_EXIST.getValue(),ResultErrorCode.COMPANY_NOT_EXIST.getCode());
        	}
        	return new RestObject(CompanyVoMapper.getLoginUserCompanyAndExtraFeatures(company));
		} catch (Exception e) {
			throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),e.getMessage(),e.getStackTrace());
		}
    	
    }
    @RequestMapping(value="/admin/company/{id}",method=RequestMethod.PUT)
    public RestObject updateCompanyInfo(JwtAuthenticationToken token,@PathVariable("id") Integer id,CompanyExtend companyExtend,@RequestParam(value = "campusImage")MultipartFile file) {
    	UserContext context=(UserContext) token.getPrincipal();
		checks(context.getId());
    	try {
    		if(companyExtend==null) {
        		throw new UserException(null,ResultErrorCode.DATA_NOT_FOUND.getValue(),ResultErrorCode.DATA_NOT_FOUND.getCode());
        	}
    		Company company=companyService.updateCompanyInfo(file, companyExtend,id);
    		if(company==null) {
        		throw new UserException(null,ResultErrorCode.COMPANY_NOT_EXIST.getValue(),ResultErrorCode.COMPANY_NOT_EXIST.getCode());
        	}
        	
        	return new RestObject(CompanyVoMapper.getLoginUserCompanyAndExtraFeatures(company),ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
		} catch (Exception e) {
			throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),e.getMessage(),e.getStackTrace());
		}

    }
    @RequestMapping(value="/admin/company/{id}/contract",method=RequestMethod.GET)
    public RestObject findListCompanyContractByCompanyId(JwtAuthenticationToken token,@PathVariable Integer id){
    	UserContext context=(UserContext) token.getPrincipal();
		checks(context.getId());
    	try {
			List<CompanyContract> companyContracts=companyService.findListCompanyContractByCompanyId(id);
			if(companyContracts==null) {
				throw new UserException(null,ResultErrorCode.COMPANYCONTRACT_NOT_EXIST.getValue(),ResultErrorCode.COMPANYCONTRACT_NOT_EXIST.getCode());
			}
			return new RestObject(CompanyVoMapper.findCompanyContractByCompanyId(companyContracts),ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
		} catch (Exception e) {
			throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),e.getMessage(),e.getStackTrace());
		}
    	
    
    }
    @RequestMapping(value="/admin/company/{id}/contract",method=RequestMethod.POST)
    public RestObject addCompanyContract(JwtAuthenticationToken token,@PathVariable("id") Integer companyId,@RequestBody CompanyContractExtend companyContractExtend){
    	UserContext context=(UserContext) token.getPrincipal();
		checks(context.getId());
    	try {
    		    if(companyContractExtend==null) {
    		    	throw new UserException(null,ResultErrorCode.DATA_NOT_FOUND.getValue(),ResultErrorCode.DATA_NOT_FOUND.getCode());
    		    }
    		    CompanyContract companyContract=companyService.addCompanyContract(companyContractExtend,companyId);
    			if(companyContract==null) {
    				throw new UserException(null,ResultErrorCode.COMPANYCONTRACT_NOT_EXIST.getValue(),ResultErrorCode.COMPANYCONTRACT_NOT_EXIST.getCode());
    			}
    			return new RestObject(CompanyVoMapper.addCompanyContract(companyContract),ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
			} catch (Exception e) {
				throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());
			}
    }
    
    @RequestMapping(value="/admin/company/{companyId}/contract/{contractId}",method = RequestMethod.PUT)
    public RestObject updateCompanyContract(JwtAuthenticationToken token,@PathVariable("companyId") Integer companyId,@PathVariable("contractId") Integer contractId,@RequestBody CompanyContractExtend companyContractExtend) {
    	UserContext context=(UserContext) token.getPrincipal();
		checks(context.getId());
    	
    	try {
    		if(companyContractExtend==null) {
    			throw new UserException(null,ResultErrorCode.DATA_NOT_FOUND.getValue(),ResultErrorCode.DATA_NOT_FOUND.getCode());
    		}
			if(!companyService.updateCompanyContract(companyContractExtend,contractId)) {
				throw new UserException(null,ResultErrorCode.COMPANYCONTRACT_UPDATE_ERROR.getValue(),ResultErrorCode.COMPANYCONTRACT_UPDATE_ERROR.getCode());
			}
			return new RestObject(null,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
		} catch (Exception e) {
			throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());
		}
    }
    @RequestMapping(value="/admin/company/{id}/logo",method=RequestMethod.POST)
    public RestObject createCompanyLogo(JwtAuthenticationToken token,@PathVariable("id") Integer id,@RequestParam(value="logo") MultipartFile file){
    	UserContext context=(UserContext) token.getPrincipal();
		checks(context.getId());
    	try {
    		Company company=companyService.getCompanyById(id);
			if(company==null) {
				throw new UserException(null,ResultErrorCode.COMPANY_NOT_EXIST.getValue(),ResultErrorCode.COMPANY_NOT_EXIST.getCode());
			}
			String url =fileUploadService.uploadFile(file, "company" + id.toString(),
					"building/" + file.getName(), null);
            company.setLoginUrl(url);
            companyService.updateCompany(company);
        	return new RestObject(url,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
		} catch (Exception e) {
			throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),e.getMessage(),e.getStackTrace());
		}
    	
    }
    
    @RequestMapping(value="/admin/company/{id}/logo",method=RequestMethod.PUT)
    public RestObject updateCompanyLogo(JwtAuthenticationToken token,@PathVariable("id") Integer id,@RequestParam(value="logo") MultipartFile file) {
    	UserContext context=(UserContext) token.getPrincipal();
		checks(context.getId());
    	
    	try {
            Company company=companyService.getCompanyById(id);
			if(company==null) {
				throw new UserException(null,ResultErrorCode.COMPANY_NOT_EXIST.getValue(),ResultErrorCode.COMPANY_NOT_EXIST.getCode());
			}
			String url =fileUploadService.uploadFile(file, "company" + id.toString(),
					"building/" + file.getName(), company.getLoginUrl());
			company.setLoginUrl(url);
			companyService.updateCompany(company);
			return new RestObject(url,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
		} catch (Exception e) {
			throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),e.getMessage(),e.getStackTrace());
		}
    }
    private void userChecks(Integer id) {
        User user = userMapper.getUserById(id);
        List<Role> roleList = userRolesMapper.getLoginRoleIdByLoginUserId(user.getId());
        parametersAndPermissionsCheck.userCheck(ResultErrorCode.FILL_PARAMETERS.getCode(), roleList);
    }
    private void checks(Integer id) {
        User user = userMapper.getUserById(id);
        List<Role> roleList = userRolesMapper.getLoginRoleIdByLoginUserId(user.getId());
        parametersAndPermissionsCheck.adminCheck(ResultErrorCode.FILL_PARAMETERS.getCode(), roleList);
    }

}
