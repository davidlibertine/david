package com.ilabservice.intelab.controller.secure;

import com.ilabservice.intelab.check.ParametersAndPermissionsCheck;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.User;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.security.auth.JwtAuthenticationToken;
import com.ilabservice.intelab.security.model.UserContext;
import com.ilabservice.intelab.service.RoleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;


@RestController
@RequestMapping("/api/secure/")
public class RoleController {

    private static Logger logger = LoggerFactory.getLogger(RoleController.class);

    @Resource
    private RoleService roleService;

    @Resource
    private UserMapper userMapper;

    @Resource
    private UserRolesMapper userRolesMapper;

    @Autowired
    private ParametersAndPermissionsCheck parametersAndPermissionsCheck;

    /**
     * 查询所有用户角色
     * @param token
     * @return
     */
    @RequestMapping(value = "/role", method = RequestMethod.GET)
    public RestObject getAllUserRoles(JwtAuthenticationToken token) {
        UserContext context = (UserContext) token.getPrincipal();
        adminOrUserchecks(context.getId());
        return new RestObject(roleService.getAllUserRoles(), ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
    }

    /**
     * 删除指定角色
     * @param token
     * @param id
     * @return
     */
    @RequestMapping(value = "/admin/role/{id}", method = RequestMethod.DELETE)
    public RestObject deleteRoleByRoleId(JwtAuthenticationToken token, @PathVariable("id") Integer id) {
        UserContext context = (UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            if(roleService.deleteRoleByRoleId(id)) {
                return new RestObject(null, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 更新指定角色
     * @param token
     * @param id
     * @param role
     * @return
     */
    @RequestMapping(value = "/admin/role/{id}", method = RequestMethod.PUT)
    public RestObject updateRoleByRoleId(JwtAuthenticationToken token, @PathVariable("id") Integer id, Role role) {
        UserContext context = (UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            if(roleService.updateRoleByRoleId(id, role)) {
                return new RestObject(null, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 添加角色
     * @param token
     * @param role
     * @return
     */
    @RequestMapping(value = "/admin/role", method = RequestMethod.POST)
    public RestObject addRole(JwtAuthenticationToken token, Role role) {
        UserContext context = (UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            Role newRole = roleService.addRole(role);
            if(newRole != null) {
                return new RestObject(newRole, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 从指定角色删除一到多个权限
     * @param token
     * @param roleId
     * @param permissionsIdArray
     * @return
     */
    @RequestMapping(value = "/admin/role/{roleId}/permission/delete", method = RequestMethod.PUT)
    public RestObject deleteOneOrMorePermissionsFromTheSpecifiedRole(JwtAuthenticationToken token, @PathVariable("roleId") Integer roleId, List<Integer> permissionsIdArray) {
        UserContext context = (UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            if(roleService.deleteOneOrMorePermissionsFromTheSpecifiedRole(roleId, permissionsIdArray)) {
                return new RestObject(null, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 给指定角色添加一到多个权限
     * @param token
     * @param roleId
     * @param permissionsIdArray
     * @return
     */
    @RequestMapping(value = "/admin/role/{roleId}/permission", method = RequestMethod.POST)
    public RestObject addOneToMultiplePermissionsToGivenRole(JwtAuthenticationToken token, @PathVariable("roleId") Integer roleId, List<Integer> permissionsIdArray) {
        UserContext context = (UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            if(roleService.addOneToMultiplePermissionsToGivenRole(roleId, permissionsIdArray)) {
                return new RestObject(null, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 权限校验
     * @param id
     */
    private void adminOrUserchecks(Integer id) {
        User user = userMapper.getUserById(id);
        List<Role> roleList = userRolesMapper.getLoginRoleIdByLoginUserId(user.getId());
        parametersAndPermissionsCheck.adminOrUserCheck(ResultErrorCode.FILL_PARAMETERS.getCode(), roleList);
    }
    private void checks(Integer id) {
        User user = userMapper.getUserById(id);
        List<Role> roleList = userRolesMapper.getLoginRoleIdByLoginUserId(user.getId());
        parametersAndPermissionsCheck.adminCheck(ResultErrorCode.FILL_PARAMETERS.getCode(), roleList);
    }
}
