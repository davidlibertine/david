package com.ilabservice.intelab.controller.secure;

import com.ilabservice.intelab.check.ParametersAndPermissionsCheck;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.model.ExtraFeature;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.User;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.security.auth.JwtAuthenticationToken;
import com.ilabservice.intelab.security.model.UserContext;
import com.ilabservice.intelab.service.ExtraFeatureService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-14 10:55:03
 */
@RestController
@RequestMapping("/secure/admin/company/")
public class ExtraFeatureController {

    private static Logger logger = LoggerFactory.getLogger(ExtraFeatureController.class);

    @Resource
    private ExtraFeatureService extraFeatureService;

    @Resource
    private UserMapper userMapper;

    @Resource
    private UserRolesMapper userRolesMapper;

    @Autowired
    private ParametersAndPermissionsCheck parametersAndPermissionsCheck;

    /**
     * 查询指定公司的所有附加功能
     * @param token
     * @param id
     * @return
     */
    @RequestMapping(value = "/{id}/feature", method = RequestMethod.GET)
    public RestObject queryAllAdditionalFeaturesOfGivenCompany(JwtAuthenticationToken token, @PathVariable("id") Integer id) {
        UserContext context = (UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            List<ExtraFeature> extraFeatureList = extraFeatureService.queryAllAdditionalFeaturesOfGivenCompany(id);
            if(extraFeatureList != null) {
                return new RestObject(extraFeatureList, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 为一个公司增添一到多个产品功能
     * @param token
     * @param id
     * @param featuresIdList
     * @return
     */
    @RequestMapping(value = "/{id}/feature", method = RequestMethod.POST)
    public RestObject addOneOrMoreProductFeaturesTCompany(JwtAuthenticationToken token,
                                                          @PathVariable("id") Integer id, List<Integer> featuresIdList) {
        UserContext context = (UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            if(extraFeatureService.addOneOrMoreProductFeaturesTCompany(id, featuresIdList)) {
                return new RestObject(null, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.FEATURE_NOE_FOUND.getCode(),
                    ResultErrorCode.FEATURE_NOE_FOUND.getValue(), null);
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 从一个公司删除一到多个产品功能
     * @param token
     * @param id
     * @param featuresIdList
     * @return
     */
    @RequestMapping(value = "/{id}/feature/delete", method = RequestMethod.PUT)
    public RestObject deleteOneOrMoreProductFeaturesTCompany(JwtAuthenticationToken token,
                                                             @PathVariable("id") Integer id, List<Integer> featuresIdList) {
        UserContext context = (UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            if (extraFeatureService.deleteOneOrMoreProductFeaturesTCompany(id, featuresIdList)) {
                return new RestObject(null, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.FEATURE_NOE_FOUND.getCode(),
                    ResultErrorCode.FEATURE_NOE_FOUND.getValue(), null);
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 权限校验
     * @param id
     */
    private void checks(Integer id) {
        User user = userMapper.getUserById(id);
        List<Role> roleList = userRolesMapper.getLoginRoleIdByLoginUserId(user.getId());
        parametersAndPermissionsCheck.adminCheck(ResultErrorCode.FILL_PARAMETERS.getCode(), roleList);
    }
}