package com.ilabservice.intelab.controller.secure;


import com.ilabservice.intelab.check.ParametersAndPermissionsCheck;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.model.*;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.security.auth.JwtAuthenticationToken;
import com.ilabservice.intelab.security.model.UserContext;
import com.ilabservice.intelab.service.LabDeviceService;
import com.ilabservice.intelab.storage.FileUploadService;
import com.ilabservice.intelab.vo.LabDeviceVo;
import com.ilabservice.intelab.vo.assemblyvo.LabDeviceVoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/secure/customer/")
public class LabDeviceController {

    @Resource
    private LabDeviceService labDeviceService;

    @Resource
    private UserMapper userMapper;

    @Resource
    private UserRolesMapper userRolesMapper;

    @Resource
    private ParametersAndPermissionsCheck parametersAndPermissionsCheck;
    @Autowired
    private FileUploadService fileUploadService;

    /**
     * 新建监控对象设备. 需要先在 lab_device 中新建一行, 然后对应的在monitor_target 里再建一行, 把 ref_table_id 设置为 lab_device.id
     * @param token
     * @param monitorTargetLabDevice
     * @return
     */
    @RequestMapping(value = "/monitor_target_lab_device", method = RequestMethod.POST)
    public RestObject addLabDevice(JwtAuthenticationToken token, MonitorTargetLabDevice monitorTargetLabDevice) {
        UserContext context = (UserContext) token.getPrincipal();
        userChecks(context.getId());
        if(monitorTargetLabDevice == null) {
            throw new UserException(ResultErrorCode.PARAMS_IS_NULL.getCode(), ResultErrorCode.PARAMS_IS_NULL.getValue(), null);
        }
        Map<String, Object> map = labDeviceService.addLabDevice(monitorTargetLabDevice, context.getId());
        if(map != null) {
            /**
             * 组装vo对象
             */
            LabDeviceVo labDeviceVo = LabDeviceVoMapper.getLabDeviceVo(map);
            return new RestObject(labDeviceVo, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
        }
        throw new UserException(ResultErrorCode.NOT_FOUND_PAGE_OR_URL_OR_MODEL.getCode(),
                ResultErrorCode.NOT_FOUND_PAGE_OR_URL_OR_MODEL.getValue(), null);
    }
    @RequestMapping(value = "monitor_target_lab_device",method = RequestMethod.GET)
    public RestObject getUserLabDevice(JwtAuthenticationToken token,Integer monitorTargetType,Integer locationId,LabDevice labDevice,Integer limit,Integer offset){
        UserContext context = (UserContext) token.getPrincipal();
        userChecks(context.getId());
        try {
            User user=userMapper.selectById(context.getId());
            List<LabDevice> labDevices=labDeviceService.getUserLabDevice(monitorTargetType,user.getCompanyId(),locationId,labDevice,limit,offset);
            if(labDevices==null){
                throw new UserException(null,ResultErrorCode.LABDEVICE_NOT_EXIST.getValue(),ResultErrorCode.LABDEVICE_NOT_EXIST.getCode());

            }
            return new RestObject(null);
        }catch (Exception e){
            throw  new UserException(ResultErrorCode.FEATURE_NOE_FOUND.getCode(),e.getMessage(),e.getStackTrace());

        }
    }
    @RequestMapping(value = "/monitor_target_lab_device/{id}",method = RequestMethod.GET)
    public RestObject findLabDeviceById(@PathVariable("id") Integer id){
        try {
            LabDevice labDevice=labDeviceService.findLabDeviceMonitorTargetById(id);
            if(labDevice==null){
                throw new UserException(null,ResultErrorCode.LABDEVICE_NOT_EXIST.getValue(),ResultErrorCode.LABDEVICE_NOT_EXIST.getCode());
            }
            return new RestObject(null);

        }catch (Exception e){
            throw  new UserException(ResultErrorCode.FEATURE_NOE_FOUND.getCode(),e.getMessage(),e.getStackTrace());
        }
    }
    @RequestMapping(value = "/monitor_target_lab_device/{id}",method = RequestMethod.PUT)
    public RestObject updateLabDevice(JwtAuthenticationToken token,@PathVariable("id") Integer id,@RequestBody  MonitorTargetLabDevice monitorTargetLabDevice){
        try {
            if(!labDeviceService.updateLabDevice(monitorTargetLabDevice,id)){
                throw new UserException(null,ResultErrorCode.LABDEVICE_UPDATE_FIAL.getValue(),ResultErrorCode.LABDEVICE_UPDATE_FIAL.getCode());

            }
            return new RestObject(null,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());

        }catch (Exception e){
            throw  new UserException(ResultErrorCode.FEATURE_NOE_FOUND.getCode(),e.getMessage(),e.getStackTrace());

        }

    }
    @RequestMapping(value = "/monitor_target_lab_device/{id}",method = RequestMethod.DELETE)
    public RestObject deleteMonitoringTargetAndLabDeviceById(@PathVariable("id") Integer id){

        try{
            if(!labDeviceService.deleteMonitoringTargetAndLabDeviceById(id)){
                throw new UserException(null,ResultErrorCode.LABDEVICE_DELETE_FAIL.getValue(),ResultErrorCode.LABDEVICE_DELETE_FAIL.getCode());

            }
            return new RestObject(null,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw  new UserException(ResultErrorCode.FEATURE_NOE_FOUND.getCode(),e.getMessage(),e.getStackTrace());
        }

    }
    @RequestMapping(value = "/monitor_target_lab_device/{id}/File/{fileId}",method = RequestMethod.DELETE)
    public RestObject deleteDeviceFile(@PathVariable("id") Integer id,@PathVariable("fileId") Integer fileId){

        try {
            if(!labDeviceService.deleteDeviceFile(id,fileId)){
                throw new UserException(null,ResultErrorCode.DEVICEFILES_DELETE_FAIL.getValue(),ResultErrorCode.DEVICEFILES_DELETE_FAIL.getCode());

            }
            return new RestObject(null,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());

        }catch (Exception e){
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }

    }
    @RequestMapping(value = "/monitor_target_lab_device/{id}/File",method = RequestMethod.GET)
    public RestObject findDeviceFiles(@PathVariable("id") Integer id){

        try {
            List<DeviceFiles> deviceFiles=labDeviceService.findDeviceFiles(id);
            if(deviceFiles==null){
                throw new UserException(null,ResultErrorCode.DEVICEFILES_NOT_EXIST.getValue(),ResultErrorCode.DEVICEFILES_NOT_EXIST.getCode());
            }
             return new RestObject(deviceFiles,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }

    }
    @RequestMapping(value = "/monitor_target_lab_device/{id}/File",method = RequestMethod.POST)
    public RestObject addDeviceFilesImage(@PathVariable("id") Integer id, @RequestParam("profileImage") MultipartFile file){

        try{
            String imgUrl=fileUploadService.uploadFile(file,"company"+id.toString(),"building/"+file.getName(),null);
            if(!labDeviceService.addDeviceFilesImage(imgUrl,id)){
                throw new UserException(null,ResultErrorCode.LABDEVICE_UPDATE_FIAL.getValue(),ResultErrorCode.LABDEVICE_UPDATE_FIAL.getCode());
            }
            return new RestObject(imgUrl,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());


        }

    }
    @RequestMapping(value = "/monitor_target_lab_device/{id}/image",method = RequestMethod.PUT)
    public RestObject updateDeviceFilesImage(@PathVariable("id") Integer id,@RequestParam("profileImage") MultipartFile file){

        try {
            LabDevice labDevice=labDeviceService.getLabDeviceById(id);
            String imgUrl=fileUploadService.uploadFile(file,"company"+id.toString(),"building/"+file.getName(),labDevice.getPhoto());
            labDevice.setPhoto(imgUrl);
            if(!labDeviceService.updateLabDeviceImage(labDevice)){
                throw new UserException(null,ResultErrorCode.LABDEVICE_UPDATE_FIAL.getValue(),ResultErrorCode.LABDEVICE_UPDATE_FIAL.getCode());

            }
            return new RestObject(imgUrl,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());

        }catch (Exception e){
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }
    }
    @RequestMapping(value = "/monitor_target_lab_device/{monitorTargetId}/measure_rule/{ruleId}",method = RequestMethod.DELETE)
    public RestObject deleteMonitoringTargetRule(@PathVariable("monitorTargetId") Integer monitorTargetId,@PathVariable("ruleId") Integer ruleId){

        try {
            if(!labDeviceService.deleteMonitoringTargetRule(monitorTargetId,ruleId)){
                throw new UserException(null,ResultErrorCode.MONITORTARGETMEASURETYPERULE_DELETE_FAIL.getValue(),ResultErrorCode.MONITORTARGETMEASURETYPERULE_DELETE_FAIL.getCode());

            }
            return new RestObject(null,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());

        }catch (Exception e){
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }

    }
    @RequestMapping(value = "/monitor_target_lab_device/{monitorTargetId}/measure_rule/{ruleId}",method = RequestMethod.PUT)
    public RestObject updateMonitorTargetMeasureTypeRule(@PathVariable("monitorTargetId") Integer monitorTargetId,@PathVariable("ruleId") Integer ruleId,@RequestBody Map<String,String> map,@RequestBody  MonitoringTargetMeasureRule monitoringTargetMeasureRule){
        try {
            String measureTypeName=map.get("measureTypeName");
            if(!labDeviceService.updateMonitorTargetMeasureTypeRule(monitorTargetId,ruleId,monitoringTargetMeasureRule,measureTypeName)){
                throw new UserException(null,ResultErrorCode.LABDEVICE_UPDATE_FIAL.getValue(),ResultErrorCode.LABDEVICE_UPDATE_FIAL.getCode());

            }
            return new RestObject(null,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());

        }catch (Exception e){
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }


    }



    private void userChecks(Integer id) {
        User user = userMapper.getUserById(id);
        List<Role> roleList = userRolesMapper.getLoginRoleIdByLoginUserId(user.getId());
        parametersAndPermissionsCheck.userCheck(ResultErrorCode.FILL_PARAMETERS.getCode(), roleList);
    }
}
