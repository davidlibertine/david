package com.ilabservice.intelab.controller.secure;


import com.ilabservice.intelab.check.ParametersAndPermissionsCheck;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.model.MeasureType;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.security.auth.JwtAuthenticationToken;
import com.ilabservice.intelab.security.model.UserContext;
import com.ilabservice.intelab.service.MeasureTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/secure/")
public class MeasureTypeController {

    @Resource
    private MeasureTypeService measureTypeService;

    @Resource
    ParametersAndPermissionsCheck parametersAndPermissionsCheck;

    /**
     * 根据id查询监控参数
     * @param id
     * @return
     */
    @RequestMapping(value = "/measure_type/{id}", method = RequestMethod.GET)
    public RestObject getMeasureTypeById(@PathVariable("id") Integer id) {
        MeasureType measureType = measureTypeService.getMeasureTypeById(id);
        if(id != null) {
            if(measureType != null) {
                return new RestObject(measureType);
            }
            new RestObject(ResultErrorCode.NOT_FOUND_PAGE_OR_URL_OR_MODEL.getValue()
                    , null ,ResultErrorCode.NOT_FOUND_PAGE_OR_URL_OR_MODEL.getCode());
        }
        return new RestObject(ResultErrorCode.PARAMS_IS_NULL.getValue()
                , null ,ResultErrorCode.PARAMS_IS_NULL.getCode());
    }

    /**
     * 获取所有的监控参数
     * @return
     */
    @RequestMapping(value = "/measure_type", method = RequestMethod.GET)
    public RestObject getAllMeasureType() {
        List<MeasureType> measureType = measureTypeService.getAllMeasureType();
        if(measureType != null) {
            return new RestObject(measureType);
        }
        return new RestObject(ResultErrorCode.NOT_FOUND_PAGE_OR_URL_OR_MODEL.getValue()
                , null ,ResultErrorCode.NOT_FOUND_PAGE_OR_URL_OR_MODEL.getCode());
    }

    /**
     * 根据 id 删除监控参数
     * @param token
     * @param id
     * @return
     */
    @RequestMapping(value = "/measure_type/{id}", method = RequestMethod.DELETE)
    public RestObject deleteMeasureTypeById(JwtAuthenticationToken token, @PathVariable("id") Integer id) {
        UserContext context = (UserContext) token.getPrincipal();
        parametersAndPermissionsCheck.userPlatformAdminCheck(context.getId());
        if(id != null) {
            if(measureTypeService.deleteMeasureTypeById(id)) {
                return new RestObject(ResultErrorCode.SUCCESS.getValue(),
                        null , ResultErrorCode.SUCCESS.getCode());
            }
            return new RestObject(ResultErrorCode.DELETE_INFO_ERROR.getValue()
                    , null ,ResultErrorCode.DELETE_INFO_ERROR.getCode());
        }
        return new RestObject(ResultErrorCode.PARAMS_IS_NULL.getValue()
                , null ,ResultErrorCode.PARAMS_IS_NULL.getCode());
    }

    /**
     * 根据id更新监控参数
     * @param token
     * @param id
     * @return
     */
    @RequestMapping(value = "/measure_type/{id}", method = RequestMethod.PUT)
    public RestObject updateMeasureTypeById(JwtAuthenticationToken token, @PathVariable("id") Integer id, MeasureType newMeasureType) {
        UserContext context = (UserContext) token.getPrincipal();
        parametersAndPermissionsCheck.userPlatformAdminCheck(context.getId());
        if(id != null) {
            if(measureTypeService.updateMeasureTypeById(id, newMeasureType)) {
                return new RestObject(ResultErrorCode.SUCCESS.getValue(),
                        null , ResultErrorCode.SUCCESS.getCode());
            }
            return new RestObject(ResultErrorCode.SERVER_PROCESSING_ERROR.getValue()
                    , null ,ResultErrorCode.SERVER_PROCESSING_ERROR.getCode());
        }
        return new RestObject(ResultErrorCode.PARAMS_IS_NULL.getValue()
                , null ,ResultErrorCode.PARAMS_IS_NULL.getCode());
    }

    /**
     * 新增监控参数
     * @param token
     * @param newMeasureType
     * @return
     */
    @RequestMapping(value = "/measure_type/{id}", method = RequestMethod.POST)
    public RestObject addMeasureType(JwtAuthenticationToken token, MeasureType newMeasureType) {
        UserContext context = (UserContext) token.getPrincipal();
        parametersAndPermissionsCheck.userPlatformAdminCheck(context.getId());
        if(measureTypeService.addMeasureTyp(newMeasureType)) {
            return new RestObject(ResultErrorCode.SUCCESS.getValue(),
                    null , ResultErrorCode.SUCCESS.getCode());
        }
        return new RestObject(ResultErrorCode.SERVER_PROCESSING_ERROR.getValue()
                , null ,ResultErrorCode.SERVER_PROCESSING_ERROR.getCode());
    }
}
