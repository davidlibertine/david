package com.ilabservice.intelab.controller.secure;

import com.alibaba.fastjson.JSON;
import com.ilabservice.intelab.check.ParametersAndPermissionsCheck;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.model.Location;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.security.auth.JwtAuthenticationToken;
import com.ilabservice.intelab.security.model.UserContext;
import com.ilabservice.intelab.service.LocationService;
import com.ilabservice.intelab.service.UserService;
import com.ilabservice.intelab.storage.FileUploadService;
import com.ilabservice.intelab.vo.assemblyvo.LocationVoMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


@RestController("secureLocationController")
@RequestMapping(value="/api/secure/customer")
public class LocationController {

    private static Logger logger = LoggerFactory.getLogger(LocationController.class);

    @Autowired
    LocationService locationService;

    @Autowired
    ParametersAndPermissionsCheck parametersAndPermissionsCheck;

    @Autowired
    FileUploadService fileUploadService;

    @Autowired
    UserService userService;

    @RequestMapping(value = "/company/{companyId}/root/location", method = RequestMethod.GET)
    @ResponseBody
    public RestObject getRootLocationsOfCompany(JwtAuthenticationToken token, @PathVariable(value="companyId") Integer companyId){
        try {
            UserContext context = (UserContext) token.getPrincipal();
            Location location = locationService.getRootLocationsByCompanyId(companyId);
            locationService.fillLocationWithMonitoringTarget(location, context.getId());
            return new RestObject(LocationVoMapper.getLocationVo(location));
        }
        catch(Exception e){
            throw e;
        }
    }


    @RequestMapping(value = "/location", consumes="multipart/form-data", method = RequestMethod.POST)
    @ResponseBody
    public RestObject createLocation(JwtAuthenticationToken token,
                                     @RequestParam(value = "profileImage") MultipartFile file,
                                     @RequestParam(value = "location") String locationString){
        try{
            UserContext userContext = (UserContext)token.getPrincipal();
            parametersAndPermissionsCheck.userPlatformAdminCheck(userContext.getId());

            Location location = JSON.parseObject(locationString, Location.class);
            if(location.getParentId() == null){
                throw new UserException(ResultErrorCode.PARAMS_NOT_COMPLETE.getCode(), "parent id cannot be null", null);
            }
            if(location.getLocationType() == null) {
                throw new UserException(ResultErrorCode.PARAMS_NOT_COMPLETE.getCode(), "location type cannot be null", null);
            }
            if(location.getName() == null){
                throw new UserException(ResultErrorCode.PARAMS_NOT_COMPLETE.getCode(), "location name cannot be null", null);
            }

            Integer companyId = userService.getLoginUserInfoByUserId(userContext.getId()).getCompanyId();

            String url = fileUploadService.uploadFile(file, "company" + companyId.toString(),
                    "building/" + file.getName(), null);
            location.setBackground(url);
            locationService.insertChildLocation(location);
            return new RestObject(LocationVoMapper.getLocationVo(location));
        }
        catch(Exception e){
            throw e;
        }
    }


    @RequestMapping(value = "/location/{locationId}", method = RequestMethod.GET)
    @ResponseBody
    public RestObject getLocation(JwtAuthenticationToken token, @PathVariable(value="locationId") Integer locationId){
        try{
            UserContext context = (UserContext) token.getPrincipal();
            Location location = locationService.getLocationById(locationId);
            locationService.fillLocationWithMonitoringTarget(location, context.getId());
            return new RestObject(LocationVoMapper.getLocationVo(location));
        }
        catch(Exception e){
            throw e;
        }
    }

    @RequestMapping(value = "/location/{locationId}", method = RequestMethod.PUT)
    @ResponseBody
    public RestObject updateLocation(JwtAuthenticationToken token,
                                     @PathVariable(value="locationId") Integer locationId,
                                     @RequestBody Location location){
        try {
            UserContext userContext = (UserContext)token.getPrincipal();
            parametersAndPermissionsCheck.userPlatformAdminCheck(userContext.getId());

            location.setId(locationId);
            locationService.updateLocation(location);
            Location newLocation = locationService.getLocationById(locationId);
            locationService.fillLocationWithMonitoringTarget(newLocation, userContext.getId());
            return new RestObject(LocationVoMapper.getLocationVo(newLocation));
        }
        catch(Exception e){
            throw e;
        }
    }

    @RequestMapping(value = "/location/{locationId}", method = RequestMethod.DELETE)
    @ResponseBody
    public void deleteLocation(JwtAuthenticationToken token,
                                     @PathVariable(value="locationId") Integer locationId){
        try{
            UserContext userContext = (UserContext)token.getPrincipal();
            parametersAndPermissionsCheck.userPlatformAdminCheck(userContext.getId());

            locationService.deleteLocationAndChild(locationId);
        }
        catch(Exception e){
            throw e;
        }
    }

    @RequestMapping(value = "/location/{locationId}/background", method = RequestMethod.PUT)
    @ResponseBody
    public RestObject updateLocationBackground(JwtAuthenticationToken token,
                                               @PathVariable(value="locationId") Integer locationId,
                                               @RequestParam(value="profileImage") MultipartFile file){
        try{
            UserContext userContext = (UserContext)token.getPrincipal();
            parametersAndPermissionsCheck.userPlatformAdminCheck(userContext.getId());

            Location location = locationService.getLocationById(locationId);
            String url =fileUploadService.uploadFile(file, "company" + location.getCompanyId().toString(),
                    "building/" + file.getName(), location.getBackground());
            location.setBackground(url);
            locationService.updateLocation(location);
            return new RestObject(url);
        }
        catch(Exception e){
            throw e;
        }
    }
}
