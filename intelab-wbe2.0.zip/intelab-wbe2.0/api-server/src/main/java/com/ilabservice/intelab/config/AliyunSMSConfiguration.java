package com.ilabservice.intelab.config;

import com.ilabservice.intelab.message.sms.SmsService;
import com.ilabservice.intelab.message.sms.aliyun.AliyunMessageManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class AliyunSMSConfiguration {

    @Value("${sms.aliyun-sms.accessKey.ID:#{null}}")
    String accessKeyId;

    @Value("${sms.aliyun-sms.accessKey.Secret:#{null}}")
    String accessKeySecret;

    @Value("${sms.aliyun-sms.templet.alertModel:#{null}}")
    String alertModel;

    @Value("${sms.aliyun-sms.templet.noticeAlert:#{null}}")
    String noticeAlert;

    @Value("${sms.aliyun-sms.templet.offlineAlert:#{null}}")
    String offlineAlert;

    @Value("${sms.aliyun-sms.templet.verifyModel:#{null}}")
    String verifyModel;

    @Value("${sms.aliyun-sms.templet.passwordModel:#{null}}")
    String passwordModel;

    @Bean(name = "SmsService")
    @ConditionalOnProperty(name = "sms.type", havingValue = "aliyun")
    public SmsService getAliyunSmsService() {
        Map<String, String> templateCodes = new HashMap<>();
        templateCodes.put("alertModel", alertModel);
        templateCodes.put("noticeAlert", noticeAlert);
        templateCodes.put("offlineAlert", offlineAlert);
        templateCodes.put("verifyModel", verifyModel);
        templateCodes.put("passwordModel", passwordModel);
        return new AliyunMessageManager(accessKeyId, accessKeySecret, templateCodes);
    }
}
