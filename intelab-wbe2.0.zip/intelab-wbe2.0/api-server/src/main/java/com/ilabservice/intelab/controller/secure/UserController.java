package com.ilabservice.intelab.controller.secure;

import com.github.pagehelper.PageInfo;
import com.ilabservice.intelab.common.ObjectRestResponse;
import com.ilabservice.intelab.check.ParametersAndPermissionsCheck;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.CompanyMapper;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.model.Company;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.User;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.security.auth.JwtAuthenticationToken;
import com.ilabservice.intelab.security.model.UserContext;
import com.ilabservice.intelab.service.UserService;
import com.ilabservice.intelab.utils.MD5Utils;
import com.ilabservice.intelab.vo.LoginUserRolesVo;
import com.ilabservice.intelab.vo.UserVo;
import com.ilabservice.intelab.vo.assemblyvo.UserVoMapper;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * Created by gxu on 1/29/18.
 */
@RestController("secureUserController")
@RequestMapping(value="/api/secure/customer")
public class UserController {

    private static Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @Resource
    private CompanyMapper companyMapper;

    @Resource
    private UserMapper userMapper;

    @Resource
    private UserRolesMapper userRolesMapper;

    @Autowired
    private ParametersAndPermissionsCheck parametersAndPermissionsCheck;

    @RequestMapping(value="", method = RequestMethod.GET)
    public @ResponseBody
    ObjectRestResponse<User> GetUser(JwtAuthenticationToken token){
        UserContext context = (UserContext) token.getPrincipal();
        return new ObjectRestResponse<>().rel(true).data(userService.getUserDetailInfo(context.getId()));
    }
//
//    @RequestMapping(value="/roles", method = RequestMethod.GET)
//    public @ResponseBody
//    RestObject GetUserRoles(JwtAuthenticationToken token){
//        UserContext context = (UserContext)token.getPrincipal();
//        return new RestObject(new RestRoleArray(userRepository.findByUserName(context.getUsername()).getRoles()));
//    }

    /**
     * 獲取當前登陸用戶的信息
     * @return
     */
    @RequestMapping(value = "/me", method = RequestMethod.GET)
    public RestObject getUserInfo(JwtAuthenticationToken token) {
        try {
            UserContext context = (UserContext) token.getPrincipal();
            User user = userService.getLoginUserInfoByUserId(context.getId());
            /**
             * 組裝vo對象返回前端
             */
            UserVo userVo = UserVoMapper.getUserVoByUserModelAndCompanyModel(user, companyMapper.selectById(user.getCompanyId()));
            if(userVo == null) {
                throw new UserException(ResultErrorCode.USER_NOT_EXIST.getCode(), ResultErrorCode.USER_NOT_EXIST.getValue(), null);
            }
            return new RestObject(userVo);
        } catch (Exception e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(), e.getMessage(), e.getStackTrace());
        }
    }

    /**
     * 修改用戶個人信息
     * @param token
     * @return
     */
    @RequestMapping(value = "/me", method = RequestMethod.PUT)
    public RestObject updateUserInfo(JwtAuthenticationToken token, User oldUser) {
        UserContext context = (UserContext) token.getPrincipal();
        /**
         * 如果沒有獲取到前端傳過來的用戶信息，直接抛出異常信息給前端
         */
        if (oldUser == null) {
            throw new UserException(ResultErrorCode.NO_GET_USER_INFO.getCode(), ResultErrorCode.NO_GET_USER_INFO.getValue(), null);
        }
        try {
            User user = userService.updateOldUserInfoReturnNewUserInfo(oldUser, context.getId());
            /**
             * 此處做一個空判斷，如果user等於null，那麽用戶信息一定是更新失敗的，直接返回一個失敗信息給前端，否則返回查詢出來的新對象
             */
            if(user == null) {
                throw new UserException(ResultErrorCode.UPDATE_USER_FAIL.getCode(), ResultErrorCode.UPDATE_USER_FAIL.getValue(), null);
            }
            /**
             * 這個暫時就加在這裏，同時把更改后的用戶信息及狀態都返回給前端， 前端可以實際需求來決定使用哪些數據
             */
            UserVo userVo = UserVoMapper.getUserVoByUserModelAndCompanyModel(user, companyMapper.selectById(user.getCompanyId()));
            return new RestObject(userVo, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(), e.getMessage(), e.getStackTrace());
        }
    }

    /**
     * 更新用戶頭像并把新的url返回給前端
     * @param token
     * @param imageUrl
     * @return
     */
    @RequestMapping(value = "/me/avatar", method = RequestMethod.PUT)
    public RestObject updateLoginUserHeadIcon(JwtAuthenticationToken token, String imageUrl) {
        UserContext context = (UserContext) token.getPrincipal();
        if (StringUtils.isEmpty(imageUrl)) {
            throw new UserException(ResultErrorCode.DATA_NOT_FOUND.getCode(), ResultErrorCode.DATA_NOT_FOUND.getValue(), null);
        }
        try {
            /**
             * 更新后需要返回新的頭像路徑
             */
            String newImgUrl = userService.updateLoginUserHeadIcon(context.getId(), imageUrl);
            if(StringUtils.isEmpty(newImgUrl)) {
                throw new UserException(ResultErrorCode.UPDATE_USER_HEAD_ICON_FAIL.getCode(),
                        ResultErrorCode.UPDATE_USER_HEAD_ICON_FAIL.getValue(), null);
            }
            return new RestObject(newImgUrl, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(), e.getMessage(), e.getStackTrace());
        }
    }

    /**
     * 修改密碼
     * @param token
     * @param oldPwd
     * @param newPwd
     * @return
     */
    @RequestMapping(value = "/me/modify/password", method = RequestMethod.POST)
    public RestObject updateLoginUserPassword(JwtAuthenticationToken token, String oldPwd, String newPwd) {
        UserContext context = (UserContext) token.getPrincipal();
        /**
         * 如果數據庫裏面查出來的密碼和傳過來的密碼相同才允許修改，所以這個地方要做一次校驗
         */
        if(!userService.selectById(context.getId()).getPassword().equals(MD5Utils.md5Encode(oldPwd, "utf-8"))) {
            throw new UserException(ResultErrorCode.USER_PASSWORD_ERROR.getCode(),
                    ResultErrorCode.USER_PASSWORD_ERROR.getValue(), null);
        }
        try {
            if(userService.updateLoginUserPassword(context.getId(), MD5Utils.md5Encode(newPwd, "utf-8"))) {
                //TODO: 如果修改成功是否需要用戶重新登陸 ...
                return new RestObject(null, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            return new RestObject(null, ResultErrorCode.UPDATE_USER_PASSWORD_ERROR.getValue(),
                    ResultErrorCode.UPDATE_USER_PASSWORD_ERROR.getCode());
        } catch (Exception e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(), e.getMessage(), e.getStackTrace());
        }
    }

    /**
     * 獲取該用戶公司的所有員工信息， 該用戶必須是管理員
     * @param token
     * @param limit
     * @param offset
     * @return
     */
    @RequestMapping(value = "/user", method = RequestMethod.GET)
    public RestObject getLoginUserCompanyUser(JwtAuthenticationToken token, Integer limit, Integer offset) {
        UserContext context = (UserContext) token.getPrincipal();
        User user = userService.selectById(context.getId());
        userChecks(context.getId());
        try {
            PageInfo pageInfo = userService.getLoginUserCompanyUser(limit, offset, context.getId());
            if(pageInfo == null) {
                throw new UserException(ResultErrorCode.NO_GET_USER_COMPANY_INFO.getCode(),
                        ResultErrorCode.NO_GET_USER_COMPANY_INFO.getValue(), null);
            }
            return new RestObject(pageInfo, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 为该用户的公司添加一个用户
     * @param token
     * @param user
     * @return
     */
    @RequestMapping(value = "/user", method = RequestMethod.POST)
    public RestObject addUserForCompany(JwtAuthenticationToken token, User user) {
        UserContext context = (UserContext) token.getPrincipal();
        userChecks(context.getId());
        try {
            Map<String ,Object> map = userService.addUserForCompany(user, context.getId());
            if(map.size() > 0) {
                UserVo userVo = UserVoMapper.getUserVoByUserModelAndCompanyModel((User) map.get("userInfo"), (Company) map.get("company"));
                return new RestObject(userVo, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            /**
             * 如果为空，返回服务器处理错误，状态为500
             */
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (Exception e) {
            /**
             * 系统异常
             */
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 根据id查询用户
     * @param id
     * @return
     */
    @RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
    public RestObject getUserInfoByUserId(JwtAuthenticationToken token, @PathVariable("id") Integer id) {
        UserContext context = (UserContext) token.getPrincipal();
        userChecks(context.getId());
        try {
            Map<String, Object> map = userService.getUserInfoByUserId(id);
            if(map.size() > 0) {
                UserVo userVo = UserVoMapper.getUserVoByUserModelAndCompanyModel((User) map.get("userInfo"), (Company) map.get("company"));
                return new RestObject(userVo, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            /**
             * 如果为空，not found，状态为404
             */
            throw new UserException(ResultErrorCode.NOT_FOUND_PAGE_OR_URL_OR_MODEL.getCode(),
                    ResultErrorCode.NOT_FOUND_PAGE_OR_URL_OR_MODEL.getValue(), null);
        } catch (UserException e) {
            /**
             * 系统异常
             */
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 根据 id 删除用户
     * @param id
     * @return
     */
    @RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
    public RestObject delectUserById(JwtAuthenticationToken token, @PathVariable("id") Integer id) {
        UserContext context = (UserContext) token.getPrincipal();
        userChecks(context.getId());
        if(userService.delectUserById(id)) {
            return new RestObject(null, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
        }
        throw new UserException(ResultErrorCode.DELETE_INFO_ERROR.getCode(),
                ResultErrorCode.DELETE_INFO_ERROR.getValue(), null);
    }

    /**
     * 根据id更新用户信息
     * @param token
     * @param id
     * @param user
     * @return
     */
    @RequestMapping(value = "/user/{id}", method = RequestMethod.PUT)
    public RestObject updateUserInfoById(JwtAuthenticationToken token, @PathVariable("id") Integer id, User user) {
        UserContext context = (UserContext) token.getPrincipal();
        userChecks(context.getId());
        try {
            Map<String, Object> map = userService.updateUserInfoById(id, user, context.getId());
            if(map.size() > 0) {
                UserVo userVo = UserVoMapper.getUserVoByUserModelAndCompanyModel((User)map.get("userInfo"), (Company) map.get("company"));
                return new RestObject(userVo, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (Exception e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 给指定用户添加一个角色
     * @param token
     * @param user_id
     * @param role_id
     * @return
     */
    @RequestMapping(value = "/user/{user_id}/role/{role_id}", method = RequestMethod.POST)
    public RestObject addRoleToSpecifiedUser(JwtAuthenticationToken token, @PathVariable("user_id") Integer user_id, @PathVariable("role_id") Integer role_id) {
        UserContext context = (UserContext) token.getPrincipal();
        userChecks(context.getId());
        try {
            if(userService.addRoleToSpecifiedUser(role_id, user_id)) {
                return new RestObject(null, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (Exception e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 从指定用户删除一个角色
     * @param token
     * @param user_id
     * @param role_id
     * @return
     */
    @RequestMapping(value = "/user/{user_id}/role/{role_id}", method = RequestMethod.DELETE)
    public RestObject deleteRoleToSpecifiedUser(JwtAuthenticationToken token, @PathVariable("user_id") Integer user_id, @PathVariable("role_id") Integer role_id) {
        UserContext context = (UserContext) token.getPrincipal();
        userChecks(context.getId());
        try {
            if(userService.deleteRoleToSpecifiedUser(role_id, user_id)) {
                return new RestObject(null, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 注销用户
     * @param token
     * @return
     */
    @RequestMapping(value = "/user/logout", method = RequestMethod.GET)
    public RestObject logOut(JwtAuthenticationToken token) {
        UserContext context = (UserContext) token.getPrincipal();
        userChecks(context.getId());
        // TODO: 注销用户登陆
        return new RestObject("successful operation");
    }

    /**
     * 获取登陆用户的角色和权限
     * @param token
     * @return
     */
    @RequestMapping(value = "/me/role", method = RequestMethod.GET)
    public RestObject getLoginUserRolesAndPermissions(JwtAuthenticationToken token) {
        UserContext context = (UserContext) token.getPrincipal();
        userChecks(context.getId());
        try {
            List<LoginUserRolesVo> loginUserRolesVoList = userService.getLoginUserRolesAndPermissions(context.getId());
            if(loginUserRolesVoList != null) {
                return new RestObject(loginUserRolesVoList);
            }
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (UserException e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 权限校验
     * @param id
     */
    private void userChecks(Integer id) {
        User user = userMapper.getUserById(id);
        List<Role> roleList = userRolesMapper.getLoginRoleIdByLoginUserId(user.getId());
        parametersAndPermissionsCheck.userCheck(ResultErrorCode.FILL_PARAMETERS.getCode(), roleList);
    }
}
