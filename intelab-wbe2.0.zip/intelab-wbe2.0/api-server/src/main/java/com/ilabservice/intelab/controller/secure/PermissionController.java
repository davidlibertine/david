package com.ilabservice.intelab.controller.secure;

import com.github.pagehelper.PageInfo;
import com.ilabservice.intelab.check.ParametersAndPermissionsCheck;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.model.Permission;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.User;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.security.auth.JwtAuthenticationToken;
import com.ilabservice.intelab.security.model.UserContext;
import com.ilabservice.intelab.service.PermissionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;


@RestController
@RequestMapping("/api/secure/admin/")
public class PermissionController {

    private static Logger logger = LoggerFactory.getLogger(RoleController.class);

    @Resource
    private PermissionService permissionService;

    @Resource
    private UserMapper userMapper;

    @Resource
    private UserRolesMapper userRolesMapper;

    @Autowired
    private ParametersAndPermissionsCheck parametersAndPermissionsCheck;
    /**
     * 获取所有数据库中现存的权限
     * @param token
     * @param limit
     * @param offset
     * @return
     */
    @RequestMapping(value = "/permission", method = RequestMethod.GET)
    public RestObject getAllPermission(JwtAuthenticationToken token, Integer limit, Integer offset) {
        UserContext context = (UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            PageInfo pageInfo = permissionService.getAllPermission(limit, offset);
            if(pageInfo == null) {
                throw new UserException(ResultErrorCode.NO_GET_PERMISSION_INFO.getCode(),
                        ResultErrorCode.NO_GET_PERMISSION_INFO.getValue(), null);
            }
            return new RestObject(pageInfo, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
        } catch (Exception e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 添加一个权限
     * @param token
     * @return
     */
    @RequestMapping(value = "/permission", method = RequestMethod.POST)
    public RestObject addPermission(JwtAuthenticationToken token, Permission permission) {
        UserContext context = (UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            Permission newPermission = permissionService.addPermission(permission);
            if(newPermission == null) {
                throw new UserException(ResultErrorCode.NO_GET_PERMISSION_INFO.getCode(),
                        ResultErrorCode.NO_GET_PERMISSION_INFO.getValue(), null);
            }
            return new RestObject(newPermission, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
        } catch (Exception e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 删除权限
     * @param token
     * @param id
     * @return
     */
    @RequestMapping(value = "/permission/{id}", method = RequestMethod.DELETE)
    public RestObject deletePermission(JwtAuthenticationToken token, @PathVariable("id") Integer id) {
        UserContext context = (UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            if(permissionService.deletePermission(id)) {
                return new RestObject(null, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.DELETE_INFO_ERROR.getCode(),
                    ResultErrorCode.DELETE_INFO_ERROR.getValue(), null);
        } catch (Exception e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 修改权限
     * @param token
     * @param id
     * @return
     */
    @RequestMapping(value = "/permission/{id}", method = RequestMethod.PUT)
    public RestObject updatePermission(JwtAuthenticationToken token, @PathVariable("id") Integer id, Permission permission) {
        UserContext context = (UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            if(permissionService.updatePermission(id, permission)) {
                return new RestObject(null, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
            }
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (Exception e) {
            logger.error(e.toString());
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    /**
     * 权限校验
     * @param id
     */
    private void checks(Integer id) {
        User user = userMapper.getUserById(id);
        List<Role> roleList = userRolesMapper.getLoginRoleIdByLoginUserId(user.getId());
        parametersAndPermissionsCheck.adminCheck(ResultErrorCode.FILL_PARAMETERS.getCode(), roleList);
    }
}
