package com.ilabservice.intelab.restful.request;

public class MonitorTargetTypeRequest {
}
