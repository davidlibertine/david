package com.ilabservice.intelab.config;

import com.ilabservice.intelab.storage.FileUploadService;
import com.ilabservice.intelab.storage.azure.AzureStorageManager;
import com.ilabservice.intelab.storage.ftp.FTPStorageManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class FileStorageConfiguration {

    @Value("${file-storage.azure.accountName:#{null}}")
    String accountName;

    @Value("${file-storage.azure.accessKey1:#{null}}")
    String accessKey1;

    @Value("${file-storage.azure.azureCloud:#{null}}")
    String azureCloud;

    @Value("${file-storage.azure.endPoint:#{null}}")
    String endPoint;

    @Value("${file-storage.azure.serviceName:#{null}}")
    String serviceName;

    @Value("${file-storage.ftp.host:#{null}}")
    String ftpHost;

    @Value("${file-storage.ftp.user:#{null}}")
    String ftpUser;

    @Value("${file-storage.ftp.password:#{null}}")
    String ftpPassword;

    @Value("${file-storage.ftp.port:#{null}}")
    String ftpPort;

    @Bean(name = "FileStorageService")
    @ConditionalOnProperty(name = "file-storage.type", havingValue = "azure")
    public FileUploadService getAzureFileUploadService(){
        return new AzureStorageManager(serviceName, accountName,
                accessKey1, azureCloud, endPoint);
    }

    @Bean(name = "FileStorageService")
    @ConditionalOnProperty(name = "file-storage.type", havingValue = "ftp")
    public FileUploadService getFtpFileUploadService(){
        return new FTPStorageManager(ftpHost, ftpUser, ftpPassword, ftpPort);
    }
}
