package com.ilabservice.intelab.security.exceptions;

public class InvalidJwtToken extends RuntimeException{
}
