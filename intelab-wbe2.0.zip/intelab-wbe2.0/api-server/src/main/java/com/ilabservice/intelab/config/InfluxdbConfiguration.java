package com.ilabservice.intelab.config;

import com.ilabservice.intelab.influxdb.InfluxDBManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// TODO: 待确认， 可能需要修改

@Configuration
public class InfluxdbConfiguration {

    @Value("${influxdb.influxdb-config.serverIp:#{null}}")
    String serverIp;

    @Value("${influxdb.influxdb-config.port:#{null}}")
    Integer port;

    @Value("${influxdb.influxdb-config.username:#{null}}")
    String username;

    @Value("${influxdb.influxdb-config.password:#{null}}")
    String password;

    @Bean(name = "InfluxDBManager")
    @ConditionalOnProperty(name = "influxdb.type", havingValue = "influxdb")
    public InfluxDBManager getInfluxDBManager(){
        return new InfluxDBManager(serverIp, port,
                username, password);
    }

}
