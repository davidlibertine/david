package com.ilabservice.intelab.security.model.token;

public interface JwtToken {
    String getToken();
}
