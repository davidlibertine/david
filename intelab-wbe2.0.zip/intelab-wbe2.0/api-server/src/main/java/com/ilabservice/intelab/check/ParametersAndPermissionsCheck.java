package com.ilabservice.intelab.check;

import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.exceptions.PermissionsException;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.RoleMapper;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.User;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ParametersAndPermissionsCheck {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private RoleMapper roleMapper;

    @Autowired
    private UserRolesMapper userRolesMapper;

    public boolean adminCheck(Integer id, List<Role> roleList) throws UserException {
        if(id == null) {
            throw new UserException(ResultErrorCode.PARAMS_IS_NULL.getCode(),
                    ResultErrorCode.PARAMS_IS_NULL.getValue(), null);
        }
        for(Role role : roleList) {
            if(StringUtils.equals(role.getRoleType(), ResultErrorCode.SYSTEM_ADMIN.getValue())) {
                return true;
            }
        }
        // TODO : 校驗該用戶是不是管理員,如果不是則直接抛出異常
        throw new UserException(ResultErrorCode.PERMISSION_NO_ACCESS.getCode(),
                ResultErrorCode.PERMISSION_NO_ACCESS.getValue(), null);
    }

    /**
     * 校验用户
     * @param id
     * @param roleList
     * @return
     * @throws UserException
     */
    public boolean userCheck(Integer id, List<Role> roleList) throws UserException {
        if(id == null) {
            throw new UserException(ResultErrorCode.PARAMS_IS_NULL.getCode(),
                    ResultErrorCode.PARAMS_IS_NULL.getValue(), null);
        }
        for(Role role : roleList) {
            if(StringUtils.equals(role.getRoleType(), ResultErrorCode.USER_ROLE.getValue())) {
                return true;
            }
        }
        // TODO : 校驗該用戶是不是管理員,如果不是則直接抛出異常
        throw new UserException(ResultErrorCode.PERMISSION_NO_ACCESS.getCode(),
                ResultErrorCode.PERMISSION_NO_ACCESS.getValue(), null);
    }

    public void userPlatformAdminCheck(Integer userId) throws UserException{
        User user = userMapper.getUserById(userId);

        if(!user.getRoles().stream().anyMatch(p -> p.getId() == ResultErrorCode.USER_PLATFORM_MANAGER.getCode())){
            throw new PermissionsException("user is not platform admin", null);
        }
    }

    public boolean adminOrUserCheck(Integer id, List<Role> roleList) throws UserException {
        if(id == null) {
            throw new UserException(ResultErrorCode.PARAMS_IS_NULL.getCode(),
                    ResultErrorCode.PARAMS_IS_NULL.getValue(), null);
        }
        for(Role role : roleList) {
            if(StringUtils.equals(role.getRoleType(), ResultErrorCode.SYSTEM_ADMIN.getValue())
                    || StringUtils.equals(role.getRoleType(), ResultErrorCode.USER_ROLE.getValue())
                    ) {
                return true;
            }
        }
        // TODO : 校驗該用戶是不是管理員,如果不是則直接抛出異常
        throw new UserException(ResultErrorCode.PERMISSION_NO_ACCESS.getCode(),
                ResultErrorCode.PERMISSION_NO_ACCESS.getValue(), null);
    }
}
