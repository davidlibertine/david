package com.ilabservice.intelab.controller.secure;

import com.ilabservice.intelab.check.ParametersAndPermissionsCheck;
import com.ilabservice.intelab.common.ObjectRestResponse;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.common.TableResultResponse;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.model.*;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.security.auth.JwtAuthenticationToken;
import com.ilabservice.intelab.security.model.UserContext;
import com.ilabservice.intelab.service.MonitoringTargetTypeService;
import com.ilabservice.intelab.storage.FileUploadService;
import com.ilabservice.intelab.vo.MeasureRuleVo;
import com.ilabservice.intelab.vo.assemblyvo.MeasureRuleVoMapper;
import com.ilabservice.intelab.vo.assemblyvo.MonitoringTargetTypeVoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import retrofit2.http.Path;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/secure")
public class MonitoringTargetTypeController {
    @Autowired
    UserMapper userMapper;
    @Autowired
    UserRolesMapper userRolesMapper;
    @Autowired
    ParametersAndPermissionsCheck parametersAndPermissionsCheck;
    @Autowired
    MonitoringTargetTypeService monitoringTargetTypeService;
    @Autowired
    FileUploadService fileUploadService;
    @RequestMapping(value = "/admin/monitor_target_type",method = RequestMethod.GET)
    public TableResultResponse findAdminListAllMonitoringTargetType(JwtAuthenticationToken token, @RequestParam(value = "limit", required = false,defaultValue = "10") Integer limit,
                                                               @RequestParam(value = "offset", required = false,defaultValue = "0") Integer offset){
        UserContext context=(UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            List<MonitoringTargetType> monitoringTargetTypes=monitoringTargetTypeService.findListAllMonitoringTargetType(limit,offset);
            if(monitoringTargetTypes==null){
               throw  new UserException(null,ResultErrorCode.MONITORINGTARGETTYPE_NOT_EXIST.getValue(),ResultErrorCode.MONITORINGTARGETTYPE_NOT_EXIST.getCode());
            }
            int tal=monitoringTargetTypeService.monitoringTargetTypeCount();
            return new TableResultResponse(tal,MonitoringTargetTypeVoMapper.getAllMonitoringTargetType(monitoringTargetTypes));
        }catch (Exception e){
                throw new UserException(ResultErrorCode.FEATURE_NOE_FOUND.getCode(),e.getMessage(),e.getStackTrace());
        }
    }
    @RequestMapping(value = "/admin/monitor_target_type",method = RequestMethod.POST)
    public RestObject addMonitoringTargetType(JwtAuthenticationToken token,@RequestParam("profileImage") MultipartFile file,MonitoringTargetType monitoringTargetType,List<Integer> measureTypes){
        try{
            UserContext context=(UserContext) token.getPrincipal();
            checks(context.getId());
            String logoUrl=fileUploadService.uploadFile(file,"company","building/"+file.getName(),null);
            MonitoringTargetType monitoringTargetType1=monitoringTargetTypeService.addMonitoringTargetType(measureTypes,monitoringTargetType,logoUrl);
            if(monitoringTargetType1==null){
                   throw  new UserException(null,ResultErrorCode.MONITORINGTARGETTYPE_NOT_EXIST.getValue(),ResultErrorCode.MONITORINGTARGETTYPE_NOT_EXIST.getCode());
            }
            return new RestObject(MonitoringTargetTypeVoMapper.getMonitoringTargetType(monitoringTargetType1),ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw  new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }
    }
    @RequestMapping(value = "/customer/monitor_target_type",method = RequestMethod.GET)
    public RestObject findUserAllMonitoringTargetType(JwtAuthenticationToken token, @RequestParam(value = "limit", required = false,defaultValue = "10") Integer limit,
                                                              @RequestParam(value = "offset", required = false,defaultValue = "0") Integer offset){
        UserContext context=(UserContext) token.getPrincipal();
        userChecks(context.getId());
        try {
            User user=userMapper.selectById(context.getId());
            List<MonitoringTargetType> monitoringTargetTypes=monitoringTargetTypeService.findUserMonitoringTargetTypeByCompanyId(user.getCompanyId(),limit,offset);
            if(monitoringTargetTypes==null){
                throw new UserException(null,ResultErrorCode.MONITORINGTARGETTYPE_NOT_EXIST.getValue(),ResultErrorCode.MONITORINGTARGETTYPE_NOT_EXIST.getCode());
            }
            return new RestObject(MonitoringTargetTypeVoMapper.getAllMonitoringTargetType(monitoringTargetTypes),ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
           throw  new UserException(ResultErrorCode.FEATURE_NOE_FOUND.getCode(),e.getMessage(),e.getStackTrace());
        }
    }
    @RequestMapping(value = "/customer/monitor_target_type/{id}",method = RequestMethod.GET)
    public RestObject findLoginUserMonitoringTargetTypeById(JwtAuthenticationToken token,@PathVariable("id") Integer id){
        UserContext context=(UserContext) token.getPrincipal();
        userChecks(context.getId());
        try {
            User user=userMapper.selectById(context.getId());
            MonitoringTargetType monitoringTargetType=monitoringTargetTypeService.findLoginUserMonitoringTargetTypeById(id,user.getCompanyId());
            if(monitoringTargetType==null){
               throw  new UserException(null,ResultErrorCode.MONITORINGTARGETTYPE_NOT_EXIST_IN_COMPANY.getValue(),ResultErrorCode.MONITORINGTARGETTYPE_NOT_EXIST_IN_COMPANY.getCode());
            }
            return new RestObject(MonitoringTargetTypeVoMapper.getMonitoringTargetType(monitoringTargetType),ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw new UserException(ResultErrorCode.FEATURE_NOE_FOUND.getCode(),e.getMessage(),e.getStackTrace());
        }

    }
    @RequestMapping(value = "/admin/monitor_target_type/{id}",method = RequestMethod.GET)
    public RestObject findAdminMonitoringTargetTypeById(JwtAuthenticationToken token,@PathVariable Integer id){
        UserContext context=(UserContext)token.getPrincipal();
        checks(context.getId());
        try {
            MonitoringTargetType monitoringTargetType=monitoringTargetTypeService.findAdminMonitoringTargetTypeById(id);
            if(monitoringTargetType==null){
                throw new UserException(null,ResultErrorCode.MONITORINGTARGETTYPE_NOT_EXIST.getValue(),ResultErrorCode.MONITORINGTARGETTYPE_NOT_EXIST.getCode());
            }
            return new RestObject(MonitoringTargetTypeVoMapper.getMonitoringTargetType(monitoringTargetType),ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw new UserException(ResultErrorCode.FEATURE_NOE_FOUND.getCode(),e.getMessage(),e.getStackTrace());
        }

    }
    @RequestMapping(value = "/admin/monitor_target_type/{id}",method = RequestMethod.DELETE)
    public RestObject deleteAdminMonitoringTargetTypeById(JwtAuthenticationToken token,@PathVariable Integer id){
        UserContext context=(UserContext) token.getPrincipal();
        checks(context.getId());
        try{
            if(!monitoringTargetTypeService.deleteAdminMonitoringTargetTypeById(id)){
               throw  new UserException(null,ResultErrorCode.MONITORINGTARGETTYPE_DELETE_FAIL.getValue(),ResultErrorCode.MONITORINGTARGETTYPE_DELETE_FAIL.getCode());
            }
            return new RestObject(null,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
               throw  new UserException(ResultErrorCode.DELETE_INFO_ERROR.getCode(),e.getMessage(),e.getStackTrace());
        }
    }
    @RequestMapping(value = "/admin/monitor_target_type/{id}",method = RequestMethod.PUT)
    public RestObject updateAdminMonitoringTargetTypeById(JwtAuthenticationToken token,@PathVariable Integer id,@RequestBody MonitoringTargetType monitoringTargetType){
        UserContext context=(UserContext) token.getPrincipal();
        checks(context.getId());
        try{
            if(!monitoringTargetTypeService.updateAdminMonitoringTargetTypeById(id,monitoringTargetType)){
                throw  new UserException(null,ResultErrorCode.MONITORINGTARGETTYPE_UPDATE_FAIL.getValue(),ResultErrorCode.MONITORINGTARGETTYPE_UPDATE_FAIL.getCode());
            }
            return new RestObject(null,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw new  UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }
    }
    @RequestMapping(value = "/admin/monitor_target_type/{id}/image",method = RequestMethod.PUT)
    public RestObject addMonitorTargetTypeImageById(JwtAuthenticationToken token,@PathVariable Integer id,@RequestParam(value = "profileImage") MultipartFile file){
        UserContext context=(UserContext) token.getPrincipal();
        checks(context.getId());
        try {
            MonitoringTargetType monitoringTargetType=monitoringTargetTypeService.getMonitoringTargetTypeById(id);
            if(monitoringTargetType==null){
                throw new UserException(null,ResultErrorCode.MONITORINGTARGETTYPE_NOT_EXIST.getValue(),ResultErrorCode.MONITORINGTARGETTYPE_NOT_EXIST.getCode());
            }
            String imgUrl=fileUploadService.uploadFile(file,"company"+id.toString(),"building/"+file.getName(),monitoringTargetType.getLogoUrl());
            monitoringTargetType.setLogoUrl(imgUrl);
            if(! monitoringTargetTypeService.updateMonitoringTargetType(monitoringTargetType)){
                throw  new UserException(null,ResultErrorCode.MONITORINGTARGETTYPE_UPDATE_FAIL.getValue(),ResultErrorCode.MONITORINGTARGETTYPE_UPDATE_FAIL.getCode());
            }
            return new RestObject(imgUrl,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw  new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),e.getMessage(),e.getStackTrace());
        }
    }
    @RequestMapping(value = "/admin/monitor_target_type/{monitorTargetTypeId}/measure_type",method = RequestMethod.GET)
    public RestObject getMeasureTypeByMonitorTargetTypeId(JwtAuthenticationToken token,@PathVariable(value = "monitorTargetTypeId") Integer monitorTargetTypeId){
        UserContext context=(UserContext) token.getPrincipal();
        checks(context.getId());
        try{
            List<Integer> measureTypeIds=monitoringTargetTypeService.getMeasureTypeByMonitorTargetTypeId(monitorTargetTypeId);
            if(measureTypeIds==null){
                throw  new UserException(null,ResultErrorCode.DATA_NOT_FOUND.getValue(),ResultErrorCode.DATA_NOT_FOUND.getCode());

            }
         return new RestObject(measureTypeIds,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw  new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }
    }
    @RequestMapping(value = "/admin/monitor_target_type/{monitorTargetTypeId}/measure_type",method = RequestMethod.POST)
    public RestObject addOneAndMoreMeasureTypeByMonitorTargetTypeId(JwtAuthenticationToken token,@PathVariable(value = "monitorTargetTypeId") Integer monitorTargetTypeId,@RequestBody List<Integer> measureTypeIds){
        UserContext context=(UserContext) token.getPrincipal();
        checks(context.getId());
        try{
            if(!monitoringTargetTypeService.addOneAndMoreMeasureTypeByMonitorTargetTypeId(monitorTargetTypeId,measureTypeIds)){
                return new RestObject(null,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());

            }
            throw  new UserException(null,ResultErrorCode.MONITORINGTARGETTYPE_ADD_FAIL.getValue(),ResultErrorCode.MONITORINGTARGETTYPE_ADD_FAIL.getCode());
        }catch (Exception e){
            throw new  UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }
    }
    @RequestMapping(value = "/admin/monitor_target_type/{monitorTargetTypeId}/delete/measure_type",method = RequestMethod.PUT)
    public RestObject deleteOneAndMoreMeasureTypeByMonitorTargetTypeById(JwtAuthenticationToken token,@PathVariable(value = "monitorTargetTypeId") Integer monitorTargetTypeId,@RequestBody List<Integer> measureTypeIds){
        UserContext context=(UserContext) token.getPrincipal();
        checks(context.getId());
        try{
            if(!monitoringTargetTypeService.deleteOneAndMoreMeasureTypeByMonitorTargetTypeId(monitorTargetTypeId,measureTypeIds)){
                throw new  UserException(null,ResultErrorCode.MONITORINGTARGETTYPE_ADD_FAIL.getValue(),ResultErrorCode.MONITORINGTARGETTYPE_ADD_FAIL.getCode());
            }
            return new RestObject(null,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw new  UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }
    }
    @RequestMapping(value = "/admin/monitor_target_type/{monitorTargetTypeId}/measure_rule",method = RequestMethod.GET)
    public RestObject getMeasureRuleByMonitorTargetTypeId(JwtAuthenticationToken token,@PathVariable(value = "monitorTargetTypeId") Integer monitorTargetTypeId){
        UserContext context=(UserContext) token.getPrincipal();
        checks(context.getId());
        try {
             List<MonitoringTargetTypeMeasureRule> monitoringTargetTypeMeasureRules=monitoringTargetTypeService.findmeasureRuleByMonitorTargetTypeId(monitorTargetTypeId);
             if(monitoringTargetTypeMeasureRules==null){
                 throw  new UserException(null,ResultErrorCode.DATA_NOT_FOUND.getValue(),ResultErrorCode.DATA_NOT_FOUND.getCode());
             }
             return new RestObject(MeasureRuleVoMapper.getMeasureRuleByMonitorTargetTypeId(monitoringTargetTypeMeasureRules),ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());

        }catch (Exception e){
            throw new  UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }

    }
    @RequestMapping(value = "/admin/monitor_target_type/{monitorTargetTypeId}/measure_rule",method = RequestMethod.POST)
    public RestObject addMeasureRuleByMonitorTargetType(JwtAuthenticationToken token, @PathVariable(value = "monitorTargetTypeId") Integer monitorTargetTypeId, @RequestBody MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule,@RequestBody Map<String,String> request){
        UserContext context=(UserContext) token.getPrincipal();
        checks(context.getId());
        try{
            String measureTypeName=request.get("measureTypeName");
            if(!monitoringTargetTypeService.addMeasureRuleByMonitorTargetType(monitoringTargetTypeMeasureRule,monitorTargetTypeId,measureTypeName)){
                throw  new UserException(null,ResultErrorCode.MONITORINGTARGETTYPEMEASURERULE_ADD_FAIL.getValue(),ResultErrorCode.MONITORINGTARGETTYPEMEASURERULE_ADD_FAIL.getCode());

            }

            List<MonitoringTargetTypeMeasureRule> monitoringTargetTypeMeasureRules=monitoringTargetTypeService.findmeasureRuleByMonitorTargetTypeId(monitorTargetTypeId);
            if(monitoringTargetTypeMeasureRules==null){
                throw  new UserException(null,ResultErrorCode.DATA_NOT_FOUND.getValue(),ResultErrorCode.DATA_NOT_FOUND.getCode());
            }
            return new RestObject(MeasureRuleVoMapper.getMeasureRuleByMonitorTargetTypeId(monitoringTargetTypeMeasureRules),ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw  new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }
    }
    @RequestMapping(value = "/admin/monitor_target_type/{monitorTargetTypeId}/measure_rule/{ruleId}",method = RequestMethod.DELETE)
    public RestObject deleteMonitoringTargetTypeMeasureRule(JwtAuthenticationToken token,@PathVariable("monitorTargetTypeId") Integer monitorTargetTypeId,@PathVariable("ruleId") Integer ruleId){
        UserContext context=(UserContext) token.getPrincipal();
        checks(context.getId());
        try{
            if(!monitoringTargetTypeService.deleteMonitoringTargetTypeMeasureRule(monitorTargetTypeId,ruleId)){
                throw new UserException(null,ResultErrorCode.MONITORINGTARGETTYPEMEASURERULE_NOT_EXIST_IN_COMPANY.getValue(),ResultErrorCode.MONITORINGTARGETTYPEMEASURERULE_NOT_EXIST_IN_COMPANY.getCode());

            }
           return new RestObject(null,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw  new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());
        }
    }
    @RequestMapping(value = "/admin/monitor_target_type/{monitorTargetTypeId}/measure_rule/{ruleId}",method = RequestMethod.PUT)
    public RestObject updateMonitoringTargetTypeMeasureRule(JwtAuthenticationToken token, @PathVariable("monitorTargetTypeId") Integer monitorTargetTypeId, @PathVariable("ruleId") Integer ruleId, @RequestBody MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule, @RequestBody Map<String,String> request){
        UserContext context=(UserContext) token.getPrincipal();
        checks(context.getId());
        try{
            String measureTypeName=request.get("measureTypeName");
            if(!monitoringTargetTypeService.updateMonitoringTargetTypeMeasureRule(monitorTargetTypeId,ruleId,monitoringTargetTypeMeasureRule,measureTypeName)){
                   throw  new UserException(null,ResultErrorCode.MONITORINGTARGETTYPEMEASURERULE_UPDATE_FAIL.getValue(),ResultErrorCode.MONITORINGTARGETTYPEMEASURERULE_UPDATE_FAIL.getCode());
            }
               return new RestObject(null,ResultErrorCode.SUCCESS.getValue(),ResultErrorCode.SUCCESS.getCode());
        }catch (Exception e){
            throw  new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),e.getMessage(),e.getStackTrace());

        }
    }
    private void userChecks(Integer id) {
        User user = userMapper.getUserById(id);
        List<Role> roleList = userRolesMapper.getLoginRoleIdByLoginUserId(user.getId());
        parametersAndPermissionsCheck.userCheck(ResultErrorCode.FILL_PARAMETERS.getCode(), roleList);
    }
    private void checks(Integer id) {
        User user = userMapper.getUserById(id);
        List<Role> roleList = userRolesMapper.getLoginRoleIdByLoginUserId(user.getId());
        parametersAndPermissionsCheck.adminCheck(ResultErrorCode.FILL_PARAMETERS.getCode(), roleList);
    }
}
