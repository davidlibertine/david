package com.ilabservice.intelab.rest.mapper.test;

import com.ilabservice.intelab.Application;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ilabservice.intelab.mapper.LocationRoleUserMapMapper;
import com.ilabservice.intelab.model.LocationRoleUserMap;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class LocationRoleUserMapMapperTest {
	@Autowired
	private LocationRoleUserMapMapper locationRoleUserMapMapper;
	@Test
	public void selectById()throws Exception{
		LocationRoleUserMap locationRoleUserMap=locationRoleUserMapMapper.selectById(1);
		Assert.assertNull(locationRoleUserMap);
	}
	

}
