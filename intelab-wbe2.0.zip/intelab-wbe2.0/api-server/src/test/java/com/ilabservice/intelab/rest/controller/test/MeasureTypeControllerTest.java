package com.ilabservice.intelab.rest.controller.test;


import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.model.MeasureType;
import com.ilabservice.intelab.service.MeasureTypeService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@AutoConfigureMockMvc
@Transactional
public class MeasureTypeControllerTest {

    @Resource
    private MeasureTypeService measureTypeService;

    @Test
    public void getMeasureTypeByIdTest() {
        MeasureType m = measureTypeService.getMeasureTypeById(1);
        System.out.println(m);
    }

    @Test
    public void getAllMeasureTypeTest (){
        List<MeasureType> measureTypeList = measureTypeService.getAllMeasureType();
        System.out.println(measureTypeList.size());
    }

    @Test
    public void deleteMeasureTypeByIdTest() {
        boolean b = measureTypeService.deleteMeasureTypeById(1);
        System.out.println(b);
    }

    @Test
    public void updateMeasureTypeByIdTest() {
        MeasureType measureType = new MeasureType();
        measureType.setUnit("sadsa");
        measureType.setName("11");
        measureType.setCode("aaaa");
        boolean b = measureTypeService.updateMeasureTypeById(1, measureType);
        System.out.println(b);
    }

    @Test
    public void addMeasureTypeTest() {
        MeasureType measureType = new MeasureType();
        measureType.setUnit("sadsa");
        measureType.setName("11");
        measureType.setCode("aaaa");
        boolean b = measureTypeService.addMeasureTyp(measureType);
        System.out.println(b);
    }

}
