package com.ilabservice.intelab.rest.rest;

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* HomeController Tester. 
* 
* @author <Authors name> 
* @since <pre>四月 27, 2018</pre> 
* @version 1.0 
*/ 
public class HomeControllerTest { 

@Before
public void before() throws Exception {
    // 启用测试之前 比如需要连接数据库等

} 

@After
public void after() throws Exception {

} 

/** 
* 
* Method: index() 
* 
*/ 
@Test
public void testIndex() throws Exception {
//TODO: Test goes here...

}


} 
