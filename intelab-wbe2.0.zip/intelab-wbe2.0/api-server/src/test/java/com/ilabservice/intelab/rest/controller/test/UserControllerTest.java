package com.ilabservice.intelab.rest.controller.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.*;
import com.ilabservice.intelab.model.*;
import com.ilabservice.intelab.service.UserService;
import com.ilabservice.intelab.utils.MD5Utils;
import com.ilabservice.intelab.vo.LoginUserRolesVo;
import com.ilabservice.intelab.vo.UserVo;
import com.ilabservice.intelab.vo.assemblyvo.UserVoMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@AutoConfigureMockMvc
@Transactional
public class UserControllerTest {

    @Resource
    private UserService userService;

    @Resource
    private UserLocationMonitoringTargetMapper userLocationMonitoringTargetMapper;

    @Resource
    private LocationRoleUserMapMapper locationRoleUserMapMapper;

    @Resource
    private ResourceTypeRoleUserMapMapper resourceTypeRoleUserMapMapper;

    @Resource
    private LeaseRecordMapper leaseRecordMapper;

    @Resource
    private MonitoringTargetMapper monitoringTargetMapper;

    @Resource
    private ResourceRoleUserMapMapper resourceRoleUserMapMapper;

    @Test
    public void addUserTest() {
       User user = new User();
       user.setCompanyId(1);
       user.setUserName("zczxc");
       user.setPassword(MD5Utils.md5Encode("1234567", "utf-8"));
       user.setName("sj");
       user.setHeadIcon("waszzzz");
       user.setMobile("123123213213213213");
       user.setTelephone("123213123123123213");
       user.setGender("111");
       user.setEmail("asdasd@qq.com");
       user.setDepartment("asdasdsdsa");
       user.setJob("1");
       user.setJobNumber("1");
       user.setBindEmail(1);
       user.setBindMobile(1);
       user.setVerify(1);
       user.setCreateDatetime(new Date());
       user.setUpdateDatetime(new Date());
       user.setLastPasswordErrorDate(new Date());
       user.setLatestPasswordUpdateTime(new Date());
       user.setPasswordErrorRetryTimes(1);
       user.setAlertNotificationType(1);
       user.setBlockChainAddress("1");
        try {
            Map<String ,Object> map = userService.addUserForCompany(user, 1);
            if(map.size() > 0) {
                UserVo userVo = UserVoMapper.getUserVoByUserModelAndCompanyModel((User) map.get("userInfo"), (Company) map.get("company"));
            }
            /**
             * 如果为空，返回服务器处理错误，状态为500
             */
            throw new UserException(ResultErrorCode.SERVER_PROCESSING_ERROR.getCode(),
                    ResultErrorCode.SERVER_PROCESSING_ERROR.getValue(), null);
        } catch (Exception e) {
            /**
             * 系统异常
             */
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(),
                    ResultErrorCode.SYSTEM_INNER_ERROR.getValue(), null);
        }
    }

    @Test
    public void getUserByUserId() {
        Map<String, Object> map = userService.getUserInfoByUserId(3);
        if(map.size() > 0) {
            UserVo userVo = UserVoMapper.getUserVoByUserModelAndCompanyModel((User) map.get("userInfo"), (Company) map.get("company"));
            System.out.println(userVo);
        }
    }

    @Test
    public void delectUserById() {
        //TODO :等待重新确认删除逻辑，还未完成
    }

    @Test
    public void updateUserInfoById() {
        User user = new User();
        user.setCompanyId(1);
        user.setUserName("zczxc");
        user.setPassword(MD5Utils.md5Encode("1234567", "utf-8"));
        user.setName("sj");
        user.setHeadIcon("waszzzz");
        user.setMobile("zxczxczxczxc");
        user.setTelephone("zxczczxc");
        user.setGender("111");
        user.setEmail("asdasd@qq.com");
        user.setDepartment("asdasdsdsa");
        user.setJob("1");
        user.setJobNumber("1");
        user.setBindEmail(1);
        user.setBindMobile(1);
        user.setVerify(1);
        user.setCreateDatetime(new Date());
        user.setUpdateDatetime(new Date());
        user.setLastPasswordErrorDate(new Date());
        user.setLatestPasswordUpdateTime(new Date());
        user.setPasswordErrorRetryTimes(1);
        user.setAlertNotificationType(1);
        user.setBlockChainAddress("1");
        Map<String, Object> map = userService.updateUserInfoById(2, user, 1);
    }

    @Test
    public void addRoleToSpecifiedUserTest() {
        userService.addRoleToSpecifiedUser(1, 1);
    }

    @Test
    public void deleteRoleToSpecifiedUser() {
        boolean deleteRoleToSpecifiedUserExit = userService.deleteRoleToSpecifiedUser(1, 1);
        System.out.println(deleteRoleToSpecifiedUserExit);
    }

    @Test
    public void test1() {
        List<LoginUserRolesVo> loginUserRolesVoList = userService.getLoginUserRolesAndPermissions(1);
        System.out.println(loginUserRolesVoList);
    }

    @Test
    public void delectUser() {
        UserLocationMonitoringTarget userLocationMonitoringTarget = userLocationMonitoringTargetMapper.selectByUserId(1);
        LocationRoleUserMap locationRoleUserMap = locationRoleUserMapMapper.selectByUserId(1);
        ResourceTypeRoleUserMap resourceTypeRoleUserMap = resourceTypeRoleUserMapMapper.selectByUserId(1);
        LeaseRecord leaseRecord = leaseRecordMapper.selectByUserId(1);
        MonitoringTarget monitoringTarget = monitoringTargetMapper.selectByUserId(1);
        ResourceRoleUserMap resourceRoleUserMap = resourceRoleUserMapMapper.selectByUserId(1);
    }
}
