package com.ilabservice.intelab.rest.service.test;


import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.storage.FileUploadService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.multipart.MultipartFile;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
public class FileUploadTest {
    @Qualifier("FileStorageService")
    @Autowired
    FileUploadService fileUploadService;

    @Test
    public void testAzureFileUpload(){

        MultipartFile multipartFile = new MockMultipartFile("test", "hello uploader".getBytes());

        System.out.println(fileUploadService.uploadFile(multipartFile, "test", "test_blob", null));
    }

}
