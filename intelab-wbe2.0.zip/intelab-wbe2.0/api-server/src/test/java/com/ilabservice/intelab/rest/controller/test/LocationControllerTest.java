package com.ilabservice.intelab.rest.controller.test;


import com.alibaba.fastjson.JSON;
import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.controller.secure.LocationController;
import com.ilabservice.intelab.mapper.MonitoringTargetMapper;
import com.ilabservice.intelab.mapper.UserLocationMonitoringTargetMapper;
import com.ilabservice.intelab.model.Location;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.service.LocationService;
import com.ilabservice.intelab.vo.LocationVo;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.request.RequestPostProcessor;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@AutoConfigureMockMvc
@Transactional
public class LocationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private LocationController locationController;

    @Autowired
    private LocationService locationService;

    @Autowired
    private MonitoringTargetMapper monitoringTargetMapper;

    @Autowired
    private UserLocationMonitoringTargetMapper userLocationMonitoringTargetMapper;

    @Test
    public void testGetRootLocationsByCompanyId(){
    }

    @Test
    public void testUpdateLocation(){
        Location location = locationService.getRootLocationsByCompanyId(1);
        Location newLocation = new Location();
        newLocation.setName("test location");
        newLocation.setXLocation(5f);
        RestObject returnLocation = locationController.updateLocation(null, location.getId(), newLocation);
    }

    @Test
    public void testDeleteLocation(){
        try{
            MvcResult mvcResult = mockMvc.perform(post("/api/unsecure/login")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"username\":\"sample_platform_manager@ILAB\", " +
                            "\"password\":\"test1234\"}"))
                    .andReturn();
            Map userTokenResponse =  JSON.parseObject(mvcResult.getResponse().getContentAsString());

            mockMvc.perform(delete("/api/secure/customer/location/2")
                    .header("X-Authorization",
                            "Bearer " + ((Map)userTokenResponse.get("data")).get("token")))
                    .andExpect(status().isOk());

            Assert.assertEquals(locationService.getLocationById(1).getIsLeaf().intValue(), 1);
            Assert.assertNull(monitoringTargetMapper.selectById(2).getLocationId());
            Assert.assertNull(userLocationMonitoringTargetMapper.selectById(1));

        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    @Test
    public void testGetLocation(){
        try {
            MvcResult mvcResult = mockMvc.perform(post("/api/unsecure/login")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"username\":\"administrator@ILAB\", " +
                            "\"password\":\"test1234\"}"))
                    .andReturn();
            Map userTokenResponse =  JSON.parseObject(mvcResult.getResponse().getContentAsString());

            mvcResult = mockMvc.perform(get("/api/secure/customer/location/1")
                    .header("X-Authorization",
                            "Bearer " + ((Map)userTokenResponse.get("data")).get("token")))
                    .andReturn();

            LocationVo result = JSON.parseObject(
                                    JSON.parseObject(
                                            mvcResult.getResponse().getContentAsString()).get("data").toString(),
                                    LocationVo.class);
            Assert.assertEquals(result.getId().intValue(), 1);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    @Test
    public void testUpdateLocationBackground(){
        try {
            MvcResult mvcResult = mockMvc.perform(post("/api/unsecure/login")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"username\":\"sample_platform_manager@ILAB\", " +
                            "\"password\":\"test1234\"}"))
                    .andReturn();
            Map userTokenResponse = JSON.parseObject(mvcResult.getResponse().getContentAsString());

            MockMultipartFile demoFile = new MockMultipartFile("profileImage", "filename.txt",
                    "text/plain", "some xml".getBytes());


            MockMultipartHttpServletRequestBuilder builder =
                    MockMvcRequestBuilders.fileUpload("/api/secure/customer/location/2/background");
            builder.with(new RequestPostProcessor() {
                @Override
                public MockHttpServletRequest postProcessRequest(MockHttpServletRequest request) {
                    request.setMethod("PUT");
                    return request;
                }
            });

            mvcResult = mockMvc.perform(builder
                    .file(demoFile)
                    .header("X-Authorization",
                            "Bearer " + ((Map) userTokenResponse.get("data")).get("token")))
                    .andDo(print())
                    .andExpect(status().isOk())
                    .andReturn();

            Assert.assertNotNull(JSON.parseObject(mvcResult.getResponse().getContentAsString()).get("data").toString());
        }
        catch(Exception e){
            e.printStackTrace();
            Assert.assertEquals(false, true);
        }

    }


    @Test
    public void testCreateAndUpdateLocation(){
        Location location =  new Location();
        location.setName("test create location");
        location.setLocationType("planet");
        location.setParentId(7);
        location.setName("test planet");

        try {
            MvcResult mvcResult = mockMvc.perform(post("/api/unsecure/login")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"username\":\"sample_platform_manager@ILAB\", " +
                            "\"password\":\"test1234\"}"))
                    .andReturn();
            Map userTokenResponse = JSON.parseObject(mvcResult.getResponse().getContentAsString());

            MockMultipartFile demoFile = new MockMultipartFile("profileImage", "filename.txt",
                    "text/plain", "some xml".getBytes());

            mvcResult = mockMvc.perform(fileUpload("/api/secure/customer/location")
                    .file(demoFile)
                    .param("location", JSON.toJSONString(location))
                    .header("X-Authorization",
                            "Bearer " + ((Map) userTokenResponse.get("data")).get("token")))
                    .andExpect(status().isOk())
                    .andReturn();
            LocationVo result = JSON.parseObject(
                    JSON.parseObject(
                            mvcResult.getResponse().getContentAsString()).get("data").toString(),
                    LocationVo.class
            );
            Assert.assertNotNull(result.getBackground());

            mvcResult = mockMvc.perform(put("/api/secure/customer/location/" + result.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content("{\"name\":\"test update location\"}")
                    .header("X-Authorization",
                            "Bearer " + ((Map) userTokenResponse.get("data")).get("token")))
                    .andExpect(status().isOk())
                    .andReturn();
            result = JSON.parseObject(
                    JSON.parseObject(mvcResult.getResponse().getContentAsString()).get("data").toString(),
                    LocationVo.class
            );

            Assert.assertEquals(result.getName(), "test update location");

        }
        catch(Exception e){
            e.printStackTrace();
            Assert.assertEquals(false, true);
        }

    }
}
