package com.ilabservice.intelab.rest.mapper.test;


import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.model.User;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class UserRolesMapTest {
    @Autowired
    UserRolesMapper userRolesMapper;

    @Autowired
    UserMapper userMapper;

    @Test
    public void testDeleteUserRolesMap(){
        User user = userMapper.getUserById(1);
        userRolesMapper.deleteById(user.getRoles().get(0).getId());
        user = userMapper.getUserById(1);
        Assert.assertTrue(user.getRoles().isEmpty());
    }
}
