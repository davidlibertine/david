package com.ilabservice.intelab.rest.mapper.test;

import com.ilabservice.intelab.Application;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ilabservice.intelab.mapper.CompanyContractMapper;
import com.ilabservice.intelab.model.CompanyContract;

import java.util.Date;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class CompanyContractMapperTest {
	@Autowired
	private CompanyContractMapper companyContractMapper;
	@Test
	public void testCreateCompanyContract(){
		CompanyContract companyContract=new CompanyContract();
		companyContract.setStartDate(new Date());
		companyContract.setEndDate(new Date());
		companyContract.setSignDate(new Date());
		companyContract.setCompanyId(1);
		companyContract.setDescription("公司协议");
//		companyContractMapper.addCompanyContract(companyContract);
//		System.out.println(companyContractMapper.addCompanyContract(companyContract));
		companyContractMapper.addCompanyContract(companyContract);
	}
	@Test
	public  void testSelect(){
		System.out.println(companyContractMapper.selectById(3));
	}



}
