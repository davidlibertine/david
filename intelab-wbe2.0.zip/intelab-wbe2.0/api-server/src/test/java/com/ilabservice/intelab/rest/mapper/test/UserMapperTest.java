package com.ilabservice.intelab.rest.mapper.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.CompanyMapper;
import com.ilabservice.intelab.mapper.RolePermissionMapMapper;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.model.User;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.service.UserService;
import org.apache.commons.lang.StringUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class UserMapperTest {

    @Autowired
    UserMapper userMapper;

    @Resource
    private UserService userService;

    @Resource
    private CompanyMapper companyMapper;

    @Resource
    private UserRolesMapper userRolesMapper;

    @Resource
    private RolePermissionMapMapper rolePermissionMapMapper;

    @Before
    public void before() throws Exception {
    }

    @After
    public void after() throws Exception {
    }

    @Test
    public void testGetUserWithRoleAndPermissionsByUserID() throws Exception {
        User user = userMapper.getUserById(2);
        Assert.assertNotNull(user);
        Assert.assertNotNull(user.getRoles());
        Assert.assertNotNull(user.getRoles().get(0).getPermissions());
    }

    @Test
    public void testDeleteByUserId(){
        userMapper.deleteById(2);
        Assert.assertNull(userMapper.getUserById(2));
    }

    @Test
    public void testGetCompanyByUserId(){
        User user = userMapper.getUserById(2);
        Assert.assertNotNull(user.getCompany());
    }

    @Test
    public void testGetLoginUserList() {
//        try {
//            User user = userService.getUserInfoByUserId(1);
//            UserVo userVo = UserVoMapper.getUserVoList(user, companyMapper.selectById(user.getCompanyId()));
//            if(userVo == null) {
//                System.out.println("xxxxxxx");
//            }
//        } catch (Exception e) {
//            /**
//             * 此處分別打印狀態碼，異常信息，以及具體的堆棧信息
//             */
//            System.out.println("error:" + e.getMessage());
//            System.out.println("errorStack:" + e.getStackTrace());
//            throw new UserException(500, e.getMessage(), null);
//        }
    }

//    @Test
//    public void testUpdateUseInfoReturnNewUserInfo() {
//        User user = new User();
//        user.setId(1);
//        user.setName("奧特曼打怪獸");
//        User users = userService.updateOldUserInfoReturnNewUserInfo(user.);
//        if(user == null) {
//            System.out.println("xxxxxx");
//        }
//        System.out.println(user.getName());
//    }

    @Test
    public void updateLoginUserHeadIcon() {
        try {
            /**
             * 更新后需要返回新的頭像路徑
             */
            String newImgUrl = userService.updateLoginUserHeadIcon(1, "file://xxxx");
            if(StringUtils.isEmpty(newImgUrl)) {
                throw new UserException(ResultErrorCode.UPDATE_USER_HEAD_ICON_FAIL.getCode(), ResultErrorCode.UPDATE_USER_HEAD_ICON_FAIL.getValue(), null);
            }
            new RestObject(newImgUrl, ResultErrorCode.SUCCESS.getValue(), ResultErrorCode.SUCCESS.getCode());
        } catch (UserException e) {
            throw new UserException(ResultErrorCode.SYSTEM_INNER_ERROR.getCode(), e.getMessage(), e.getStackTrace());
        }
    }

    @Test
    public void updateUserPassword() {
        userService.updateLoginUserPassword(1, "xxxx");
    }

    @Test
    public void getUserInfoByCompanyId() {
        userService.getLoginUserCompanyUser(1, 15, 1);
    }
}
