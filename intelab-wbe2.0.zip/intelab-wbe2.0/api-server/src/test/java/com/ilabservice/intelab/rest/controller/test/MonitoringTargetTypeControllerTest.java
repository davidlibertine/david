package com.ilabservice.intelab.rest.controller.test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.controller.secure.MonitoringTargetTypeController;
import org.apache.commons.collections.bag.SynchronizedSortedBag;
import org.apache.tomcat.util.http.fileupload.FileUpload;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.access.method.P;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.request.RequestPostProcessor;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class MonitoringTargetTypeControllerTest {
    @Autowired
    MonitoringTargetTypeController monitoringTargetTypeController;
    private MockMvc mockMvc;
    @Autowired
    private WebApplicationContext context;
    @Before
    public void setUp(){
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }
    @Test
    public void findAdminListAllMonitoringTargetType(){
        try {
            MvcResult result=mockMvc.perform(get("/api/secure/admin/monitor_target_type")
                    .param("limit","4")
                    .param("offset","0")).andReturn();
            System.out.println(result.getResponse().getContentAsString());
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Test
    public void addMonitoringTargetType(){
        try {
            Integer measureTypes[]={1,2};
            MvcResult mvcResult=mockMvc.perform(post("/api/secure/admin/monitor_target_type")

            .param("name","123")
            .param("companyId","1")
            .param("description","123")
            .param("list","1,2")
            ).andExpect(status().isOk()).andReturn();
            Map userTokenResponse = JSON.parseObject(mvcResult.getResponse().getContentAsString());
            MockMultipartFile demoFile = new MockMultipartFile("profileImage", "filename.txt",
                    "text/plain", "some xml".getBytes());
            MockMultipartHttpServletRequestBuilder builder =
                    fileUpload("/api/secure/admin/monitor_target_type");
            builder.with(new RequestPostProcessor() {
                @Override
                public MockHttpServletRequest postProcessRequest(MockHttpServletRequest request) {
                    request.setMethod("POST");
                    return request;
                }
            });
            mvcResult=mockMvc.perform(builder
            .file(demoFile).contentType(MediaType.MULTIPART_FORM_DATA)
                   ).andReturn();
         System.out.println(mvcResult.getResponse().getContentAsString());
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Test
    public void findUserAllMonitoringTargetType(){
        try{
           MvcResult result=mockMvc.perform(get("/api/secure/customer/monitor_target_type").param("limit","4")
           .param("offset","0")).andReturn();
           System.out.println(result.getResponse().getContentAsString());
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Test
    public void findLoginUserMonitoringTargetTypeById(){
        try {
             MvcResult result=mockMvc.perform(get("/api/secure/admin/monitor_target_type/1")).andExpect(status().isOk()).andReturn();
             System.out.println(result.getResponse().getContentAsString());
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Test
    public void deleteAdminMonitoringTargetTypeById(){
        try {
            MvcResult result=mockMvc.perform(delete("/api/secure//admin/monitor_target_type/1"))
                    .andExpect(status().isOk()).andReturn();
            System.out.println(result.getResponse().getContentAsString());

        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Test
    public void updateAdminMonitoringTargetTypeById(){

    }
    @Test
    public void addMonitorTargetTypeImageById(){
        try {
            MockMultipartFile demoFile = new MockMultipartFile("profileImage", "filename.txt",
                    "text/plain", "some xml".getBytes());
//             MvcResult mvcResult=mockMvc.perform(fileUpload("/api/secure/admin/monitor_target_type/1/image").
//             .file(demoFile)).andExpect(status().isOk()).andReturn();

            MockMultipartHttpServletRequestBuilder builder =
                    fileUpload("/api/secure/admin/monitor_target_type/1/image");
            builder.with(new RequestPostProcessor() {
                @Override
                public MockHttpServletRequest postProcessRequest(MockHttpServletRequest request) {
                    request.setMethod("PUT");
                    return request;
                }
            });
           MvcResult mvcResult=mockMvc.perform(builder
                    .file(demoFile)).andReturn();
             System.out.println(mvcResult.getResponse().getContentAsString());
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Test
    public void getMeasureTypeByMonitorTargetTypeId(){
        try {
            MvcResult result=mockMvc.perform(get("/api/secure/admin/monitor_target_type/1/measure_type"))
                    .andExpect(status().isOk()).andReturn();
            System.out.println(result.getResponse().getContentAsString());

        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Test
    public void addOneAndMoreMeasureTypeByMonitorTargetTypeId(){
        try{
            Integer[] measureTypeIds={1,2};
            MvcResult result=mockMvc.perform(post("/api/secure/admin/monitor_target_type/1/measure_type")
            .contentType(MediaType.APPLICATION_JSON)
                    .content(JSON.toJSONString(measureTypeIds))
           )
                    .andExpect(status().isOk()).andReturn();
            System.out.println(result.getResponse().getContentAsString());

        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Test
    public void deleteOneAndMoreMeasureTypeByMonitorTargetTypeById()throws Exception{
        Integer[] measureTypeIds={1,2};
        MvcResult mvcResult=mockMvc.perform(put("/api/secure/admin/monitor_target_type/1/delete/measure_type")
        .contentType(MediaType.APPLICATION_JSON)
        .content(JSON.toJSONString(measureTypeIds))).andReturn();
        System.out.println(mvcResult.getResponse().getContentAsString());


    }
    @Test
    public void getMeasureRuleByMonitorTargetTypeId() throws Exception{
        MvcResult result=mockMvc.perform(get("/api/secure/admin/monitor_target_type/1/measure_rule"))
                .andReturn();
        System.out.println(result.getResponse().getContentAsString());

    }
    @Test
    public void addMeasureRuleByMonitorTargetType()throws Exception{
        MvcResult result=mockMvc.perform(post("/api/secure/admin/monitor_target_type/1/measure_rule")
        .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
        .content("{\"measureTypeName\":\"温度\",\"name\":\"123\",\"definition\":\"123\"}"))
                .andExpect(status().isOk()).andReturn();
        System.out.println(result.getResponse().getContentAsString());
    }
    @Test
    public void deleteMonitoringTargetTypeMeasureRule()throws Exception{
        MvcResult result=mockMvc.perform(delete("/api/secure/admin/monitor_target_type/1/measure_rule/1"))
                .andReturn();
        System.out.println(result.getResponse().getContentAsString());

    }
    @Test
    public  void updateMonitoringTargetTypeMeasureRule(){
        try {
            MvcResult result=mockMvc.perform(put("/api/secure/admin/monitor_target_type/1/measure_rule/1")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content("{\"measureTypeName\":\"温度\",\"name\":\"123\",\"definition\":\"123\"}"))
                    .andReturn();
            System.out.println(result.getResponse().getContentAsString());
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
