package com.ilabservice.intelab.rest.mapper.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.mapper.LabDeviceMapper;
import com.ilabservice.intelab.model.LabDevice;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
@SpringBootTest(classes = Application.class)
public class LabDeviceMapperTest {
    @Autowired
    LabDeviceMapper labDeviceMapper;
    @Test
    public void test(){
        List<Integer> dis=new ArrayList<>();
        dis.add(1);
        dis.add(2);
        List<LabDevice> labDevices=labDeviceMapper.selectBatchIds(dis);
        System.out.println(labDevices);
    }
    @Test
    public void findLabDeviceByExample(){
        List<Integer> labDeviceIds=new ArrayList<>();
        labDeviceIds.add(1);
        labDeviceIds.add(2);
        labDeviceIds.add(3);
        LabDevice labDevice=new LabDevice();
        labDevice.setBrand("123");
        Map<String,Object> map=new HashMap<>();
        map.put("labDevice",labDevice);
        map.put("limit",1);
        map.put("offset",0);
        map.put("labDeviceIds",labDeviceIds);
        List<LabDevice> labDevices=labDeviceMapper.findLabDeviceByExample(map);
        System.out.println(labDevices);
    }
    @Test
    public void findCountByExample(){
        LabDevice labDevice=new LabDevice();
        labDevice.setBrand("123");
        Integer count=labDeviceMapper.findCountByExample(labDevice);
        System.out.println(count);
    }
}
