package com.ilabservice.intelab.rest.mapper.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.mapper.RoleMapper;
import com.ilabservice.intelab.mapper.RolePermissionMapMapper;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.RolePermissionMap;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class RolePermissionMapMapperTest {

    @Autowired
    RolePermissionMapMapper rolePermissionMapMapper;

    @Autowired
    RoleMapper roleMapper;

    @Test
    public void testRolePermissionMapDelete(){
        Role role = roleMapper.getRoleById(4);
        int old_permissions_size = role.getPermissions().size();
        System.out.println(role.getPermissions());
        rolePermissionMapMapper.deleteById(role.getPermissions().get(1));

        role = roleMapper.getRoleById(4);
        int new_permissions_size = role.getPermissions().size();
        Assert.assertEquals(old_permissions_size-1, new_permissions_size);

    }

    @Test
    public void test() {
        RolePermissionMap rolePermissionMap = rolePermissionMapMapper.selectById(1);
        Assert.assertNotNull(rolePermissionMap);
        Assert.assertNotNull(rolePermissionMap.getPermission().getId());
        Assert.assertNotNull(rolePermissionMap.getRole().getId());
    }
}
