package com.ilabservice.intelab.rest.rest;//package com.ilabservice.intelab.rest;
//
//import com.alibaba.fastjson.JSONObject;
//import com.ilabservice.intelab.Application;
//import com.ilabservice.intelab.service.UserService;
//import org.junit.Assert;
//import org.junit.Test;
//import org.junit.Before;
//import org.junit.After;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.test.SpringApplicationConfiguration;
//import org.springframework.boot.test.TestRestTemplate;
//import org.springframework.boot.test.WebIntegrationTest;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.util.LinkedMultiValueMap;
//import org.springframework.util.MultiValueMap;
//import org.springframework.web.client.RestTemplate;
//
///**
//* LoginUserController Tester.
//*
//* @author <Authors name>
//* @since <pre>四月 27, 2018</pre>
//* @version 1.0
//*/
//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringApplicationConfiguration(classes = Application.class)
////@WebAppConfiguration
//@WebIntegrationTest("server.port:0")// 使用0表示端口号随机，也可以具体指定如8888这样的固定端口
//public class LoginUserControllerTest {
//
//    private RestTemplate template = new TestRestTemplate();
//
//    @Autowired
//    UserService userService;
//
//    @Value("${local.server.port}")// 注入端口号
//    private int port;
//
//
//@Before
//public void before() throws Exception {
//
//}
//
//@After
//public void after() throws Exception {
//}

/** 
* 
* Method: page(@RequestParam(value = "size", required = false,defaultValue = "10") Integer size, @RequestParam(value = "current", required = false,defaultValue = "0") Integer current) 
* 
*/ 
//@Test
//public void testPage() throws Exception {
////TODO: Test goes here...
//    String url = "http://localhost:"+port+"/loginUser/page";
//    MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
//    map.add("size", "10");
//    map.add("current", "1");
//    String result = template.getForObject(url, String.class,map );
//    JSONObject jsonObject = JSONObject.parseObject(result);
//    System.out.println(jsonObject);
//    Assert.assertNotNull(jsonObject.getJSONObject("data"));
//}
//
///**
//*
//* Method: get(@PathVariable Serializable id)
//*
//*/
//@Test
//public void testGet() throws Exception {
////TODO: Test goes here...
//    String url = "http://localhost:"+port+"/loginUser/1";
//    MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
//    //map.add("id", "1");
//    String result = template.getForObject(url, String.class,map );
//    System.out.println(result);
//    JSONObject jsonObject = JSONObject.parseObject(result);
//    System.out.println(jsonObject);
//    Assert.assertNotNull(jsonObject.getJSONObject("data"));
//}
//
///**
//*
//* Method: getUserRoleAndPermissions(@PathVariable("id") Integer id)
//*
//*/
//@Test
//public void testGetUserRoleAndPermissions() throws Exception {
////TODO: Test goes here...
//    String url = "http://localhost:"+port+"/loginUser/getUserRoleAndPermissions/1";
//    MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
//    //map.add("id", "1");
//    String result = template.getForObject(url, String.class,map );
//    System.out.println(result);
//    JSONObject jsonObject = JSONObject.parseObject(result);
//    System.out.println(jsonObject);
//    Assert.assertNotNull(jsonObject.getJSONObject("data"));
//}


//}
