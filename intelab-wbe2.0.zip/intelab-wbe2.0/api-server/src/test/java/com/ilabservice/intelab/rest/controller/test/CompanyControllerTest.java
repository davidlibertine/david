package com.ilabservice.intelab.rest.controller.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.fileUpload;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.alibaba.fastjson.JSON;
import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.model.CompanyExtend;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.security.auth.JwtAuthenticationToken;
import com.ilabservice.intelab.vo.CompanyVo;
import org.apache.commons.collections.bag.SynchronizedSortedBag;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.request.RequestPostProcessor;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.ilabservice.intelab.common.ObjectRestResponse;
import com.ilabservice.intelab.common.TableResultResponse;
import com.ilabservice.intelab.controller.secure.CompanyController;
import com.ilabservice.intelab.vo.CompanyContractVo;

import org.junit.Assert;
import org.junit.Before;

import java.math.BigDecimal;
import java.util.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@AutoConfigureMockMvc
@Transactional
public class CompanyControllerTest {
    @Autowired
    private CompanyController companyController;
    private MockMvc mockMvc;
    @Autowired
    private WebApplicationContext context;
    @Before
    public void setUp(){
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }
	@Test
	public void testGetLoginUserCompanyAndExtraFeatures() {
		JwtAuthenticationToken token=null;
		companyController.getLoginUserCompanyAndExtraFeatures(token);
	}

	@Test
	public void testGetAdminCompanyPage() {
		TableResultResponse tableResultResponse=companyController.getAdminCompanyPage(null, 10, 0);
		Assert.assertNotNull(tableResultResponse.getData());
	}

	@Test
	public void testFindListCompanyContractByCompanyId() {
		RestObject objectRestResponse=companyController.findListCompanyContractByCompanyId(null,1);
		System.out.println(objectRestResponse.getData());
		//Assert.assertNotNull(objectRestResponse.getData());
	    //Assert.assertEquals(((List<CompanyContract>)objectRestResponse.getData()).get(0).getId().intValue(),9);
	}

	@Test
	public void testAddCompanyContract() {
		CompanyContractVo companyContractvo=new CompanyContractVo();
		companyContractvo.setDescription("123");
		companyContractvo.setStartDate(123457890L);
		companyContractvo.setEndDate(12234L);
		companyContractvo.setCompanyId(1);
		//RestObject objectRestResponse=companyController.addCompanyContract(null,1, companyContractvo);
		//System.out.println(objectRestResponse.getData());
		//Assert.assertEquals(((CompanyContractVo)objectRestResponse.getData()).getDescription(),"123");
		try {
		MvcResult result=mockMvc.perform(MockMvcRequestBuilders.post("/api/secure/admin/company/1/contract")
                    .contentType(MediaType.APPLICATION_JSON).content("{\"startDate\":\"123456\", " +
                            "\"endDate\":\"112344\",\"description\":\"123\"}").
                    accept(MediaType.APPLICATION_JSON))
				    .andExpect(status().isOk())
                    .andReturn();
                   System.out.println(result.getResponse().getContentAsString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Test
	public void testUpdateCompanyContract() {
		CompanyContractVo companyContractVo=new CompanyContractVo();
		companyContractVo.setCompanyId(1);
		companyContractVo.setStartDate(123457890L);
		companyContractVo.setEndDate(12234L);
		companyContractVo.setSignDate(12345L);
		companyContractVo.setDescription("公司协议");
		companyContractVo.setId(1);
		try {
			MvcResult result=mockMvc.perform(MockMvcRequestBuilders.put("/api/secure/admin/company/1/contract/1")
					.contentType(MediaType.APPLICATION_JSON)
					.accept(MediaType.APPLICATION_JSON)
			        .content("{\"startDate\":\"123456\",\"endDate\":\"112344\"}"))
					.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();

			System.out.println(result.getResponse().getContentAsString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		//RestObject objectRestResponse=companyController.updateCompanyContract(null,companyContractVo.getCompanyId(),companyContractVo.getId(), companyContractVo);
	   // System.out.println(objectRestResponse.getData());
	}

	@Test
	public void testCreateCompanyLogo() throws Exception {
		MockMultipartFile demoFile = new MockMultipartFile("logo", "filename.txt",
				"text/plain", "some xml".getBytes());
		MvcResult result=mockMvc.perform(fileUpload("/api/secure/admin/company/1/logo")
				.file(demoFile)

		).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();


	}
	

	@Test
	public void testUpdateCompanyLogo() throws  Exception{

		MockMultipartFile demoFile = new MockMultipartFile("logo", "filename.txt",
				"text/plain", "some xml".getBytes());
        MockMultipartHttpServletRequestBuilder builder=MockMvcRequestBuilders.fileUpload("/api/secure/admin/company/1/logo");
        builder.with(new RequestPostProcessor() {
			@Override
			public MockHttpServletRequest postProcessRequest(MockHttpServletRequest request) {
				request.setMethod("PUT");
				return request;
			}
		});
        MvcResult  mvcResult = mockMvc.perform(builder
						.file(demoFile)).andExpect(status().isOk()).andReturn();
//	MvcResult result=mockMvc.perform(fileUpload("/api/secure/admin/company/1/logo")
//				.file(demoFile)
//		).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
       System.out.println(mvcResult.getResponse().getContentAsString());
	}
	@Test
	public void testCreateCompanyInfo()throws Exception{
		CompanyExtend companyVo=new CompanyExtend();
		companyVo.setName("释普科技");
		companyVo.setAddress("上海");
		companyVo.setEmail("1235@163.com");
		companyVo.setDomainName("ilabservice");
		companyVo.setTelephone("12345678901");
		companyVo.setLongitude(new BigDecimal(123));
		companyVo.setLatitude(new BigDecimal(123));
		companyVo.setManagerName("王五");
		companyVo.setManagerLoginUsername("赵柳");
		companyVo.setLocationName("room");
        List<Integer> extraFeasture=new ArrayList<>();
        extraFeasture.add(1);
		MockMultipartFile demoFile = new MockMultipartFile("campusImage", "filename.txt",
				"text/plain", "some xml".getBytes());
		MvcResult result=mockMvc.perform(post("/api/secure/admin/company").param("name","123").param("extraFeasture[]","")).andExpect(status().isOk()).andReturn();
// result=mockMvc.perform(fileUpload("/api/secure/admin/company")
//	.file(demoFile)).andExpect(status().isOk()).andReturn();
//		List<Integer> featureIdList=new ArrayList<>();
//		featureIdList.add(1);
		RestObject restObject=companyController.createCompanyInfo(null,demoFile,extraFeasture,companyVo);
		System.out.println(restObject);
	}
	@Test
	public void updateCOmpanyInfoTest(){
		try {
			MockMultipartFile demoFile = new MockMultipartFile("campusImage", "filename.txt",
					"text/plain", "some xml".getBytes());
			MvcResult result=mockMvc.perform(put("/api/secure/admin/company/1")

					.param("name","123")
			.param("domainName","123")
					.param("campusImage","")
			).andExpect(status().isOk()).andReturn();
			MockMultipartHttpServletRequestBuilder builder=MockMvcRequestBuilders.fileUpload("/api/secure/admin/company/1/logo");
			builder.with(new RequestPostProcessor() {
				@Override
				public MockHttpServletRequest postProcessRequest(MockHttpServletRequest request) {
					request.setMethod("PUT");
					return request;
				}
			});
			MvcResult  mvcResult = mockMvc.perform(builder
					.file(demoFile)).andExpect(status().isOk()).andReturn();
			System.out.println(result.getResponse().getContentAsString());
		}catch (Exception e){
			e.printStackTrace();
		}
	}

}
