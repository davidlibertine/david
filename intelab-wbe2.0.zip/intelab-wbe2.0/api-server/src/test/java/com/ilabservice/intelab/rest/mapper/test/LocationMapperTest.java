package com.ilabservice.intelab.rest.mapper.test;

import static org.junit.Assert.*;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.model.MonitoringTarget;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ilabservice.intelab.mapper.LocationMapper;
import com.ilabservice.intelab.model.Location;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class LocationMapperTest {
	@Autowired
	private LocationMapper locationMapper;

	@Test
	public void testFindLocationByUserId() {
		Location location=locationMapper.findLocationByUserId(1);
		Assert.assertNull(location);
		fail("Not yet implemented");
	}
	@Test
	public void selectById()throws Exception{
		Location location=locationMapper.selectById(1);
		System.out.println(location);
		Assert.assertNotNull(location);
	}

	@Test
	public void testRootLocation(){
		Location location=locationMapper.getRootLocationsByCompanyId(1);
		System.out.println(location);
	}
	@Test
	public void testGetMonitoringTargetWithLocationIdAndUserId(){
		List<MonitoringTarget> monitoringTargetList =
				locationMapper.getMonitoringTargetByLocationIdAndUserId(6, 2);
		Assert.assertNotNull(monitoringTargetList);
	}

	@Test
	public void testFindLocationByROleId() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindLocationById() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindMonitoringTargetByLocationId() {
		fail("Not yet implemented");
	}

}
