package com.ilabservice.intelab.rest.controller.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.service.ExtraFeatureService;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@AutoConfigureMockMvc
@Transactional
public class FeatureControllerTest {

    @Resource
    private ExtraFeatureService extraFeatureService;

    @Test
    public void deletes() {
        List<Integer> list = Lists.newArrayList();
        list.add(1);
        list.add(2);
        boolean b = extraFeatureService.addOneOrMoreProductFeaturesTCompany(1, list);
        System.out.println(b);
    }

    @Test
    public void adds() {
        List<Integer> list = Lists.newArrayList();
        list.add(1);
        list.add(2);
        boolean b = extraFeatureService.deleteOneOrMoreProductFeaturesTCompany(1, list);
        System.out.println(b);
    }
}
