package com.ilabservice.intelab.rest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses(HomeControllerTest.class)
public class SuiteTest{
    /**
     *
　　　　　　1、作为测试套件的入口类，类中不能包含任何方法。
　　　　　　2、更改测试运行器Suite.class。
　　　　　　3、将需要运行的测试类放入Suite.SuiteClasses({})的数组中。
     * */

}
