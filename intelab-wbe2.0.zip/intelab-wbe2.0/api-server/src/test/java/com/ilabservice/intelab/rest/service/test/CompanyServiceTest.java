package com.ilabservice.intelab.rest.service.test;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.model.CompanyContractExtend;
import com.ilabservice.intelab.model.CompanyExtend;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.ilabservice.intelab.model.Company;
import com.ilabservice.intelab.model.CompanyContract;
import com.ilabservice.intelab.service.CompanyService;
import com.ilabservice.intelab.vo.CompanyContractVo;
import com.ilabservice.intelab.vo.CompanyVo;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class CompanyServiceTest {
    @Autowired
    private CompanyService companyService;
	@Test
	public void testSelectCompanyById() {
		Company company=companyService.selectCompanyAndExtraFeatureById(1);
		Assert.assertNotNull(company);
	}

	@Test
	public void testGetAdminCompanysPage() {
		List<Company> companies=companyService.getAdminCompanysPage(10, 0);
		System.out.println(companies.get(0).getId());
		Assert.assertNotNull(companies);
	}

	@Test
	public void testFindListCompanyContractByCompanyId() {
		List<CompanyContract> companyContracts=companyService.findListCompanyContractByCompanyId(1);
		Assert.assertNotNull(companyContracts);
		Assert.assertEquals(companyContracts.get(0).getId().toString(), "1");
	}

	@Test
	public void testAddCompanyContract() throws Exception {
		CompanyContractExtend companyContractVo=new CompanyContractExtend();
		companyContractVo.setStartDate(123457890L);
		companyContractVo.setEndDate(12234L);
		companyContractVo.setSignDate(12345L);
		companyContractVo.setDescription("公司协议");
	    CompanyContract companyContract= companyService.addCompanyContract(companyContractVo, 1);
	    Assert.assertNotNull(companyContract);
	}

	@Test
	public void testFindCompanyCount() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateCompanyContract() throws Exception {
		CompanyContractExtend companyContractVo=new CompanyContractExtend();
		companyContractVo.setCompanyId(1);
		companyContractVo.setStartDate(123457890L);
		companyContractVo.setEndDate(12234L);
		companyContractVo.setSignDate(12345L);
		companyContractVo.setDescription("公司协议");
		companyContractVo.setId(1);
		companyService.updateCompanyContract(companyContractVo, "1");
		Assert.assertTrue(companyService.updateCompanyContract(companyContractVo, "1"));
	}

	@Test
	public void testUpdateCompanyInfo() throws Exception {
		CompanyExtend companyVo=new CompanyExtend();
		companyVo.setId(1);
		companyVo.setAddress("上海");
		companyVo.setEmail("1235@163.com");
		companyVo.setDomainName("ilabservice");
		companyVo.setTelephone("12345678901");
		companyVo.setLongitude(new BigDecimal(123));
		companyVo.setLatitude(new BigDecimal(123));
		
		File file1=new File("/home/david/a.txt");
 		MultipartFile file=new MockMultipartFile(file1.getName(), file1.getName(), "", new FileInputStream(file1));
		String path="/22";
		Company company=companyService.updateCompanyInfo(file,companyVo,1);
		Assert.assertNotNull(company);
	}
	@Test
	public void testCreateCompanyInfo() throws FileNotFoundException, IOException {
		CompanyExtend companyVo=new CompanyExtend();
		companyVo.setName("释普科技");
		companyVo.setAddress("上海");
		companyVo.setEmail("1235@163.com");
		companyVo.setDomainName("ilabservice");
		companyVo.setTelephone("12345678901");
		companyVo.setLongitude(new BigDecimal(123));
		companyVo.setLatitude(new BigDecimal(123));
		companyVo.setManagerName("王五");
		companyVo.setManagerLoginUsername("赵柳");
		companyVo.setLocationName("room");
		File file1=new File("/home/david/a.txt");
 		MultipartFile file=new MockMultipartFile(file1.getName(), file1.getName(), "", new FileInputStream(file1));
 		List<Integer> featureIdList=new ArrayList<>();
 		featureIdList.add(1);
 		featureIdList.add(2);
		Company company=companyService.createCompanyInfo(file,featureIdList,companyVo);
		Assert.assertNotNull(company);
	}

}
