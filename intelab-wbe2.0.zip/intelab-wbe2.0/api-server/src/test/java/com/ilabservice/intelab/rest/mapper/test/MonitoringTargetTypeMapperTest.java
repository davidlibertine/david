package com.ilabservice.intelab.rest.mapper.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.mapper.MonitoringTargetTypeMapper;
import com.ilabservice.intelab.model.MeasureType;
import com.ilabservice.intelab.model.MonitoringTargetType;
import com.ilabservice.intelab.model.MonitoringTargetTypeMeasureRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class MonitoringTargetTypeMapperTest {
    @Autowired
    private MonitoringTargetTypeMapper monitoringTargetTypeMapper;
    @Test
    public void findMonitorTargetTypeCountTest(){
        int count=monitoringTargetTypeMapper.findMonitorTargetTypeCount();
        System.out.println(count);
    }
    @Test
    public void testFindMeasureTypesByMonitoringTargetTypeId(){
        List<MeasureType> measureTypes=monitoringTargetTypeMapper.findMeasureTypesByMonitoringTargetTypeId(1);
        System.out.println(measureTypes);
    }
    @Test
    public void testAddOneAndMoreMeasureTypeByMonitorTargetTypeId(){
        List<Map> list=new ArrayList<>();
        Map map=new HashMap();
        map.put("monitoringTargetTypeId",1);
        map.put("measureTypeId",1);
        list.add(map);
        Integer count=monitoringTargetTypeMapper.addOneAndMoreMeasureTypeByMonitorTargetTypeId(list);
        System.out.println(count);
    }
    @Test
    public void testDeleteOneAndMoreMeasureTypeByMonitorTargetTypeId(){
        List<Integer> list=new ArrayList<>();
        list.add(1);
        list.add(2);
        Integer count=monitoringTargetTypeMapper.deleteOneAndMoreMeasureTypeByMonitorTargetTypeId(1,list);
        System.out.println(count);
    }
    @Test
    public void testFindmeasureRuleByMonitorTargetTypeId(){
        List<MonitoringTargetTypeMeasureRule> monitoringTargetTypeMeasureRules=monitoringTargetTypeMapper.findmeasureRuleByMonitorTargetTypeId(1);
        System.out.println(monitoringTargetTypeMeasureRules);
    }
    @Test
    public void testDeleteMeasureRuleByMonitoringTargetTypeIdAndMeasureRule(){
        MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule=new MonitoringTargetTypeMeasureRule();
        monitoringTargetTypeMeasureRule.setId(1);
        monitoringTargetTypeMeasureRule.setMonitoringTargetTypeId(1);
        monitoringTargetTypeMapper.deleteMeasureRuleByMonitoringTargetTypeIdAndMeasureRule(monitoringTargetTypeMeasureRule);
    }
    @Test
    public void testAddMonitoringTargetType(){
        MonitoringTargetType monitoringTargetType=new MonitoringTargetType();
        monitoringTargetType.setName("123");
        monitoringTargetTypeMapper.addMonitoringTargetType(monitoringTargetType);
    }
}
