package com.ilabservice.intelab.rest.mapper.test;

import java.util.List;

import com.ilabservice.intelab.Application;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.User;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class UserRolesMapperTest {
	@Autowired
	private UserRolesMapper userRolesMapper;
	@Test
	public void findUserByRoleId()throws Exception{
		User user=userRolesMapper.findUserByRoleId(1);
		Assert.assertNotNull(user);
		Assert.assertNotNull(user.getUserName());
	}
	@Test
	public void findListRoleByUserId()throws Exception{
		List<Role> roles=userRolesMapper.findListRoleByUserId(1);
		Assert.assertNotNull(roles);
		Assert.assertNotNull(roles.get(0).getName());
		
	}

}
