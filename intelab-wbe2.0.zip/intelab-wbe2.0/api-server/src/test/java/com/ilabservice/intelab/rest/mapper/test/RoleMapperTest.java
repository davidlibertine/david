package com.ilabservice.intelab.rest.mapper.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.mapper.RoleMapper;
import com.ilabservice.intelab.model.Role;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class RoleMapperTest {

    @Autowired
    RoleMapper roleMapper;

    @Before
    public void before() throws Exception {
    }

//    @Rollback
    @After
    public void after() throws Exception {
    }

    @Test
    public void testGetRoleWithPermissionById(){
        Role role = roleMapper.getRoleById(1);
        Assert.assertNotNull(role);
        Assert.assertNotNull(role.getPermissions());
    }

    @Test
    public void testDelteByRoleId(){
        roleMapper.deleteById(1);
        Assert.assertNull(roleMapper.getRoleById(1));
    }
}
