package com.ilabservice.intelab.rest.rest;

import com.ilabservice.intelab.rest.mapper.test.RoleMapperTest;
import com.ilabservice.intelab.rest.mapper.test.RolePermissionMapMapperTest;
import com.ilabservice.intelab.rest.mapper.test.UserMapperTest;
import com.ilabservice.intelab.rest.mapper.test.UserRolesMapTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({RoleMapperTest.class, UserMapperTest.class, RolePermissionMapMapperTest.class,
        UserRolesMapTest.class})
public class SuiteTest{

    /**
     *
　　　　　　1、作为测试套件的入口类，类中不能包含任何方法。
　　　　　　2、更改测试运行器Suite.class。
　　　　　　3、将需要运行的测试类放入Suite.SuiteClasses({})的数组中。
     * */

}
