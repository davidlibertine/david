package com.ilabservice.intelab.rest.service.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.mapper.MonitoringTargetTypeMapper;
import com.ilabservice.intelab.model.MeasureType;
import com.ilabservice.intelab.model.MonitoringTargetType;
import com.ilabservice.intelab.model.MonitoringTargetTypeMeasureRule;
import com.ilabservice.intelab.service.MonitoringTargetTypeService;
import org.apache.commons.collections.bag.SynchronizedSortedBag;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class MonitoringTargetTypeServiceTest {
    @Autowired
    MonitoringTargetTypeService monitoringTargetTypeService;
    @Autowired
    MonitoringTargetTypeMapper monitoringTargetTypeMapper;
    @Test
    public void findListAllMonitoringTargetType() {
        List<MonitoringTargetType> monitoringTargetTypes=monitoringTargetTypeService.findListAllMonitoringTargetType(8,0);
        System.out.println(monitoringTargetTypes);

    }

    @Test
    public void addMonitoringTargetType() {
        List<Integer> measureTypes=new ArrayList<>();
        measureTypes.add(1);
        MonitoringTargetType monitoringTargetType=new MonitoringTargetType();
        monitoringTargetType.setName("gaoyaguo ");
        String logoUrl=null;
        MonitoringTargetType monitoringTargetType1=monitoringTargetTypeService.addMonitoringTargetType(measureTypes,monitoringTargetType,logoUrl);
        System.out.println(monitoringTargetType1);

    }

    @Test
    public void monitoringTargetTypeCount() {
        Integer count=monitoringTargetTypeService.monitoringTargetTypeCount();
        System.out.println(count);
    }

    @Test
    public void findUserMonitoringTargetTypeByCompanyId() {
       List<MonitoringTargetType> monitoringTargetTypes= monitoringTargetTypeService.findUserMonitoringTargetTypeByCompanyId(1,8,0);
        System.out.println(monitoringTargetTypes);
    }

    @Test
    public void findLoginUserMonitoringTargetTypeById() {
        MonitoringTargetType monitoringTargetType=new MonitoringTargetType();
        monitoringTargetType.setId(6);
        monitoringTargetType.setCompanyId(1);
       MonitoringTargetType monitoringTargetType1= monitoringTargetTypeMapper.selectOne(monitoringTargetType);
        System.out.println(monitoringTargetType1);
    }

    @Test
    public void findAdminMonitoringTargetTypeById() {
        MonitoringTargetType monitoringTargetType=monitoringTargetTypeService.findAdminMonitoringTargetTypeById(1);
        System.out.println(monitoringTargetType);
    }

    @Test
    public void deleteAdminMonitoringTargetTypeById() {
        boolean b=monitoringTargetTypeService.deleteAdminMonitoringTargetTypeById(1);
        System.out.println(b);
    }

    @Test
    public void updateAdminMonitoringTargetTypeById() {
    }

    @Test
    public void getMonitoringTargetTypeById() {
       MonitoringTargetType monitoringTargetType=monitoringTargetTypeService.getMonitoringTargetTypeById(1);
       System.out.println(monitoringTargetType);
    }

    @Test
    public void updateMonitoringTargetType() {
       // boolean b=monitoringTargetTypeService.updateMonitoringTargetType()
    }

    @Test
    public void getMeasureTypeByMonitorTargetTypeId() {
        List<Integer> monitoringTargetType=monitoringTargetTypeService.getMeasureTypeByMonitorTargetTypeId(1);
        System.out.println(monitoringTargetType);
    }

    @Test
    public void addOneAndMoreMeasureTypeByMonitorTargetTypeId() {
        List<Integer> ids=new ArrayList<>();
        ids.add(1);
        ids.add(2);
        boolean b=monitoringTargetTypeService.addOneAndMoreMeasureTypeByMonitorTargetTypeId(1,ids);
        System.out.println(b);

    }

    @Test
    public void deleteOneAndMoreMeasureTypeByMonitorTargetTypeId() {
        List<Integer> ids=new ArrayList<>();
        ids.add(1);
        ids.add(2);
        boolean b=monitoringTargetTypeService.deleteOneAndMoreMeasureTypeByMonitorTargetTypeId(1,ids);
        System.out.println(b);

    }

    @Test
    public void findmeasureRuleByMonitorTargetTypeId() {
        List<MonitoringTargetTypeMeasureRule> measureTypes=monitoringTargetTypeService.findmeasureRuleByMonitorTargetTypeId(1);
        System.out.println(measureTypes);
    }

    @Test
    public void addMeasureRuleByMonitorTargetType() {
        MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule=new MonitoringTargetTypeMeasureRule();
        monitoringTargetTypeMeasureRule.setName("123");
        monitoringTargetTypeMeasureRule.setDefinition("123");
        boolean b=monitoringTargetTypeService.addMeasureRuleByMonitorTargetType(monitoringTargetTypeMeasureRule,1,"温度");
        System.out.println(b);
    }

    @Test
    public void deleteMonitoringTargetTypeMeasureRule() {
        boolean b=monitoringTargetTypeService.deleteMonitoringTargetTypeMeasureRule(1,1);
        System.out.println(b);
    }

    @Test
    public void updateMonitoringTargetTypeMeasureRule() {
        MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule=new MonitoringTargetTypeMeasureRule();
        monitoringTargetTypeMeasureRule.setName("123");
        monitoringTargetTypeMeasureRule.setDefinition("123");
        boolean b=monitoringTargetTypeService.updateMonitoringTargetTypeMeasureRule(1,1,monitoringTargetTypeMeasureRule,"温度");
        System.out.println(b);
    }
}