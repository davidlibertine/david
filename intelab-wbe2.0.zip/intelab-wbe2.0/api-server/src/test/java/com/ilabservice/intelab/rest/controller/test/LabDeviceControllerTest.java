package com.ilabservice.intelab.rest.controller.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.model.MonitorTargetLabDevice;
import com.ilabservice.intelab.model.MonitoringTarget;
import com.ilabservice.intelab.restful.object.RestObject;
import com.ilabservice.intelab.service.LabDeviceService;
import com.ilabservice.intelab.vo.LabDeviceVo;
import com.ilabservice.intelab.vo.assemblyvo.LabDeviceVoMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Map;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@AutoConfigureMockMvc
@Transactional
public class LabDeviceControllerTest {

    @Resource
    private LabDeviceService labDeviceService;

    @Test
    public void addLabDeviceTest() {

        MonitorTargetLabDevice monitorTargetLabDevice = new MonitorTargetLabDevice();
        monitorTargetLabDevice.setAssetId("aaa");
        monitorTargetLabDevice.setBrand("112");
        monitorTargetLabDevice.setEnableSharing(1);
        monitorTargetLabDevice.setLeaseCause(1);
        monitorTargetLabDevice.setLeasePricePerHour(12.2f);
        monitorTargetLabDevice.setLocationId(1);
        monitorTargetLabDevice.setManufacture("zzz");
        monitorTargetLabDevice.setModel("ddd");
        monitorTargetLabDevice.setName("vvv");
        monitorTargetLabDevice.setPerchaseDate("123456");
        monitorTargetLabDevice.setPerchaseDate("zxcxc");
        monitorTargetLabDevice.setProductLine("x11");
        monitorTargetLabDevice.setProfileImage("asdsad");
        monitorTargetLabDevice.setSerialNumber("ooo");

        Map<String, Object> map = labDeviceService.addLabDevice(monitorTargetLabDevice, 1);
        if(map != null) {
            /**
             * 组装vo对象
             */
            LabDeviceVo labDeviceVo = LabDeviceVoMapper.getLabDeviceVo(map);
            System.out.println(labDeviceVo);
        }
    }
}
