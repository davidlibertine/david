package com.ilabservice.intelab.rest.mapper.test;

import java.util.List;

import com.ilabservice.intelab.Application;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ilabservice.intelab.mapper.ExtraFeatureMapper;
import com.ilabservice.intelab.model.ExtraFeature;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class ExtraFeatureMapperTest {
   @Autowired
   ExtraFeatureMapper extraFeatureMapper;
	@Test
	public void testFindListExtraFeature() {
		List<ExtraFeature> extraFeatures=extraFeatureMapper.findListExtraFeature(1);
		Assert.assertNotNull(extraFeatures);
	}

}
