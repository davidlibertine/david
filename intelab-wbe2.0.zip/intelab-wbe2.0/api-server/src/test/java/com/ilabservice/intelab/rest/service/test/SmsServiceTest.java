package com.ilabservice.intelab.rest.service.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.message.sms.SmsService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
public class SmsServiceTest {

    @Qualifier("SmsService")
    @Autowired
    SmsService smsService;

    @Test
    public void sendSmsTest() {
        boolean b = smsService.sendSms("17621702332", "3306", 0, null);
        System.out.println(b);
    }
}
