package com.ilabservice.intelab.rest.mapper.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.mapper.SensorMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
public class SensorMapperTest {

    @Resource
    private SensorMapper sensorMapper;

    @Test
    public void test() {
        Assert.assertNotNull(sensorMapper.selectById(1));
        Assert.assertNotNull(sensorMapper.selectById(1).getIotTerminal());
    }
}
