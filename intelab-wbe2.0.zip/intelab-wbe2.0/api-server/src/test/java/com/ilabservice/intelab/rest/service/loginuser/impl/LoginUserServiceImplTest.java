package com.ilabservice.intelab.rest.service.loginuser.impl;//package com.ilabservice.intelab.service.loginuser.impl;
//
//import com.ilabservice.intelab.Application;
//import com.ilabservice.intelab.mapper.UserMapper;
//import com.ilabservice.intelab.mapper.PermissionMapper;
//import com.ilabservice.intelab.mapper.RoleMapper;
//import com.ilabservice.intelab.mapper.UserRolesMapper;
//import com.ilabservice.intelab.model.User;
//import com.ilabservice.intelab.service.impl.UserServiceImpl;
//import org.junit.Assert;
//import org.junit.Test;
//import org.junit.Before;
//import org.junit.After;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.SpringApplicationConfiguration;
//import org.springframework.boot.test.WebIntegrationTest;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
///**
//* LoginUserServiceImpl Tester.
//*
//* @author <Authors name>
//* @since <pre>四月 27, 2018</pre>
//* @version 1.0
//*/
//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringApplicationConfiguration(classes = Application.class)
//@WebIntegrationTest("server.port:0")// 使用0表示端口号随机，也可以具体指定如8888这样的固定端口
//public class LoginUserServiceImplTest {
//    @Autowired
//    UserMapper userMapper;
//
//    @Autowired
//    RoleMapper rolesMapper;
//
//    @Autowired
//    PermissionMapper permissionMapper;
//
//    @Autowired
//    UserRolesMapper userRolesMapper;
//
//@Before
//public void before() throws Exception {
//}
//
//@After
//public void after() throws Exception {
//}
////
/////**
////*
////* Method: deleteById(Serializable id)
////*
////*/
////@Test
////public void testDeleteById() throws Exception {
//////TODO: Test goes here...
////
////    Assert.assertEquals(true, new UserServiceImpl().deleteById(1));
////}
////
/////**
////*
////* Method: recover(Exception e, Serializable id)
////*
////*/
////@Test
////public void testRecover() throws Exception {
//////TODO: Test goes here...
////}
////
///**
//*
//* Method: getUserRoleAndPermissionsByUserID(Serializable id)
//*
//*/
////@Test
////public void testGetUserRoleAndPermissionsByUserID() throws Exception {
//////TODO: Test goes here...
////    //    Assert.assertNotNull(new UserServiceImpl().getUserRoleAndPermissionsByUserID(1));
////}
//
//
//}
