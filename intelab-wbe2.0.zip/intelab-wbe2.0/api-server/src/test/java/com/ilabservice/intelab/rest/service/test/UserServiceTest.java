package com.ilabservice.intelab.rest.service.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.mapper.RoleMapper;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.User;
import com.ilabservice.intelab.service.UserService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class UserServiceTest {

    @Autowired
    UserService userService;


    @Autowired
    RoleMapper roleMapper;


    @Autowired
    UserMapper userMapper;


    @Before
    public void before() throws Exception {

    }

    @After
    public void after() throws Exception {

    }

    @Test
    public void testGetUserService(){
        User user = userService.getUserDetailInfo(1);
        Assert.assertNotNull(user);
        Assert.assertNotNull(user.getRoles());
    }

    @Test
    public void testAddRoleToUser(){
        User user = userMapper.getUserById(1);
        Role role = roleMapper.getRoleById(2);
        userService.addRoleToUser(role, user);
        user = userMapper.getUserById(1);
        System.out.println(user.getRoles());

    }

    @Test
    public void testUpdateUserInfo(){
        User user = userMapper.getUserById(1);
        user.setName("hello world");
        userService.updateById(user);
        user = userMapper.getUserById(1);
        Assert.assertEquals(user.getName(), "hello world");
    }


}
