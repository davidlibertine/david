package com.ilabservice.intelab.rest.mapper.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.mapper.DeviceFilesMapper;
import com.ilabservice.intelab.model.DeviceFiles;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class DeviceFilesMapperTest {

    @Resource
    private DeviceFilesMapper deviceFilesMapper;

    @Test
    public void test() {
        DeviceFiles deviceFiles = deviceFilesMapper.selectById(1);
//        Assert.assertNotNull(deviceFiles);
//        Assert.assertNotNull(deviceFiles.getLabDevice());
//        System.out.println(deviceFiles.getDeviceId());
//        LabDevice labDevice = labDeviceMapper.selectById(deviceFiles.getDeviceId());
    }
}
