package com.ilabservice.intelab.rest.mapper.test;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.mapper.MonitoringTargetMeasureRuleMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
public class MonitoringTargetMeasureRuleMapperTest {

    @Resource
    private MonitoringTargetMeasureRuleMapper monitoringTargetMeasureRuleMapper;

    @Test
    public void test() {
        Assert.assertNotNull(monitoringTargetMeasureRuleMapper.selectById(1));
        Assert.assertNotNull(monitoringTargetMeasureRuleMapper.selectById(1).getMonitoringTarget());
        Assert.assertNotNull(monitoringTargetMeasureRuleMapper.selectById(1).getMeasureType());
    }
}
