package com.ilabservice.intelab.rest.controller.test;

import com.github.pagehelper.PageInfo;
import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.check.ParametersAndPermissionsCheck;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.model.Permission;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.User;
import com.ilabservice.intelab.service.PermissionService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@AutoConfigureMockMvc
@Transactional
public class PermissionControllerTest {

    @Resource
    private PermissionService permissionService;

    @Resource
    private UserRolesMapper userRolesMapper;

    @Resource
    private UserMapper userMapper;

    @Autowired
    private ParametersAndPermissionsCheck parametersAndPermissionsCheck;

    @Test
    public void getAllPermissionTest() {
        User user = userMapper.getUserById(1);
        List<Role> roleList = userRolesMapper.getLoginRoleIdByLoginUserId(user.getId());
        boolean b = parametersAndPermissionsCheck.adminCheck(ResultErrorCode.FILL_PARAMETERS.getCode(), roleList);
        PageInfo pageInfo = permissionService.getAllPermission(1, 10);
        System.out.println(pageInfo);
    }

    @Test
    public void addPermission() {
        Permission permission = new Permission();
        permission.setCreateDatetime(new Date());
        permission.setDescription("111");
        permission.setName("123123");
        permission.setPermissionType("123123");
        Permission p = permissionService.addPermission(permission);
        System.out.println(p);
    }

    @Test
    public void deletePermission() {
        Boolean b = permissionService.deletePermission(1);
        System.out.println(b);
    }

    @Test
    public void updatePermission() {
        Permission permission = new Permission();
        permission.setCreateDatetime(new Date());
        permission.setDescription("1");
        permission.setName("12");
        permission.setPermissionType("tttt");
        Boolean b = permissionService.updatePermission(1, permission);
        System.out.println(b);
    }
}
