package com.ilabservice.intelab.rest.mapper.test;

import java.util.List;

import com.ilabservice.intelab.Application;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.ilabservice.intelab.mapper.CompanyMapper;
import com.ilabservice.intelab.model.Company;
import com.ilabservice.intelab.model.ExtraFeature;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
@Transactional
public class CompanyMapperTest {
	@Autowired
	private CompanyMapper companyMapper;
	@Test
	public void findListExtraFeatureByCompanyIdTest() {
		List<ExtraFeature> extraFeatures=companyMapper.findListExtraFeatureByCompanyId(1);
		Assert.assertNotNull(extraFeatures);
	}
	@Test
	public void selectByIdTest() {
		Company company=companyMapper.selectById(1);
		Assert.assertNotNull(company);
	}

}
