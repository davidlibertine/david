# intelab-wbe2.0
intelab backend 2.0


###  1：retry 机制

	基于spring的重试机制
	
	重点注解是 
		@Retryable注解 被注解的方法发生异常时会重试
		
		  value			指定发生的异常进行重试
        include			和value一样，默认空，当exclude也为空时，所有异常都重试
        exclude 		指定异常不重试，默认空，当include也为空时，所有异常都重试
        maxAttemps:  	重试次数，默认3
        backoff   		重试补偿机制，默认没有
        RetryOperations定义了重试的API，RetryTemplate提供了模板实现，线程安全的，
        同于Spring 一贯的API风格，RetryTemplate将重试、熔断功能封装到模板中，提供健壮和不易出错的API供大家使用。
        backoff 重试机制有很多种
                1：固定时间重试
                2：随机时间重试
                3：渐变式重试  比如一开始1秒钟重试一次，再5秒重试一次，等等类似等差或者等比数列这种

	
	
	@Recover  retry的方法 参数必须和 指定retry的参数一致
	
		一村提到的问题，当涉及到有多个需要重试的方法 ，根据参数匹配，不同的参数，方法重载
		
		什么时候重试？
			当出现异常的时候 会 重试  这种通常是自定义的异常  比如说 数据库连接中断异常 调用其他
				服务的连接异常等等 
			@Retryable(value = { RemoteAccessFailedException.class }）
			

### 2:单元测试

	由于后台的是接口服务器，所以所做的单元测试基本上是 resttemplate 测试请求
	
	SuiteTest
	
		    /**
		     *
		　　　　　　1、作为测试套件的入口类，类中不能包含任何方法。
		　　　　　　2、更改测试运行器Suite.class。
		　　　　　　3、将需要运行的测试类放入Suite.SuiteClasses({})的数组中。
		     * */

		     
	其他的测试样例是单个测试
	
	@Before 测试之前要干什么  通常是准备数据
	
	@Test 测试的方法 格式是 test + 指定测试类中的方法名
	
	@After 测试结束
	
	
#### 3:单元测试步骤

    1): 全局测试
    
        进到项目根目录  cd ./api_server
                     mvn clean test
                     
    2): 单个测试
    
        mvn clean test -Dtest=TestClassName#testMethod
        
        TestClassName 要执行的测试类名
        testMethod  要执行的这个类的测试方法
        
        eg: mvn clean test -Dtest=LoginUserServiceImplTest#testGetUserRoleAndPermissionsByUserID
                     
                     
	
#### 4: 打包

    
        1）parent根目录打包 mvn clean package -Dmaven.test.skip=true
        
        2）项目根目录 mvn clean package -Dmaven.test.skip=true
        
        打包后的文件  在 output 文件夹
        
#### 5.  文件上传服务模块
 * 文件上传服务配置：
配置框架如下：
```
file-storage:
   type: azure | ftp
   ftp:
       host: localhost
       user: test
       password: test
       port: 21
  azure:
       serviceName: influxmedia
       accountName: intelab2test
       accessKey1: cnXBFOgQlELcHhigRBBfKsNdm/UzaRYFib7vOB0zQOYEUenE9io57aINKGVJLrf4KnnHc4snO10SKnsCEXczGw==
       azureCloud: china
       endPoint: core.chinacloudapi.cn
```
 在type中可以选择使用azure或ftp，然后在azure或ftp部分填上相关的参数。
  * 文件上传服务使用
 在模块中通过Spring的autowire机制可以直接装配服务，例子如下：
```
@Autowired
FileUploadService fileUploadService;
```
 * 文件上传接口规范
 FileUploadService使用统一的接口提供文件上传服务：
```
String uploadFile(MultipartFile file, String containerName, String blobName, String oldName);
```
其中参数file是上传的文件，containerName是父容器名称，blobName是子容器名称，包括文件名，oldName是旧路径，旧路径是为了删除旧的资源。
返回值是新的url。
举例来说，将新文件test上传到/company1/building/目录下，调用接口的方式为：
```
String url = uploadFile(test, "company1", "building/test", null); 
```