package com.ilabservice.intelab.client;

import com.ilabservice.intelab.mqtt.IotMqttClient;
import com.ilabservice.intelab.mqtt.MsgReceiveHandler;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;

public class MqttClientTest {

    private IotMqttClient iotMqttClient;

    @Before
    public void before(){
        // 初始化客户端并拿到客户端
        this.iotMqttClient = new IotMqttClient().initClient(
                Client.user,Client.password,Client.broker,Client.clientId,Client.topic,new IotMsgHandle());
    }


    @Test
    public void sendMsgTest() throws Exception{
        // 发送消息
        // 发送和接收的client id 一定不能一样哦 否则就会踢掉一开始连接的 这个客户端要把握好 订阅同一个topic 就行了
        this.iotMqttClient.setClientId(iotMqttClient.getClientId() + "-send");
        this.iotMqttClient.sendMsg(iotMqttClient,"你收到了吗哈哈哈哈哈哈");
    }

    @Test
    public void receiveMsgTest(){
        // 连接并收到消息进行处理
        this.iotMqttClient.connect(iotMqttClient);
    }

    
    /**
     * 
     * @author RedWall
     * @date 2018/5/21
     * @desc mqtt收到消息需要处理  只需 实现接口MsgReceiveHandler即可
     * 
    **/
    
    @Slf4j
    public static class IotMsgHandle implements MsgReceiveHandler {


        @Override
        public void handlerMsg(String msg){
            log.info("iot 开始处理消息测试下--" + msg);
//        try {
//            Thread.sleep(10000L);
//        }catch (InterruptedException e){
//            log.error(e.getMessage());
//        }
            // TODO 处理消息
            log.info("iot 结束处理消息");
        }

    }

}
