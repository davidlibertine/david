package com.ilabservice.intelab.config;

import lombok.Data;


@Data
@Deprecated
public class ClientConfig {

    private Integer threadNums;

}
