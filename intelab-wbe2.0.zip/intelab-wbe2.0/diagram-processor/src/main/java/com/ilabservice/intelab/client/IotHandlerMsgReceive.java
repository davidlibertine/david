package com.ilabservice.intelab.client;

import com.ilabservice.intelab.mqtt.MsgReceiveHandler;
import lombok.extern.slf4j.Slf4j;

@Slf4j
/**
 * 
 * @author RedWall
 * @date 2018/5/19
 * @desc mqtt 处理消息
 *
**/

public class IotHandlerMsgReceive implements MsgReceiveHandler {

    @Override
    public void handlerMsg(String msg){
        log.info("iot 开始处理消息--" + msg);
//        try {
//            Thread.sleep(10000L);
//        }catch (InterruptedException e){
//            log.error(e.getMessage());
//        }
        // TODO 处理消息
        log.info("iot 结束处理消息");
    }

}
