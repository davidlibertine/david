//package com.ilabservice.intelab.client;
//
//import com.ilabservice.intelab.mqtt.MsgHandler;
//import com.ilabservice.intelab.notify.EventObserver;
//import lombok.extern.slf4j.Slf4j;
//
//@Slf4j
//public class IotEventObserver implements EventObserver{
//
//    private MsgReceiveHandler msgReceiveHandler;
//
//    private IotEventObserver(){}
//
//    public IotEventObserver(MsgReceiveHandler msgReceiveHandler){
//        this.msgReceiveHandler = msgReceiveHandler;
//    }
//
//
//    /**
//     * 消息通知
//     * @param info 消息
//     */
//    @Override
//    public void onEvent(Object info){
//        log.info("消息体:" + info);
//        log.info("去处理消息");
//        this.msgReceiveHandler.handlerMsg(info.toString());
//        log.info("消息处理完毕");
//        log.info("注销当前观察者");
////        MyNotify.getNotifier().unRegisterObserver(this);
//    }
//}
