package com.ilabservice.intelab.task;

import com.ilabservice.intelab.mqtt.MsgReceiveHandler;
import com.ilabservice.intelab.notify.MyNotifier;
import com.ilabservice.intelab.notify.MyNotify;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
@Deprecated
/**
 * 
 * @author RedWall
 * @date 2018/5/19
 * @desc 已废弃
 * 
**/

public class ObserveTask implements Runnable {

    private MsgReceiveHandler msgReceiveHandler;

    private ObserveTask(){}

    public ObserveTask(MsgReceiveHandler msgReceiveHandler){
        this.msgReceiveHandler = msgReceiveHandler;
    }


    @Override
    public void run(){
        log.info("观察者上线====" + Thread.currentThread().getName());
        MyNotifier notifier = MyNotify.getNotifier();
//        notifier.registerObserver("distribute", new IotEventObserver(this.getMsgReceiveHandler()));
    }


}
