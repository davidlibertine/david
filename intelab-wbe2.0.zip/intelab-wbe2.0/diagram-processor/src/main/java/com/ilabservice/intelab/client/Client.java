package com.ilabservice.intelab.client;

import lombok.Data;

@Data
public class Client {

//    public static final String broker = "tcp://mqtt-cn-0pp0lqhyn05.mqtt.aliyuncs.com:1883";

    public static final String broker = "tcp://zissi.chinaeast.cloudapp.chinacloudapi.cn:61613";

    public static final String clientId = "GID_testilab@@@ClientID_wangmeng";

    public static final String user = "admin";

    public static final String password = "password";


    public static final String topic = "topic";
}
