package com.ilabservice.intelab.main;

import com.ilabservice.intelab.client.Client;
import com.ilabservice.intelab.client.IotHandlerMsgReceive;
import com.ilabservice.intelab.config.ClientConfig;
import com.ilabservice.intelab.mqtt.IotMqttClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.concurrent.ExecutorService;


/**
* @author RedWall
* @mail walkmanlucas@gmail.com
* @date 2018/5/11
* @desc 主线程启动
**/
@Slf4j
public class App {

    private static ExecutorService pool;

    /**
    * @author RedWall
    * @mail walkmanlucas@gmail.com
    * @param
    * @date 2018/5/11
    * @desc 主程序线程入口  启动类
    * @return 
    **/
    public static void main(String[] args) {
        log.info("主线程开始启动...");
        App app = new App();
        app.init();
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                log.info(String.valueOf(pool.isShutdown()));
                pool.shutdown();
                log.info(String.valueOf(pool.isShutdown()));
                // jvm 关闭前检查client 是否处于活跃状态
//                ThreadGroup group = Thread.currentThread().getThreadGroup();
//                ThreadGroup topGroup = group;
//// 遍历线程组树，获取根线程组
//                while (group != null) {
//                    topGroup = group;
//                    group = group.getParent();
//                }
//// 激活的线程数加倍
//                int estimatedSize = topGroup.activeCount() * 2;
//                Thread[] slackList = new Thread[estimatedSize];
//// 获取根线程组的所有线程
//                int actualSize = topGroup.enumerate(slackList);
//// copy into a list that is the exact size
//                Thread[] list = new Thread[actualSize];
//                System.arraycopy(slackList, 0, list, 0, actualSize);
//                System.out.println("Thread list size == " + list.length);
//                for (Thread thread : list) {
//                    System.out.println(thread.getName());
            }
        });
    }

    /**
    * @author RedWall
    * @mail walkmanlucas@gmail.com
    * @param
    * @date 2018/5/11
    * @desc 初始化获取配置信息
    * @return 
    **/
    public void init(){
        ApplicationContext ctx = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
        ClientConfig clientConfig = (ClientConfig)ctx.getBean("config");
        // 初始化客户端
        IotMqttClient iotMqttClient = new IotMqttClient().initClient(
                Client.user,Client.password,Client.broker,Client.clientId,Client.topic,new IotHandlerMsgReceive());
        // 连接
        new IotMqttClient().connect(iotMqttClient);
    }






}
