package com.ilabservice.intelab.task;

import com.ilabservice.intelab.client.Client;
import com.ilabservice.intelab.client.IotHandlerMsgReceive;
import com.ilabservice.intelab.mqtt.IotMqttClient;
import lombok.extern.slf4j.Slf4j;

/**
* @author RedWall
* @mail walkmanlucas@gmail.com
* @date 2018/5/11
* @desc mqtt客户端接受信息任务
**/
@Slf4j
@Deprecated
public class ClientReceiveTask implements Runnable {


    @Override
    public void run(){
        IotMqttClient iotMqttClient = new IotMqttClient().initClient(Client.user,Client.password,Client.broker,Client.clientId,"topic",new IotHandlerMsgReceive());
        new IotMqttClient().connect(iotMqttClient);
    }

}
