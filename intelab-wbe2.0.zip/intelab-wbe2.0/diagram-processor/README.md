### MQTT Client 基本使用


    MQTT（Message Queuing Telemetry Transport，消息队列遥测传输协议），
    是一种基于发布/订阅（publish/subscribe）模式的“轻量级”通讯协议，
    该协议构建于TCP/IP协议上，由IBM在1999年发布。MQTT最大优点在于，
    可以以极少的代码和有限的带宽，为连接远程设备提供实时可靠的消息服务。
    作为一种低开销、低带宽占用的即时通讯协议，使其在物联网、小型设备、移动应用等方面有较广泛的应用。

    notes:
    1: client 与server连接，client唯一性
    2: qos 
       level 0：最多一次的传输
        
            消息是基于TCP/IP网络传输的。没有回应，在协议中也没有定义重传的语义。消息可能到达服务器1次，也可能根本不会到达。
      
       level 1：至少一次的传输
       
            服务器接收到消息会被确认，通过传输一个PUBACK信息。如果有一个可以辨认的传输失败，无论是通讯连接还是发送设备，还是过了一段时间确认信息没有收到，发送方都会将消息头的DUP位置1，然后再次发送消息。消息最少一次到达服务器。SUBSCRIBE和UNSUBSCRIBE都使用level 1 的QoS。
            
            如果客户端没有接收到PUBACK信息（无论是应用定义的超时，还是检测到失败然后通讯session重启），客户端都会再次发送PUBLISH信息，并且将DUP位置1。
            
            当它从客户端接收到重复的数据，服务器重新发送消息给订阅者，并且发送另一个PUBACK消息。
            
       level 2： 只有一次的传输
       在QoS level 1上附加的协议流保证了重复的消息不会传送到接收的应用。这是最高级别的传输，当重复的消息不被允许的情况下使用。这样增加了网络流量，但是它通常是可以接受的，因为消息内容很重要。
       
       QoS level 2在消息头有Message ID。
       
       本项目中默认使用了qos : level 2
         

#### 1：项目启动类为：com.ilabservice.intelab.main.APP

#### 2：配置项：src/main/resource/mqtt-client.properties
        
        1):现在只配置了项目启动时候启动的客户端数目
        
       com.ilabservice.intelab.client.Client 配置 连接broker的信息
       
      
        
#### 3：测试：

        1）src/test/java/com.ilabservice/intelab/client
        
        MQTTRecvMsgTest 接受信息测试
        MQTTSendMsgTest 发送消息测试
        
#### 4: 打包

        1）parent根目录打包 mvn clean package -Dmaven.test.skip=true
        
        2）项目根目录 mvn clean package -Dmaven.test.skip=true
        
        打包后的文件  在 output 文件夹
        
        
#### 2018-05-19 新增MQTT处理

    app启动时已经初始化连接broker
    
    需要唯一做的是
 
    在 com.ilabservice.intelab.client.IotHandlerMsgReceive 里的TODO 里面写需要接收消息后的操作
    
#### 2018-05-21 新增MQTT 测试
    
    com.ilabservice.intelab.client.MqttClientTest
    
    
    
    
        
        