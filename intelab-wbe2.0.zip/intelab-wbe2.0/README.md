# intelab-parent


### modules

    api-server  api服务端
    
    diagram-processor  MQTT Client
    
    intelab-data  业务处理逻辑 model service mapper
    
    intelab-common 公共模块
    
### 打包

    mvn clean install package -Dmaven.test.skip=true
    
    自动打包到output文件夹