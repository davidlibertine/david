package com.ilabservice.intelab.mqtt;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

public class IotMqttClient implements MqttClientHandler {

    private static final Logger log = LoggerFactory.getLogger(IotMqttClient.class);

    private String username;

    private String password;

    private String broker;

    private String clientId;

    private String topic;

    private MsgReceiveHandler msgReceiveHandler;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getBroker() {
        return broker;
    }

    public void setBroker(String broker) {
        this.broker = broker;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public MsgReceiveHandler getMsgReceiveHandler() {
        return msgReceiveHandler;
    }

    public void setMsgReceiveHandler(MsgReceiveHandler msgReceiveHandler) {
        this.msgReceiveHandler = msgReceiveHandler;
    }

    public IotMqttClient() {

    }

    @Override
    public IotMqttClient initClient(String username, String password, String broker, String clientId, String topic, MsgReceiveHandler msgReceiveHandler){
        this.username = username;
        this.password = password;
        this.broker = broker;
        this.clientId = clientId;
        this.topic = topic;
        this.msgReceiveHandler = msgReceiveHandler;
        return this;
    }

    @Override
    public void connect(IotMqttClient iotMqttClient){
        MemoryPersistence persistence = new MemoryPersistence();
        try {
            MqttClient sampleClient = new MqttClient(iotMqttClient.getBroker(), iotMqttClient.getClientId(), persistence);
            final MqttConnectOptions connOpts = new MqttConnectOptions();
            log.info("Connecting to broker: " + iotMqttClient.getBroker() + "-----" + iotMqttClient.getClientId());
            /**
             * 计算签名，将签名作为 MQTT 的 password
             * 签名的计算方法，参考工具类 MacSignature，第一个参数是 ClientID 的前半部分，即 GroupID
             * 第二个参数阿里云的 SecretKeys
             */
//                String sign = MacSignature.macSignature(Client.clientId.split("@@@")[0], secretKey);
            /**
             * 设置订阅方订阅的 Topic 集合，此处遵循 MQTT 的订阅规则，可以是一级 Topic，二级 Topic，P2P 消息请订阅/p2p
             */
            final String[] topicFilters=new String[]{iotMqttClient.getTopic()};
            final int[]qos={2};
            connOpts.setUserName(iotMqttClient.getUsername());
            connOpts.setServerURIs(new String[] { iotMqttClient.getBroker() });
            connOpts.setPassword(iotMqttClient.getPassword().toCharArray());
            connOpts.setCleanSession(true);  //若设为false，MQTT服务器将持久化客户端会话的主体订阅和ACK位置，默认为true
            connOpts.setKeepAliveInterval(90);//定义客户端传来消息的最大时间间隔秒数，服务器可以据此判断与客户端的连接是否已经断开，从而避免TCP/IP超时的长时间等待
            connOpts.setAutomaticReconnect(true);  // 自动重连
            sampleClient.setCallback(new MqttCallbackExtended() {
                public void connectComplete(boolean reconnect, String serverURI) {
                    log.info("connect success----"+sampleClient.getClientId());
                    //连接成功，需要上传客户端所有的订阅关系
                    try {
                        sampleClient.subscribe(topicFilters,qos);
                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
                }
                public void connectionLost(Throwable throwable) {
                    log.info("mqtt connection lost-"+sampleClient.getClientId());
                }
                public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                    log.info(sampleClient.getClientId() + "收到消息");
                    log.info("messageArrived:" + topic + "------" + new String(mqttMessage.getPayload()));
                    // 收到消息需要处理
                    iotMqttClient.getMsgReceiveHandler().handlerMsg(new String(mqttMessage.getPayload()));
                }
                public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
                    log.info("deliveryComplete:" + iMqttDeliveryToken.getMessageId() + "-----" + sampleClient.getClientId());
                }
            });
            //客户端每次上线都必须上传自己所有涉及的订阅关系，否则可能会导致消息接收延迟
            sampleClient.connect(connOpts);
            //每个客户端最多允许存在30个订阅关系，超出限制可能会丢弃导致收不到部分消息
            sampleClient.subscribe(topicFilters,qos);
//            Thread.sleep(Integer.MAX_VALUE);
        } catch (Exception me) {
            me.printStackTrace();
        }
    }


    @Override
    public void sendMsg(IotMqttClient iotMqttClient,String msg) throws Exception{
        /**
         * 设置当前用户私有的 MQTT 的接入点。例如此处示意使用 XXX，实际使用请替换用户自己的接入点。接入点的获取方法是，在控制台创建 MQTT 实例，每个实例都会分配一个接入点域名。
         */
        final String broker = iotMqttClient.getBroker();
        /**
         * 设置阿里云的 AccessKey，用于鉴权
         */
//        final String acessKey ="LTAIxEoa2KTuHQy9";
//        /**
//         * 设置阿里云的 SecretKey，用于鉴权
//         */
//        final String secretKey ="hsmMYkh87VDCEorxB1fpkBpQUff0dQ";
        /**
         * 发消息使用的一级 Topic，需要先在 MQ 控制台里创建
         */
        final String topic = iotMqttClient.getTopic();
        /**
         * MQTT 的 ClientID，一般由两部分组成，GroupID@@@DeviceID
         * 其中 GroupID 在 MQ 控制台里创建
         * DeviceID 由应用方设置，可能是设备编号等，需要唯一，否则服务端拒绝重复的 ClientID 连接
         */
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            final MqttClient sampleClient = new MqttClient(broker, iotMqttClient.getClientId(), persistence);
            final MqttConnectOptions connOpts = new MqttConnectOptions();
            System.out.println("Connecting to broker: " + broker);
            /**
             * 计算签名，将签名作为 MQTT 的 password。
             * 签名的计算方法，参考工具类 MacSignature，第一个参数是 ClientID 的前半部分，即 GroupID
             * 第二个参数阿里云的 SecretKey
             */
//            sign = MacSignature.macSignature(clientId.split("@@@")[0], secretKey);
            connOpts.setUserName(iotMqttClient.getUsername());
            connOpts.setServerURIs(new String[] { broker });
            connOpts.setPassword(iotMqttClient.getPassword().toCharArray());
            connOpts.setCleanSession(true);
            connOpts.setKeepAliveInterval(90);
            connOpts.setAutomaticReconnect(true);
            sampleClient.setCallback(new MqttCallbackExtended() {
                public void connectComplete(boolean reconnect, String serverURI) {
                    System.out.println("connect success");
                }
                public void connectionLost(Throwable throwable) {
                    System.out.println("mqtt connection lost");
                }
                public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                    System.out.println("messageArrived:" + topic + "------" + new String(mqttMessage.getPayload()));
                }
                public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
                    System.out.println(sampleClient.getClientId() + "收到消息");
                    System.out.println("deliveryComplete:" + iMqttDeliveryToken.getMessageId());
                }
            });
            sampleClient.connect(connOpts);
            String scontent = msg;
            //此处消息体只需要传入 byte 数组即可，对于其他类型的消息，请自行完成二进制数据的转换
            final MqttMessage message = new MqttMessage(scontent.getBytes());
            message.setQos(2);
            /**
             *消息发送到某个主题 Topic，所有订阅这个 Topic 的设备都能收到这个消息。
             * 遵循 MQTT 的发布订阅规范，Topic 也可以是多级 Topic。此处设置了发送到二级 Topic
             */
            sampleClient.publish(topic, message);
        } catch (Exception me) {
            me.printStackTrace();
        }
    }




}
