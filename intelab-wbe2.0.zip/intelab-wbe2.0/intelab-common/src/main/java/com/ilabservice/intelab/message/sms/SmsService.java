package com.ilabservice.intelab.message.sms;

import java.util.Map;

public interface SmsService {

    /**
     * 发送短信
     * @param verifyMobile
     * @param message
     * @param type
     * @param messageMap
     * @return
     */
    boolean sendSms(String verifyMobile, String message, Integer type, Map<String, String> messageMap);
}
