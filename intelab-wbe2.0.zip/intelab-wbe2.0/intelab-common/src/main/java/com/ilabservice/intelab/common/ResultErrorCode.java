package com.ilabservice.intelab.common;

/**
 * 自定義異常信息返回狀態碼
 */
public enum ResultErrorCode {

    /**
     * 成功狀態碼
     */
    SUCCESS(200, "succeeds"),
    /**
     * 常用失败状态码
     */
    NOT_FOUND_PAGE_OR_URL_OR_MODEL(404, "not found"),
    UPDATE_USER_PASSWORD_ERROR(500, "failed to update password"),
    DELETE_INFO_ERROR(409, "cannot delete because of conflict"),
    FEATURE_NOE_FOUND(404, "feature not found"),
    /**
     * 参数错误
     */
    PARAMS_IS_NULL(10001, "参数为空"),
    PARAMS_NOT_COMPLETE(10002, "参数不全"),
    PARAMS_TYPE_ERROR(10003, "参数类型错误"),
    PARAMS_IS_INVALID(10004, "参数无效"),
    FILL_PARAMETERS(1, "填充参数"),
    /**
     * 用户错误
     */
    USER_NOT_EXIST(20001, "用户不存在"),
    USER_NOT_LOGGED_IN(20002, "用户未登陆"),
    USER_ACCOUNT_ERROR(20003, "用户名或密码错误"),
    USER_ACCOUNT_FORBIDDEN(20004, "用户账户已被禁用"),
    USER_HAS_EXIST(20005, "用户已存在"),
    UPDATE_USER_FAIL(20008, "更新用戶失敗"),
    UPDATE_USER_HEAD_ICON_FAIL(20006, "更新用戶頭像失敗"),
    USER_PASSWORD_ERROR(20007, "舊密码错误"),
    NO_GET_USER_COMPANY_INFO(20009, "沒有查到用戶信息"),
    NO_GET_PERMISSION_INFO(20010, "沒有查到权限信息"),
    /**
     * 业务错误
     */
    BUSINESS_ERROR(30001, "系统业务出现问题"),
    /**
     * 系统错误
      */
    SYSTEM_INNER_ERROR(40001, "系统内部错误"),
    SERVER_PROCESSING_ERROR(500, "服务器处理错误"),
    /**
     * 数据错误
     */
    DATA_NOT_FOUND(50001, "数据未找到"),
    DATA_IS_WRONG(50002, "数据有误"),
    DATA_ALREADY_EXISTED(50003, "数据已存在"),
    NO_GET_USER_INFO(50004, "沒有從Controller參數中獲取到用戶信息"),
    /**
     * 接口異常
     */
    INTERFACE_INNER_INVOKE_ERROR(60001, "系统内部接口调用异常"),
    INTERFACE_OUTER_INVOKE_ERROR(60002, "系统外部接口调用异常"),
    INTERFACE_FORBIDDEN(60003, "接口禁止访问"),
    INTERFACE_ADDRESS_INVALID(60004, "接口地址无效"),
    INTERFACE_REQUEST_TIMEOUT(60005, "接口请求超时"),
    INTERFACE_EXCEED_LOAD(60006, "接口负载过高"),
    /**
     * 訪問權限異常
     */
    PERMISSION_NO_ACCESS(70001, "没有访问权限"),
    /*
     * companyError
     */
    COMPANY_NOT_EXIST(80001,"公司信息不存在"),
    COMPANYCONTRACT_NOT_EXIST(80002,"公司协议不存在"),
    COMPANYCONTRACT_INSERT_FAIL(80003,"添加协议失败"),
    COMPANYCONTRACT_UPDATE_ERROR(80004,"公司协议更新失败"),
    COMPANYLOGO_ADD_ERROR(80005,"公司logo添加失败"),
    COMPANY_UPDATE_FAIL(80006,"更新公司信息失败"),
    COMPANY_CREATE_FAIL(80007,"创建公司信息失败"),
    /**
     *monitoringTargetTypeError
     */
    MONITORINGTARGETTYPE_NOT_EXIST(90001,"监控对象类型不存在"),
    MONITORINGTARGETTYPE_DELETE_FAIL(90002,"监控对象种类删除失败"),
    MONITORINGTARGETTYPE_UPDATE_FAIL(90003,"监控对象种类更新失败"),
    MONITORINGTARGETTYPE_ADD_FAIL(90004,"在控制对象类型中添加控制参数失败"),
    MONITORINGTARGETTYPEMEASURERULE_ADD_FAIL(90005,"添加监控参数规则失败"),
    MONITORINGTARGETTYPEMEASURERULE_UPDATE_FAIL(90006,"更新监控参数规则失败"),
    MONITORINGTARGETTYPEMEASURERULE_DELETE_FAIL(90007,"监控对象没有监控规则"),
    MONITORINGTARGETTYPE_NOT_EXIST_IN_COMPANY(90008,"本公司不存在该监控对象种类"),
    MONITORINGTARGETTYPEMEASURERULE_NOT_EXIST_IN_COMPANY(90009,"该监控种类不存在监控规则"),
    /**
     * labDeviceError
     */
    LABDEVICE_UPDATE_FIAL(100001,"监控对象设备更新失败"),
    LABDEVICE_DELETE_FAIL(100002,"监控对象设备删除失败"),
    DEVICEFILES_NOT_EXIST(100003,"设备文件不存在"),
    MONITORTARGETMEASURETYPERULE_DELETE_FAIL(100004,"监控对象规则删除失败"),
    DEVICEFILES_DELETE_FAIL(100005,"该设备不存在设备文件"),
    LABDEVICE_NOT_EXIST(100006,"监控对象设备不存在"),
    /**
     * 逻辑校验码
     */
    SYSTEM_ADMIN(0, "SYSTEM_ROLE"),
    USER_ROLE(1 ,"USER_ROLE"),
    USER_PLATFORM_MANAGER(4, "USER PLATFORM MANAGER");

    private String value;
    private int code;

    ResultErrorCode(int code, String value) {
        this.code = code;
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public int getCode() {
        return code;
    }

    public static ResultErrorCode codeOf(int code) {
        for(ResultErrorCode resultErrorCodeEnum : values()) {
            if(resultErrorCodeEnum.getCode() == code) {
                return resultErrorCodeEnum;
            }
        }
        throw new RuntimeException("没有找到对应枚举");
    }
}
