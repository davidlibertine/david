package com.ilabservice.intelab.mqtt;

/**
 * 
 * @author RedWall
 * @date 2018/5/19
 * @desc mqtt接收消息后需要处理
 * 
**/
public interface MsgReceiveHandler {

    /**
     * @author RedWall
     * @mail walkmanlucas@gmail.com
     * @param
     * @date 2018/5/18
     * @desc 处理消息
     * @return
     **/
    void handlerMsg(String clientMsg);

}
