package com.ilabservice.intelab.mqtt;

/**
* @author RedWall
* @mail walkmanlucas@gmail.com
* @date 2018/5/18
* @desc mqtt 处理
**/
public interface MqttClientHandler {


    IotMqttClient initClient(String username, String password, String broker, String clientId, String topic, MsgReceiveHandler msgReceiveHandler);

    void connect(IotMqttClient iotMqttClient);

    void sendMsg(IotMqttClient iotMqttClient,String msg) throws Exception;

}