package com.ilabservice.intelab.message.sms.aliyun;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.ilabservice.intelab.message.sms.SmsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class AliyunMessageManager implements SmsService {

    private static Logger LOGGER = LoggerFactory.getLogger(AliyunMessageManager.class);

    //产品名称:云通信短信API产品,开发者无需替换
    private static final String product = "Dysmsapi";
    //产品域名,开发者无需替换
    private static final String domain = "dysmsapi.aliyuncs.com";
    //验证码短信签名绑定手机号
    private static final String MessageSign1 = "INTELAB绑定手机";
    //设备警报短信签名设备警报
    private static final String MessageSign2 = "INTELAB设备报警";
    //找回密码短信签名找回密码
    private static final String MessageSign3 = "INTELAB找回密码";

    private String accessKeyId;
    private String accessKeySecret;
    private Map<String, String> templateCodes;

    public AliyunMessageManager(String accessKeyId, String accessKeySecret, Map<String, String> templateCodes) {
        this.accessKeyId = accessKeyId;
        this.accessKeySecret = accessKeySecret;
        this.templateCodes = templateCodes;
    }

    @Override
    public boolean sendSms(String verifyMobile, String message, Integer type, Map<String, String> messageMap) {
        //可自助调整超时时间
        System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
        System.setProperty("sun.net.client.defaultReadTimeout", "10000");

        SendSmsResponse sendSmsResponse = null;
        try {
            // 短信发送报警信息
            if (type.equals(1)) {
                //初始化acsClient,暂不支持region化
                IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", accessKeyId, accessKeySecret);
                DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
                IAcsClient acsClient = new DefaultAcsClient(profile);

                //组装请求对象-具体描述见控制台-文档部分内容
                SendSmsRequest request = new SendSmsRequest();
                //必填:待发送手机号
                request.setPhoneNumbers(verifyMobile);
                //必填:短信签名-可在短信控制台中找到
                request.setSignName(MessageSign2);
                //可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${code}"时,此处的值为
                switch (messageMap.get("type")) {
                    case "参数":
                        //必填:短信模板-可在短信控制台中找到
                        request.setTemplateCode(templateCodes.get("alertModel"));
                        request.setTemplateParam("{\"deviceName\":\"" + messageMap.get("deviceName") + "\", \"time\":\"" + messageMap.get("time") + "\", " +
                                "\"alertName\":\"" + messageMap.get("alertName") + "\", \"standard\":\"" + messageMap.get("standard") + "\", " +
                                "\"value\":\"" + messageMap.get("value") + "\", \"doorAlert\":\"" + messageMap.get("doorAlert") + "\", " +
                                "\"location\":\"" + messageMap.get("location") + "\", \"deviceId\":\"" + messageMap.get("deviceId") + "\"}");
                        break;
                    case "离线提示":
                        //必填:短信模板-可在短信控制台中找到
                        request.setTemplateCode(templateCodes.get("noticeAlert"));
                        request.setTemplateParam("{\"location\":\"" + messageMap.get("location") + "\", \"deviceName\":\"" +
                                messageMap.get("deviceName") + "\", \"time\":\"" + messageMap.get("time") + "\"}");
                        break;
                    default:
                        //必填:短信模板-可在短信控制台中找到
                        request.setTemplateCode(templateCodes.get("offlineAlert"));
                        request.setTemplateParam("{\"deviceName\":\"" + messageMap.get("deviceName") + "\", \"time\":\"" + messageMap.get("time") + "\", " +
                                "\"alertName\":\"" + messageMap.get("alertName") + "\", " +
                                "\"location\":\"" + messageMap.get("location") + "\", \"deviceId\":\"" + messageMap.get("deviceId") + "\"}");
                        break;
                }
                sendSmsResponse = acsClient.getAcsResponse(request);
            } else if (type.equals(0)) {
                // 短信发送验证码
                //初始化acsClient,暂不支持region化
                IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", accessKeyId, accessKeySecret);
                DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
                IAcsClient acsClient = new DefaultAcsClient(profile);

                //组装请求对象-具体描述见控制台-文档部分内容
                SendSmsRequest request = new SendSmsRequest();
                //必填:待发送手机号
                request.setPhoneNumbers(verifyMobile);
                //必填:短信签名-可在短信控制台中找到
                request.setSignName(MessageSign1);
                //必填:短信模板-可在短信控制台中找到
                request.setTemplateCode(templateCodes.get("verifyModel"));
                //可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${code}"时,此处的值为
                request.setTemplateParam("{\"code\":\"" + message + "\"}");

                //请求失败这里会抛ClientException异常
                sendSmsResponse = acsClient.getAcsResponse(request);
            } else if (type.equals(2)) {
                // 短信找回密码
                //初始化acsClient,暂不支持region化
                IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", accessKeyId, accessKeySecret);
                DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
                IAcsClient acsClient = new DefaultAcsClient(profile);

                //组装请求对象-具体描述见控制台-文档部分内容
                SendSmsRequest request = new SendSmsRequest();
                //必填:待发送手机号
                request.setPhoneNumbers(verifyMobile);
                //必填:短信签名-可在短信控制台中找到
                request.setSignName(MessageSign3);
                //必填:短信模板-可在短信控制台中找到
                request.setTemplateCode(templateCodes.get("passwordModel"));
                //可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${code}"时,此处的值为
                request.setTemplateParam("{\"code\":\"" + message + "\"}");

                //请求失败这里会抛ClientException异常
                sendSmsResponse = acsClient.getAcsResponse(request);
            }
            if (sendSmsResponse != null && sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
                //请求成功
                LOGGER.info(String.format("Successfully send SMS to %s. %s",
                        verifyMobile,
                        message));
                return true;
            } else if (sendSmsResponse != null && sendSmsResponse.getCode() != null){
                LOGGER.warn(String.format("Failed to send SMS to %s. errCode %s, %s",
                        verifyMobile,
                        sendSmsResponse.getCode(),
                        sendSmsResponse.getMessage()));
                return false;
            } else {
                return false;
            }
        } catch (Exception e) {
            LOGGER.error(String.format("Exception happened in sending SMS to cellphone %s. Err: %s",
                    verifyMobile,
                    e.toString()));
            return false;
        }
    }
}
