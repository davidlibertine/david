package com.ilabservice.intelab.mqtt;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Data
/**
 * 
 * @author RedWall
 * @date 2018/5/19
 * @desc 已废弃
 * 
**/
@Deprecated
public class ClientHandler {

    private static final Logger log = LoggerFactory.getLogger(ClientHandler.class);

    private MsgReceiveHandler msgReceiveHandler;

    private ClientHandler(){}

    public ClientHandler(MsgReceiveHandler msgReceiveHandler){
        this.msgReceiveHandler = msgReceiveHandler;
    }

    public void handlerMsg(String clientMsg){
        log.info("开始处理消息--" + clientMsg);
        msgReceiveHandler.handlerMsg(clientMsg);
        log.info("处理消息----end");
    }


}
