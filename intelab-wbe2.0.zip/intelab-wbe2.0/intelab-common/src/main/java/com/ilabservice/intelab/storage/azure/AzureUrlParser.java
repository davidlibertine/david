package com.ilabservice.intelab.storage.azure;

import java.util.HashMap;
import java.util.Map;

public class AzureUrlParser {

    public static Map<String, String> parseAzureUrl(String url) {
        if(url == null || !url.startsWith("http")){
            return null;
        }
        int firstSlash = url.indexOf("//", 0);
        if (firstSlash == -1) {
            return null;
        }
        int secondSlash = url.indexOf('/', firstSlash + 2);
        if (secondSlash == -1) {
            return null;
        }
        int thirdSlash = url.indexOf('/', secondSlash + 1);
        Map<String, String> resultMap = new HashMap<>();
        resultMap.put("containerName", url.substring(secondSlash + 1, thirdSlash));
        resultMap.put("blobName", url.substring(thirdSlash + 1));
        System.out.println("second: " + secondSlash + ", third: " + thirdSlash + ", url: " + url);
        return resultMap;
    }

}
