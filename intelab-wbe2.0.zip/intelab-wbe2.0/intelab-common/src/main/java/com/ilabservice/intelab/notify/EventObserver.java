package com.ilabservice.intelab.notify;

/**
* @author RedWall
* @mail walkmanlucas@gmail.com
* @param
* @date 2018/5/18
* @desc 
* @return 
**/
public interface EventObserver {

    /**
     * 消息通知
     * @param info 消息
     */
    void onEvent(Object info);

}
