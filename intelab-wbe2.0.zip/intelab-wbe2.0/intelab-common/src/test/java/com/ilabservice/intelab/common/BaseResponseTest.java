package com.ilabservice.intelab.common;

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* BaseResponse Tester. 
* 
* @author <Authors name> 
* @since <pre>五月 19, 2018</pre> 
* @version 1.0 
*/ 
public class BaseResponseTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 

/** 
* 
* Method: getMessage() 
* 
*/ 
@Test
public void testGetMessage() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setMessage(String message) 
* 
*/ 
@Test
public void testSetMessage() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: getStatus() 
* 
*/ 
@Test
public void testGetStatus() throws Exception { 
//TODO: Test goes here... 
} 

/** 
* 
* Method: setStatus(int status) 
* 
*/ 
@Test
public void testSetStatus() throws Exception { 
//TODO: Test goes here... 
} 


} 
