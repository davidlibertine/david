package com.ilabservice.intelab.mapper;

import com.ilabservice.intelab.model.DeviceFiles;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-14 09:23:08
 */
@Mapper
public interface DeviceFilesMapper extends BaseMapper<DeviceFiles> {
	
}
