package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Data
@ApiModel(value = "monitoring_target_measure_type_map")
@TableName("monitoring_target_measure_type_map")
public class MonitoringTargetMeasureTypeMap extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private Integer monitoringTargetId;
	
    @ApiModelProperty(value = "")
    private Integer measureTypeId;

    @TableField(exist = false)
    private MonitoringTarget monitoringTarget;

    @TableField(exist = false)
    private MeasureType measureType;
	

}
