package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableField;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.ilabservice.intelab.model.BaseEntity;
import com.ilabservice.intelab.common.annotation.EnableParam;
import com.ilabservice.intelab.common.annotation.FillAuto;

import java.util.Date;
import java.util.List;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-14 09:23:08
 */
@Data
@ApiModel(value = "lab_device")
@TableName("lab_device")
public class LabDevice extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private String name;
	
    @ApiModelProperty(value = "")
    @TableField(value = "purchase_date")
    private String purchaseDate;
	
    @ApiModelProperty(value = "")
    private String photo;
	
    @ApiModelProperty(value = "")
    private String manufacturer;
	
    @ApiModelProperty(value = "")
    private String model;
	
    @ApiModelProperty(value = "")
    @TableField(value = "health_score")
    private Float healthScore;
	
    @ApiModelProperty(value = "")
    @TableField(value = "create_datetime")
    private Date createDatetime;
	
    @ApiModelProperty(value = "")
    @TableField(value = "asset_id")
    private String assetId;
	
    @ApiModelProperty(value = "")
    @TableField(value = "product_line")
    private String productLine;
	
    @ApiModelProperty(value = "")
    private String brand;
	
    @ApiModelProperty(value = "")
    @TableField(value = "block_chain_key")
    private String blockChainKey;
	
    @ApiModelProperty(value = "")
    @TableField(value = "enable_sharing")
    private Integer enableSharing;
	
    @ApiModelProperty(value = "")
    @TableField(value = "lease_clause")
    private String leaseClause;
	
    @ApiModelProperty(value = "")
    @TableField(value = "lease_price_per_hour")
    private Float leasePricePerHour;
    @TableField(exist = false)
    private Location location;
    @TableField(exist = false)
    private List<DeviceFiles> deviceFiles;
    @TableField(exist = false)
    private List<MonitoringTarget> monitoringTargets;
    @TableField(exist = false)
    private MonitoringTargetType monitoringTargetType;
	

}
