package com.ilabservice.intelab.mapper;

import com.ilabservice.intelab.model.CompanyExtraFeatureMap;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-09 21:06:04
 */
@Mapper
public interface CompanyExtraFeatureMapMapper extends BaseMapper<CompanyExtraFeatureMap> {

    List<CompanyExtraFeatureMap> selectCompanyExtraListByCompanyId(@Param("companyId") Integer companyId);

    Integer addOneOrMoreProductFeaturesTCompany(@Param("list") List<Integer> list);

    Integer deleteOneOrMorefeaturessFromTheCompanyId(@Param("companyId") Integer companyId, @Param("featuresIdList") List<Integer> featuresIdList);
	
}
