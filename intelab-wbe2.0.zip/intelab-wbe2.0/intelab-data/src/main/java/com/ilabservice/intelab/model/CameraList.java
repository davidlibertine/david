package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.ibatis.type.Alias;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Data
@ApiModel(value = "camera_list")
@TableName("camera_list")
@Alias("camera_list")
public class CameraList extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private String name;
	
    @ApiModelProperty(value = "")
    private Integer monitoringTargetId;
	
    @ApiModelProperty(value = "")
    private String serialNo;
	
    @ApiModelProperty(value = "")
    private String playUrl;
	
    @ApiModelProperty(value = "")
    private String description;

    @TableField(exist = false)
    private MonitoringTarget monitoringTarget;
}
