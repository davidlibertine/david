package com.ilabservice.intelab.model;

import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.util.Date;


/**
 *
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-04-27 21:23:55
 */
@Data
@ApiModel(value = "permission")
@TableName("permission")
public class Permission extends BaseEntity{

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;

    @ApiModelProperty(value = "")
    private String permissionType;

    @ApiModelProperty(value = "")
    private String name;

    @ApiModelProperty(value = "")
    private String description;

    @ApiModelProperty(value = "")
    private Date createDatetime;


}