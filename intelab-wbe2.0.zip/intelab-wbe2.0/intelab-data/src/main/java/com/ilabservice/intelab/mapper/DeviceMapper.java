package com.ilabservice.intelab.mapper;

import com.ilabservice.intelab.model.Device;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Mapper
public interface DeviceMapper extends BaseMapper<Device> {
	
}
