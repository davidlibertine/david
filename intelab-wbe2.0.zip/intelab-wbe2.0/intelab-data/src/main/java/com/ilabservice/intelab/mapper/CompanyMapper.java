package com.ilabservice.intelab.mapper;

import com.ilabservice.intelab.model.Company;
import com.ilabservice.intelab.model.CompanyContract;
import com.ilabservice.intelab.model.ExtraFeature;
import com.ilabservice.intelab.model.Location;
import com.ilabservice.intelab.vo.CompanyVo;
import com.baomidou.mybatisplus.mapper.BaseMapper;

import java.io.Serializable;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CompanyMapper extends BaseMapper<Company> {
	public Company selectCompanyById(Serializable companyId);
	public List<ExtraFeature> findListExtraFeatureByCompanyId(Serializable companyId);
    public List<CompanyContract> findListCompanyContractByCompanyId(Serializable companyId);
    public int findCompanyCount();
    public int updateCompanyInfo(Location location);
    public int  createCompany(Company company);
}