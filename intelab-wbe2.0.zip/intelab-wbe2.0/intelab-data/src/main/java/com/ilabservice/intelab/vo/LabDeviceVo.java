package com.ilabservice.intelab.vo;

import com.ilabservice.intelab.model.DeviceFiles;
import com.ilabservice.intelab.model.MonitoringTargetMeasureRule;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LabDeviceVo {

    private Integer id;

    private String name;

    private String brand;

    private String model;

    private String assetId;

    private Date createTime;

    private String serialNo;

    private String productLine;

    private String purchaseDate;

    private String photo;

    private Integer ownerId;

    private Float xCoordinate;

    private Float yCoordinate;

    private Integer locationId;

    private String locationBackground;

    private Integer monitorTargetTypeId;

    private String monitorTargetTypeName;

    private MonitoringTargetMeasureRule measureRules;

    private DeviceFiles files;

    private Integer enableSharing;

    private String blockchainKey;

    private String leaseClause;

    private Float leasePrice;

    private Integer latesteRunningStatue;

}
