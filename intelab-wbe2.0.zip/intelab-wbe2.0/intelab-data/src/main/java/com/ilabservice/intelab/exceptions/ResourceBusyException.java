package com.ilabservice.intelab.exceptions;

import com.ilabservice.intelab.object.object.ResourceBasic;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.CONFLICT, reason = "resource busy")
public class ResourceBusyException extends RuntimeException {

    private ResourceBasic resourceBasic;
    public ResourceBasic getResourceBasic() {
        return resourceBasic;
    }

    public void setResourceBasic(ResourceBasic resourceBasic) {
        this.resourceBasic = resourceBasic;
    }



    public ResourceBusyException(String message, Integer id, String... params){
        super(message);
        resourceBasic = new ResourceBasic();
        resourceBasic.setId(id);

        if(params.length > 0){
            resourceBasic.setType(params[0]);
        }
        if(params.length > 1){
            resourceBasic.setDesc(params[1]);
        }

    }
}
