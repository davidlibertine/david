package com.ilabservice.intelab.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MonitorTargetLabDevice {

    private String name;

    private String serialNumber; //11

    private String model;

    private String brand;

    private String assetId;

    private String productLine;

    private Integer enableSharing;

    private Integer leaseCause;

    private Float leasePricePerHour;

    private String manufacture;

    private String perchaseDate;

    private Integer locationId;

    private String profileImage;

}
