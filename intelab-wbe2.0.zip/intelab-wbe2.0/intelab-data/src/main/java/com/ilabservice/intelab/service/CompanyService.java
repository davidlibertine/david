package com.ilabservice.intelab.service;

import java.io.Serializable;
import java.util.List;

import javax.swing.text.StyledEditorKit.BoldAction;

import com.ilabservice.intelab.model.CompanyContractExtend;
import com.ilabservice.intelab.model.CompanyExtend;
import org.springframework.web.multipart.MultipartFile;

import com.ilabservice.intelab.model.Company;
import com.ilabservice.intelab.model.CompanyContract;
import com.ilabservice.intelab.service.base.BaseService;
import com.ilabservice.intelab.vo.CompanyContractVo;
import com.ilabservice.intelab.vo.CompanyVo;

public interface CompanyService extends BaseService<Company>{
	public Company selectCompanyAndExtraFeatureById(Serializable companyId);
	public List<Company> getAdminCompanysPage(Integer limit, Integer offset);
	public List<CompanyContract> findListCompanyContractByCompanyId(Serializable companyId);
	public CompanyContract addCompanyContract(CompanyContractExtend companyContractExtend, Serializable companyId)throws Exception;
	public int findCompanyCount();
	public Company getCompanyById(Integer id);
	public void updateCompany(Company company);
    public boolean updateCompanyContract(CompanyContractExtend companyContractExtend, Serializable contractId)throws Exception;
    public Company updateCompanyInfo(MultipartFile file, CompanyExtend companyExtend, Integer id) throws Exception;
    public Company createCompanyInfo(MultipartFile file, List<Integer> featureIdList, CompanyExtend companyExtend);
}
