package com.ilabservice.intelab.vo.assemblyvo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ilabservice.intelab.model.Company;
import com.ilabservice.intelab.model.CompanyContract;
import com.ilabservice.intelab.model.ExtraFeature;
import com.ilabservice.intelab.vo.CompanyContractVo;
import com.ilabservice.intelab.vo.CompanyVo;


public class CompanyVoMapper {
	public static CompanyVo getLoginUserCompanyAndExtraFeatures(Company company) {
		CompanyVo companyVo=new CompanyVo();
		companyVo.setId(company.getId());
		companyVo.setName(company.getName());
		companyVo.setAddress(company.getAddress());
		companyVo.setEmail(company.getEmail());
		companyVo.setDomainName(company.getDomainName());
		companyVo.setTelephone(company.getTelephone());
		companyVo.setBackgroundUrl(company.getBackgroundUrl());
		List<ExtraFeature> extraFeatures=company.getExtraFeatures();
		companyVo.setExtraFeatures(extraFeatures);
		return companyVo;
	}
	public static List<CompanyVo> getAdminCompany(List<Company> companies) {
		List<CompanyVo> companyVos=new ArrayList<>();
		for (Company company: companies) {
			CompanyVo companyVo=new CompanyVo();
			companyVo.setId(company.getId());
			companyVo.setName(company.getName());
			companyVo.setLogo(company.getBackgroundUrl());
			companyVos.add(companyVo);
		}
		
		return companyVos;
	}
	public static CompanyContractVo addCompanyContract(CompanyContract companyContract){
		CompanyContractVo companyContractVo=new CompanyContractVo();
		companyContractVo.setCompanyId(companyContract.getCompanyId());
		companyContractVo.setStartDate(companyContract.getStartDate().getTime());
		companyContractVo.setEndDate(companyContract.getEndDate().getTime());
		companyContractVo.setSignDate(companyContract.getSignDate().getTime());
		companyContractVo.setDescription(companyContract.getDescription());
		return companyContractVo;
	}
	public static  List<CompanyContractVo> findCompanyContractByCompanyId(List<CompanyContract> companyContracts){
		List<CompanyContractVo> companyContractVos=new ArrayList<>();
		for(CompanyContract companyContract:companyContracts){
			CompanyContractVo companyContractVo=new CompanyContractVo();
			companyContractVo.setCompanyId(companyContract.getCompanyId());
			companyContractVo.setStartDate(companyContract.getStartDate().getTime());
			companyContractVo.setEndDate(companyContract.getEndDate().getTime());
			companyContractVo.setSignDate(companyContract.getSignDate().getTime());
			companyContractVo.setDescription(companyContract.getDescription());
			companyContractVos.add(companyContractVo);

		}
		return companyContractVos;
	}

}
