package com.ilabservice.intelab.model;

import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.ilabservice.intelab.model.BaseEntity;
import com.ilabservice.intelab.common.annotation.EnableParam;
import com.ilabservice.intelab.common.annotation.FillAuto;

import javax.management.monitor.Monitor;
import java.util.List;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-09 15:42:09
 */
@Data
@ApiModel(value = "user_location_monitoring_target")
@TableName("user_location_monitoring_target")
public class UserLocationMonitoringTarget extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    @TableField(value="user_id")
    private Integer userId;
	
    @ApiModelProperty(value = "")
    @TableField(value="location_id")
    private Integer locationId;
	
    @ApiModelProperty(value = "")
    @TableField(value="target_id")
    private Integer targetId;
	
}
