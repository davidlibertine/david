package com.ilabservice.intelab.vo;

import com.ilabservice.intelab.model.Permission;
import com.ilabservice.intelab.model.Role;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginUserRolesVo {

    Role roles;

    List<Permission> permissions;
}
