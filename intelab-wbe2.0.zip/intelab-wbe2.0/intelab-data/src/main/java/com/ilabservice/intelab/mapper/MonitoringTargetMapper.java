package com.ilabservice.intelab.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ilabservice.intelab.model.LeaseRecord;
import com.ilabservice.intelab.model.MonitoringTarget;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Mapper
public interface MonitoringTargetMapper extends BaseMapper<MonitoringTarget> {

    MonitoringTarget selectByUserId(@Param("userId") Integer userId);

    Integer addMonitoringTarget(MonitoringTarget monitoringTarget);
}
