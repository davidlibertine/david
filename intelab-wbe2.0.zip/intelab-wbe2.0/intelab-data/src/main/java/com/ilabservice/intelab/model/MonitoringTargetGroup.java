package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Data
@ApiModel(value = "monitoring_target_group")
@TableName("monitoring_target_group")
public class MonitoringTargetGroup extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private String groupName;
	
    @ApiModelProperty(value = "")
    private String groupDesc;
	
    @ApiModelProperty(value = "")
    private Integer isDynamic;
	
    @ApiModelProperty(value = "")
    private String dynamicGroupRule;
	
    @ApiModelProperty(value = "")
    private Integer parentGroupId;
	
    @ApiModelProperty(value = "")
    private Date createDatetime;

}
