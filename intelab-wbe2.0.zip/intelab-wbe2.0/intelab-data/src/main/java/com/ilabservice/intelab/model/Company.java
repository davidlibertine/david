package com.ilabservice.intelab.model;

import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;
import java.util.List;


import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.ilabservice.intelab.model.BaseEntity;
import com.ilabservice.intelab.common.annotation.EnableParam;
import com.ilabservice.intelab.common.annotation.FillAuto;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-09 21:06:04
 */
@Data
@ApiModel(value = "company")
@TableName("company")
public class Company extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    @TableField(value="domain_name")
    private String domainName;
	
    @ApiModelProperty(value = "")
    private String name;
	
    @ApiModelProperty(value = "")
    private String address;
	
    @ApiModelProperty(value = "")
    private String email;
	
    @ApiModelProperty(value = "")
    private String telephone;
	
    @ApiModelProperty(value = "")
    @TableField(value="background_url")
    private String backgroundUrl;
	
    @ApiModelProperty(value = "")
    @TableField(value="create_datetime")
    private Date createDatetime;
	
    @ApiModelProperty(value = "")
    @TableField(value="login_url")
    private String loginUrl;
	
    @ApiModelProperty(value = "")
    @TableField(value="update_datetime")
    private Date updateDatetime;
	
    @ApiModelProperty(value = "")
    @TableField(value="block_chain_address")
    private String blockChainAddress;
	
    /**
     * After deletion operation, it becomes false, only for admin analysis
     */
    @ApiModelProperty(value = "After deletion operation, it becomes false, only for admin analysis")
    @TableField(value="is_enabled")
    private Integer isEnabled;
    
    @TableField(exist=false)
    private CompanyContract companyContract;
    
    @TableField(exist=false)
    private List<ExtraFeature> extraFeatures;
    
  
	

}
