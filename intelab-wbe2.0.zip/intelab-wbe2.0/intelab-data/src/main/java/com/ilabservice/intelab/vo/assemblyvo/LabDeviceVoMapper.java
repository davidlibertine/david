package com.ilabservice.intelab.vo.assemblyvo;

import com.ilabservice.intelab.model.*;
import com.ilabservice.intelab.vo.LabDeviceVo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class LabDeviceVoMapper {

    public static LabDeviceVo getLabDeviceVo(Map<String, Object> map) {

        Location location = (Location) map.get("location");
        MonitoringTargetMeasureRule monitoringTargetMeasureRule = (MonitoringTargetMeasureRule)map.get("measureRules");
        LabDevice labDevice1 = (LabDevice)map.get("labDevice");
        DeviceFiles deviceFiles = (DeviceFiles)map.get("deviceFiles");
        MonitoringTarget monitoringTarget = (MonitoringTarget)map.get("monitoringTarget");


        /**
         * 组装对象
         */
        LabDeviceVo labDeviceVo = new LabDeviceVo();
        labDeviceVo.setId(labDevice1.getId());
        labDeviceVo.setName(labDevice1.getName());
        labDeviceVo.setBrand(labDevice1.getBrand());
        labDeviceVo.setModel(labDevice1.getModel());
        labDeviceVo.setAssetId(labDevice1.getAssetId());
        labDeviceVo.setCreateTime(labDevice1.getCreateDatetime());
        labDeviceVo.setSerialNo(monitoringTarget.getSerialNo());
        labDeviceVo.setProductLine(labDevice1.getProductLine());
        labDeviceVo.setPurchaseDate(labDevice1.getPurchaseDate());
        labDeviceVo.setPhoto(labDevice1.getPhoto());
        labDeviceVo.setOwnerId(monitoringTarget.getOwnerId());
        labDeviceVo.setXCoordinate(location.getXLocation());
        labDeviceVo.setYCoordinate(location.getYLocation());
        labDeviceVo.setLocationId(monitoringTarget.getLocationId());
        labDeviceVo.setLocationBackground(deviceFiles.getUrl());
        labDeviceVo.setMonitorTargetTypeId(monitoringTarget.getMonitoringTargetTypeId());
        labDeviceVo.setMonitorTargetTypeName(monitoringTarget.getName());

        labDeviceVo.setMeasureRules(monitoringTargetMeasureRule);
        labDeviceVo.setFiles(deviceFiles);

        labDeviceVo.setEnableSharing(labDevice1.getEnableSharing());
        labDeviceVo.setBlockchainKey(labDevice1.getBlockChainKey());
        labDeviceVo.setLeaseClause(labDevice1.getLeaseClause());
        labDeviceVo.setLeasePrice(labDevice1.getLeasePricePerHour());
        labDeviceVo.setLatesteRunningStatue(monitoringTarget.getLatestRunningStatus());

        return labDeviceVo;
    }
    public static List<LabDeviceVo> getListLabDeviceVo(List<LabDevice> labDevices){
        List<LabDeviceVo> labDeviceVos=new ArrayList<>();
//        for(LabDevice labDevice1:labDevices){
//            LabDeviceVo labDeviceVo=new LabDeviceVo();
//            labDeviceVo.setId(labDevice1.getId());
//            labDeviceVo.setName(labDevice1.getName());
//            labDeviceVo.setBrand(labDevice1.getBrand());
//            labDeviceVo.setModel(labDevice1.getModel());
//            labDeviceVo.setAssetId(labDevice1.getAssetId());
//            labDeviceVo.setCreateTime(labDevice1.getCreateDatetime());
//
//            labDeviceVo.setSerialNo(monitoringTarget.getSerialNo());
//            labDeviceVo.setProductLine(labDevice1.getProductLine());
//            labDeviceVo.setPurchaseDate(labDevice1.getPurchaseDate());
//            labDeviceVo.setPhoto(labDevice1.getPhoto());
//            List<MonitoringTarget> monitoringTargets=labDevice1.getMonitoringTargets();
//            labDeviceVo.setOwnerId(monitoringTargets.get(0).getOwnerId());
//            Location location=labDevice1.getLocation();
//            labDeviceVo.setXCoordinate(location.getXLocation());
//            labDeviceVo.setYCoordinate(location.getYLocation());
//            labDeviceVo.setLocationId(location.getId());
//            labDeviceVo.setLocationBackground(location.getBackground());
//            MonitoringTargetType monitoringTargetType=labDevice1.getMonitoringTargetType();
//            labDeviceVo.setMonitorTargetTypeId(monitoringTargetType.getId());
//            labDeviceVo.setMonitorTargetTypeName(monitoringTargetType.getName());
//
//            labDeviceVo.setMeasureRules(monitoringTargetMeasureRule);
//            List<DeviceFiles> deviceFiles=labDevice1.getDeviceFiles();
//            labDeviceVo.setFiles(deviceFiles);
//
//            labDeviceVo.setEnableSharing(labDevice1.getEnableSharing());
//            labDeviceVo.setBlockchainKey(labDevice1.getBlockChainKey());
//            labDeviceVo.setLeaseClause(labDevice1.getLeaseClause());
//            labDeviceVo.setLeasePrice(labDevice1.getLeasePricePerHour());
//            labDeviceVo.setLatesteRunningStatue(monitoringTarget.getLatestRunningStatus());

            return null;
        }

}
