package com.ilabservice.intelab.vo.assemblyvo;

import com.ilabservice.intelab.model.MonitoringTargetType;
import com.ilabservice.intelab.vo.MonitoringTargetTypeVo;

import java.util.ArrayList;
import java.util.List;
/*
private Integer id;
    private String name;
    private Integer companyId;
    private String description;
    private String logoUrl;
    List<MeasureType> measureTypes;
 */
public class MonitoringTargetTypeVoMapper {
    public static List<MonitoringTargetTypeVo> getAllMonitoringTargetType(List<MonitoringTargetType> monitoringTargetTypes){
        List<MonitoringTargetTypeVo> monitoringTargetTypeList=new ArrayList<>();
        for (MonitoringTargetType monitoringTargetType:monitoringTargetTypes){
            MonitoringTargetTypeVo monitoringTargetTypeVo=new MonitoringTargetTypeVo();
            monitoringTargetTypeVo.setId(monitoringTargetType.getId());
            monitoringTargetTypeVo.setCompanyId(monitoringTargetType.getCompanyId());
            monitoringTargetTypeVo.setDescription(monitoringTargetType.getDescription());
            monitoringTargetTypeVo.setLogoUrl(monitoringTargetType.getLogoUrl());
            monitoringTargetTypeVo.setMeasureTypes(monitoringTargetType.getMeasureTypes());
            monitoringTargetTypeList.add(monitoringTargetTypeVo);

        }
        return monitoringTargetTypeList;
    }
    public static MonitoringTargetTypeVo getMonitoringTargetType(MonitoringTargetType monitoringTargetType){
        MonitoringTargetTypeVo monitoringTargetTypeVo=new MonitoringTargetTypeVo();
        monitoringTargetTypeVo.setId(monitoringTargetType.getId());
        monitoringTargetTypeVo.setCompanyId(monitoringTargetType.getCompanyId());
        monitoringTargetTypeVo.setDescription(monitoringTargetType.getDescription());
        monitoringTargetTypeVo.setLogoUrl(monitoringTargetType.getLogoUrl());
        monitoringTargetTypeVo.setMeasureTypes(monitoringTargetType.getMeasureTypes());
        return monitoringTargetTypeVo;
    }
}

