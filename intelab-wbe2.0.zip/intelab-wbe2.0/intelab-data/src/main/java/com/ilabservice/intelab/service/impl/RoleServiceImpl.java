package com.ilabservice.intelab.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.PermissionMapper;
import com.ilabservice.intelab.mapper.RoleMapper;
import com.ilabservice.intelab.mapper.RolePermissionMapMapper;
import com.ilabservice.intelab.mapper.UserRolesMapper;
import com.ilabservice.intelab.model.Permission;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.RolePermissionMap;
import com.ilabservice.intelab.model.UserRolesMap;
import com.ilabservice.intelab.service.RoleService;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class RoleServiceImpl implements RoleService {


    @Resource
    private RoleMapper roleMapper;

    @Resource
    private UserRolesMapper userRolesMapper;

    @Resource
    private RolePermissionMapMapper rolePermissionMapMapper;

    @Resource
    private PermissionMapper permissionMapper;

    /**
     * 查询所有用户角色
     * @return
     */
    @Override
    public List<Role> getAllUserRoles() {
        List<Role> roleList = roleMapper.getAllUserRoles();
        return roleList != null ? roleList : null;
    }

    /**
     * 删除指定角色
     * @param id
     * @return
     */
    @Override
    public Boolean deleteRoleByRoleId(Integer id) throws UserException {
        /**
         * 删除之前需要先校验该角色是否已经绑定了用户和权限，如果绑定则不允许删除
         */
        UserRolesMap userRolesMap = userRolesMapper.getUserRolesMapByRoleId(id);
        RolePermissionMap rolePermissionMap = rolePermissionMapMapper.getUserRolePermissionMapByRoleId(id);
        if(userRolesMap != null || rolePermissionMap != null ) {
            return false;
        }
        return roleMapper.deleteById(id) > 0 ? true :false;
    }

    /**
     * 更新指定角色
     * @param id
     * @return
     */
    @Override
    public Boolean updateRoleByRoleId(Integer id, Role newRole) throws UserException {
        /**
         * 判断这个角色是否存在
         */
        Role role = roleMapper.getRoleById(id);
        if(role != null) {
            newRole.setId(id);
            return roleMapper.updateById(newRole) > 0 ? true : false;
        }
        return false;
    }

    /**
     * 新增角色
     * @param role
     * @return
     */
    @Override
    public Role addRole(Role role) throws UserException {
        role.setCreateDatetime(new Date());
        Integer count = roleMapper.insert(role);
        Role newRole = roleMapper.getRoleById(role.getId());
        if(count > 0) {
            return newRole != null ? newRole : null;
        }
        return null;
    }

    /**
     * 从指定角色删除一到多个权限
     * @param roleId
     * @param permissionIdList
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    @Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public Boolean deleteOneOrMorePermissionsFromTheSpecifiedRole(Integer roleId, List<Integer> permissionIdList) throws UserException {
        /**
         * 校验通过执行删除逻辑 删除出现异常直接回滚
         */
        if(!checks(roleId, permissionIdList)) {
            return false;
        }
        return rolePermissionMapMapper.deleteOneOrMorePermissionsFromTheSpecifiedRole(roleId, permissionIdList) > 0 ? true :false;
    }

    /**
     * 给指定角色添加一到多个权限
     * @param roleId
     * @param permissionIdList
     * @return
     */
    @Override
    public Boolean addOneToMultiplePermissionsToGivenRole(Integer roleId, List<Integer> permissionIdList) {
        if(checks(roleId, permissionIdList)) {
            Map<String, Integer> map = Maps.newHashMap();
            List list = Lists.newArrayList();
            for(Integer permissionId : permissionIdList) {
                map.put("roleId", roleId);
                map.put("permissionId", permissionId);
                list.add(map);
            }
            return rolePermissionMapMapper.addOneToMultiplePermissionsToGivenRole(list) > 0 ? true : false;
        }
        return false;
    }

    /**
     * 校验
     * @param id
     * @param integers
     * @return
     */
    private boolean checks(Integer id, List<Integer> integers) {
        Role role = roleMapper.selectById(id);
        if(role == null) {
            return false;
        }
        for(Integer permissionId : integers) {
            Permission permission = permissionMapper.selectById(permissionId);
            if(permission == null) {
                throw new UserException();
            }
        }
        return true;
    }
}
