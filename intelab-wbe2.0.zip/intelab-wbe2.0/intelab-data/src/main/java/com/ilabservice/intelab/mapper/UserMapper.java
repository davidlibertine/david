package com.ilabservice.intelab.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ilabservice.intelab.model.Permission;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.io.Serializable;
import java.util.List;

/**
 * 
 *
 * @author RedWall
 * @email walkmanlucas@gmail.com
 * @date 2018-04-18 14:41:05
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {

    List<Role> listAllRolesByUserid(Serializable userid);

    List<Permission> listAllPermissionsByRoleid(Serializable roleid);

    User getUserIdAndPasswordByUserName(Serializable userName);

    User getUserById(Serializable userId);

    Integer updateUserByPrimaryKeySelective(User user);

    List<User> getUserListByCompanyId(@Param("companyId") Integer companyId);
}
