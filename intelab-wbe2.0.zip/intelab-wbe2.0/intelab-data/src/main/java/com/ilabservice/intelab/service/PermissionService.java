package com.ilabservice.intelab.service;

import com.github.pagehelper.PageInfo;
import com.ilabservice.intelab.model.Permission;


public interface PermissionService {

    /**
     * 获取所有数据库中现存的权限
     * @return
     */
    PageInfo getAllPermission(Integer limit, Integer offset);

    /**
     * 新增一个权限
     * @param permission
     * @return
     */
    Permission addPermission(Permission permission);

    /**
     * 通过id删除一个权限
     * @param id
     * @return
     */
    Boolean deletePermission(Integer id);

    /**
     * 修改权限
     * @param id
     * @return
     */
    Boolean updatePermission(Integer id, Permission permission);
}
