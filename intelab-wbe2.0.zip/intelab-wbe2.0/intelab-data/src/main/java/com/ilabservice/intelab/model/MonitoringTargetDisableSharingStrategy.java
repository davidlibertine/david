package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Data
@ApiModel(value = "monitoring_target_disable_sharing_strategy")
@TableName("monitoring_target_disable_sharing_strategy")
public class MonitoringTargetDisableSharingStrategy extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private Integer monitoringTargetId;
	
    @ApiModelProperty(value = "")
    private String strategyType;
	
    @ApiModelProperty(value = "")
    private String content;

    @TableField(exist = false)
    private MonitoringTarget monitoringTarget;

}
