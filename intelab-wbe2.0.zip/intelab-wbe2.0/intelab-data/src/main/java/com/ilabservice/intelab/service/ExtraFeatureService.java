package com.ilabservice.intelab.service;

import com.ilabservice.intelab.model.ExtraFeature;

import java.util.List;

public interface ExtraFeatureService {

    /**
     * 查询指定公司的所有附加功能
     * @param id
     * @return
     */
    List<ExtraFeature> queryAllAdditionalFeaturesOfGivenCompany(Integer id);

    /**
     * 为一个公司增添一到多个产品功能
     * @param id
     * @param featuresIdList
     * @return
     */
    boolean addOneOrMoreProductFeaturesTCompany(Integer id, List<Integer> featuresIdList);

    /**
     * 从一个公司删除一到多个产品功能
     * @param id
     * @param featuresIdList
     * @return
     */
    boolean deleteOneOrMoreProductFeaturesTCompany(Integer id, List<Integer> featuresIdList);
}
