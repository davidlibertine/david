package com.ilabservice.intelab.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 該對象為VO眎圖層對象，專門用於返回給前端數據
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserVo {

    private Integer id;

    private String username;

    private String name;

    private String email;

    private String mobile;

    private String telephone;

    private String gender;

    private String headIcon;

    private String department;

    private String job;

    private String jobNum;

    private String companyDomainName;

    private Integer bindMobile;

    private Integer bindEmail;

    private Integer alertNotificationType;

    private Integer latestPasswordUpdateTime;
}
