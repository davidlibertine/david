package com.ilabservice.intelab.model;

import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.ilabservice.intelab.model.BaseEntity;
import com.ilabservice.intelab.common.annotation.EnableParam;
import com.ilabservice.intelab.common.annotation.FillAuto;

import java.util.Date;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Data
@ApiModel(value = "device")
@TableName("device")
public class Device extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private String code;
	
    @ApiModelProperty(value = "")
    private String name;
	
    @ApiModelProperty(value = "")
    private String purchaseDate;
	
    @ApiModelProperty(value = "")
    private String photo;
	
    @ApiModelProperty(value = "")
    private String manufacturer;
	
    @ApiModelProperty(value = "")
    private String productModel;
	
    @ApiModelProperty(value = "")
    private Float healthScore;
	
    @ApiModelProperty(value = "")
    private Date createDatetime;
	

}
