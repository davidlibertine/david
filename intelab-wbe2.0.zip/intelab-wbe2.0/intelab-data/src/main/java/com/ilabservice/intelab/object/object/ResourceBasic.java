package com.ilabservice.intelab.object.object;

import lombok.Data;

@Data
public class ResourceBasic {
    private Integer id;
    private String type;
    private String desc;
}
