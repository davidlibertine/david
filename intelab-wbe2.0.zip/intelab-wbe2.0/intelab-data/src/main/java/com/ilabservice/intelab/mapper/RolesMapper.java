package com.ilabservice.intelab.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ilabservice.intelab.model.Role;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RolesMapper extends BaseMapper<Role> {

}
