package com.ilabservice.intelab.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ilabservice.intelab.model.Role;
import org.apache.ibatis.annotations.Mapper;

import java.io.Serializable;
import java.util.List;

@Mapper
public interface RoleMapper extends BaseMapper<Role> {

    Role getRoleById(Serializable id);

    List<Role> getAllUserRoles();

    Integer addRole(Role role);

}
