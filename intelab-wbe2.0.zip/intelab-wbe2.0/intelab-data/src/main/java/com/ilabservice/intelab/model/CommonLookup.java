package com.ilabservice.intelab.model;

import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.ilabservice.intelab.model.BaseEntity;
import com.ilabservice.intelab.common.annotation.EnableParam;
import com.ilabservice.intelab.common.annotation.FillAuto;

import java.util.Date;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Data
@ApiModel(value = "common_lookup")
@TableName("common_lookup")
public class CommonLookup extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private String categoryName;
	
    @ApiModelProperty(value = "")
    private String categoryDesc;
	
    @ApiModelProperty(value = "")
    private String code;
	
    @ApiModelProperty(value = "")
    private String value;
	
    @ApiModelProperty(value = "")
    private Integer sortOrder;
	
    @ApiModelProperty(value = "")
    private Date createDatetime;
	

}
