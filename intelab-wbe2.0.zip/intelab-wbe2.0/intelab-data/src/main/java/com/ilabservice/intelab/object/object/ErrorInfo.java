package com.ilabservice.intelab.object.object;

import lombok.Data;

@Data
public class ErrorInfo<T> {
    /**
     * application error code, in addition to HTTP status code, classify the error in a higher granularity
     */
    private Integer code;
    /**
     * Error message
     */
    private String message;
    /**
     * Related data
     */
    private T data;
}
