package com.ilabservice.intelab.vo.assemblyvo;
import com.ilabservice.intelab.model.MonitoringTargetTypeMeasureRule;
import com.ilabservice.intelab.vo.MeasureRuleVo;

import java.util.ArrayList;
import java.util.List;

public class MeasureRuleVoMapper {
    public static List<MeasureRuleVo>  getMeasureRuleByMonitorTargetTypeId(List<MonitoringTargetTypeMeasureRule> monitoringTargetMeasureRules){
        List<MeasureRuleVo> measureRuleVos=new ArrayList<>();
        for(MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule:monitoringTargetMeasureRules){
            MeasureRuleVo measureRuleVo=new MeasureRuleVo();
            measureRuleVo.setId(monitoringTargetTypeMeasureRule.getId());
            measureRuleVo.setName(monitoringTargetTypeMeasureRule.getName());
            measureRuleVo.setMeasureTypeName(monitoringTargetTypeMeasureRule.getMeasureType().getName());
            measureRuleVo.setDefinition(monitoringTargetTypeMeasureRule.getDefinition());
            measureRuleVo.setPurpose(monitoringTargetTypeMeasureRule.getPurpose());
            measureRuleVos.add(measureRuleVo);
        }
        return measureRuleVos;
    }
}
