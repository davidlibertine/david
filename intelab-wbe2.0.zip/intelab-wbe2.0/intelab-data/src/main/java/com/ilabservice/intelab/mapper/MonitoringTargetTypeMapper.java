package com.ilabservice.intelab.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ilabservice.intelab.model.MeasureType;
import com.ilabservice.intelab.model.MonitoringTargetType;
import com.ilabservice.intelab.model.MonitoringTargetTypeMeasureRule;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @Author:david
 * @Description
 * @Date: 上午9:43 18-5-30
 */


@Mapper
public interface MonitoringTargetTypeMapper extends BaseMapper<MonitoringTargetType> {
    int findMonitorTargetTypeCount();
    List<MeasureType> findMeasureTypesByMonitoringTargetTypeId(Integer monitoringTargetTypeId);
    Integer addOneAndMoreMeasureTypeByMonitorTargetTypeId(@Param("list") List<Map> list);
    Integer deleteOneAndMoreMeasureTypeByMonitorTargetTypeId(@Param("monitoringTargetTypeId") Integer id,@Param("list") List<Integer> list);
    List<MonitoringTargetTypeMeasureRule> findmeasureRuleByMonitorTargetTypeId(Integer id);
    Integer addMonitoringTargetType(MonitoringTargetType monitoringTargetType);
    Integer deleteMeasureRuleByMonitoringTargetTypeIdAndMeasureRule(MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule);
}
