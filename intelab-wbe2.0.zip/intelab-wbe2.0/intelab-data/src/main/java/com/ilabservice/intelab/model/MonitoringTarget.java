package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Data
@ApiModel(value = "monitoring_target")
@TableName("monitoring_target")
public class MonitoringTarget extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private Integer locationId;
	
    @ApiModelProperty(value = "")
    private String serialNo;
	
    @ApiModelProperty(value = "")
    private Integer monitoringTargetTypeId;
	
    @ApiModelProperty(value = "")
    private String refTable;
	
    @ApiModelProperty(value = "")
    private Integer refTableId;

    @ApiModelProperty(value = "")
    private String name;
	
    @ApiModelProperty(value = "")
    private Integer ownerId;
	
    @ApiModelProperty(value = "")
    private Integer creatorId;
	
    @ApiModelProperty(value = "")
    private Date createDatetime;
	
    @ApiModelProperty(value = "")
    private Integer isEnabled;
	
    @ApiModelProperty(value = "")
    private String status;

    @ApiModelProperty(value = "")
    private Integer latestRunningStatus;

    @ApiModelProperty(value = "")
    private Integer companyId;
	
    @TableField(exist = false)
    private List<CameraList> cameraLists;

    @TableField(exist = false)
    private Company company;

    @TableField(exist = false)
    private User createUser;

    @TableField(exist = false)
    private User ownerUser;

    @TableField(exist = false)
    private Location location;

    @TableField(exist = false)
    private MonitoringTargetType monitoringTargetType;
    @TableField(exist = false)
    private LabDevice labDevice;
    @TableField(exist = false)
    private List<MonitoringTargetMeasureRule> monitoringTargetMeasureRules;
}
