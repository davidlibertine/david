package com.ilabservice.intelab.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.*;
import com.ilabservice.intelab.model.*;
import com.ilabservice.intelab.service.MonitoringTargetTypeService;
import com.ilabservice.intelab.service.base.impl.BaseServiceImpl;
import com.ilabservice.intelab.vo.MeasureRuleVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MonitoringTargetTypeServiceImpl extends BaseServiceImpl<MonitoringTargetTypeMapper,MonitoringTargetType> implements MonitoringTargetTypeService {
    @Autowired
    MonitoringTargetTypeMapper monitoringTargetTypeMapper;
    @Autowired
    MonitoringTargetTypeMeasureRuleMapper monitoringTargetTypeMeasureRuleMapper;
    @Autowired
    MonitoringTargetTypeMeasureTypeMapMapper monitoringTargetTypeMeasureTypeMapMapper;
    @Autowired
    MeasureTypeMapper measureTypeMapper;
    @Autowired
    MonitoringTargetMapper monitoringTargetMapper;
    @Override
    public List<MonitoringTargetType> findListAllMonitoringTargetType(Integer limit,Integer offset) {
        List<MonitoringTargetType> monitoringTargetTypes=monitoringTargetTypeMapper.selectPage(new Page<>(offset,limit),new EntityWrapper<>());
        for(MonitoringTargetType monitoringTargetType:monitoringTargetTypes){
            List<MeasureType> measureTypes=monitoringTargetTypeMapper.findMeasureTypesByMonitoringTargetTypeId(monitoringTargetType.getId());
            monitoringTargetType.setMeasureTypes(measureTypes);
        }
        return monitoringTargetTypes;
    }

    @Override
    @Transactional
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public MonitoringTargetType addMonitoringTargetType(List<Integer> measureTypes,MonitoringTargetType monitoringTargetType,String logoUrl) {
        MonitoringTargetType mt=new MonitoringTargetType();
        mt.setName(monitoringTargetType.getName());
        mt.setCompanyId(monitoringTargetType.getCompanyId());
        mt.setDescription(monitoringTargetType.getDescription());
        mt.setLogoUrl(logoUrl);
        Integer monitoringTargetTypeId = monitoringTargetTypeMapper.addMonitoringTargetType(mt);
        if(monitoringTargetTypeId!=null){
            if (checks(monitoringTargetTypeId, measureTypes)) {
                List<Map> ids = new ArrayList<>();
                Map map = new HashMap();
                for (Integer measureTypeId : measureTypes) {
                    map.put("monitoringTargetTypeId", monitoringTargetTypeId);
                    map.put("measureTypeId", measureTypeId);
                    ids.add(map);
                }
                monitoringTargetTypeMapper.addOneAndMoreMeasureTypeByMonitorTargetTypeId(ids);
                MonitoringTargetType monitoringTargetType1 = monitoringTargetTypeMapper.selectById(monitoringTargetTypeId);
                List<MeasureType> measureType = monitoringTargetTypeMapper.findMeasureTypesByMonitoringTargetTypeId(monitoringTargetType1.getId());
                monitoringTargetType1.setMeasureTypes(measureType);
                return monitoringTargetType1;
            }
        }
        return null;
    }

    @Override
    public int monitoringTargetTypeCount(){
        return monitoringTargetTypeMapper.findMonitorTargetTypeCount();
    }

    @Override
    public List<MonitoringTargetType> findUserMonitoringTargetTypeByCompanyId(Integer companyId,Integer limit,Integer offset) {
        List<MonitoringTargetType> monitoringTargetTypes=monitoringTargetTypeMapper.selectPage(new Page<>(offset,limit),new EntityWrapper<MonitoringTargetType>().eq("company_id",companyId).or().eq("company_id",-1));
        if(monitoringTargetTypes!=null&&monitoringTargetTypes.size()>0) {
            for (MonitoringTargetType monitoringTargetType : monitoringTargetTypes) {
                List<MeasureType> measureTypes = monitoringTargetTypeMapper.findMeasureTypesByMonitoringTargetTypeId(monitoringTargetType.getId());
                monitoringTargetType.setMeasureTypes(measureTypes);
            }
        }
        return monitoringTargetTypes;

    }

    @Override
    public MonitoringTargetType findLoginUserMonitoringTargetTypeById(Integer id,Integer companyId) {
        List<MonitoringTargetType> monitoringTargetTypes=monitoringTargetTypeMapper.selectList(new EntityWrapper<MonitoringTargetType>().eq("id",id).eq("company_id",companyId));
        if(monitoringTargetTypes!=null&& monitoringTargetTypes.size()>0) {
            for (MonitoringTargetType monitoringTargetType : monitoringTargetTypes) {
                List<MeasureType> measureTypes = monitoringTargetTypeMapper.findMeasureTypesByMonitoringTargetTypeId(monitoringTargetType.getId());
                monitoringTargetType.setMeasureTypes(measureTypes);
            }
        }
        return monitoringTargetTypes.get(0);
    }

    @Override
    public MonitoringTargetType findAdminMonitoringTargetTypeById(Integer id) {
        MonitoringTargetType monitoringTargetType=monitoringTargetTypeMapper.selectById(id);
        if(monitoringTargetType!=null){
            List<MeasureType> measureTypes=monitoringTargetTypeMapper.findMeasureTypesByMonitoringTargetTypeId(monitoringTargetType.getId());
            monitoringTargetType.setMeasureTypes(measureTypes);
        }

        return monitoringTargetType;
    }

    @Override
    @Transactional
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean deleteAdminMonitoringTargetTypeById(Integer id) {
        //TODO
        List<MonitoringTarget> monitoringTargets=monitoringTargetMapper.selectList(new EntityWrapper<MonitoringTarget>().eq("monitoring_target_type_id","id"));
        if(monitoringTargets==null) {
            if (!(monitoringTargetTypeMeasureRuleMapper.delete(new EntityWrapper<MonitoringTargetTypeMeasureRule>().eq("monitoring_target_type_id", id)) > 0 && monitoringTargetTypeMeasureTypeMapMapper.delete(new EntityWrapper<MonitoringTargetTypeMeasureTypeMap>().eq("monitoring_target_type_id", id)) > 0 && monitoringTargetTypeMapper.deleteById(id) > 0)) {
                return true;
            }
        }
        return false;
    }

    @Override
    @Transactional
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean updateAdminMonitoringTargetTypeById(Integer id,MonitoringTargetType monitoringTargetType) {
        //TODO
        if(monitoringTargetTypeMapper.update(monitoringTargetType,new EntityWrapper<MonitoringTargetType>().eq("id",id))==1) {
            List<MeasureType> measureTypes = monitoringTargetType.getMeasureTypes();
            for (MeasureType measureType : measureTypes) {
                measureTypeMapper.updateById(measureType);
            }
            return true;
        }else {
            return false;
        }
    }

    @Override
    @Transactional
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public MonitoringTargetType getMonitoringTargetTypeById(Integer id) {
        return monitoringTargetTypeMapper.selectById(id);
    }

    @Override
    @Transactional
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean updateMonitoringTargetType(MonitoringTargetType monitoringTargetType) {
        return monitoringTargetTypeMapper.updateById(monitoringTargetType)==1;
    }

    @Override
    public List<Integer> getMeasureTypeByMonitorTargetTypeId(Integer id) {
       List<MonitoringTargetTypeMeasureTypeMap> monitoringTargetTypeMeasureTypeMaps= monitoringTargetTypeMeasureTypeMapMapper.selectList(new EntityWrapper<MonitoringTargetTypeMeasureTypeMap>().eq("monitoring_target_type_id",id));
       List<Integer> measureTypeIds=new ArrayList<>();
       for(MonitoringTargetTypeMeasureTypeMap monitoringTargetTypeMeasureTypeMap:monitoringTargetTypeMeasureTypeMaps){
           Integer monitoringTargetTypeMeasureTypeMapId=monitoringTargetTypeMeasureTypeMap.getId();
           measureTypeIds.add(monitoringTargetTypeMeasureTypeMapId);
       }
       return measureTypeIds;
    }

    @Override
    @Transactional
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean addOneAndMoreMeasureTypeByMonitorTargetTypeId(Integer id, List<Integer> list) {
       if(checks(id,list)){
           List<Map> ids=new ArrayList<>();
           Map map=new HashMap();
           for (Integer measureTypeId:list){
               map.put("monitoringTargetTypeId",id);
               map.put("measureTypeId",measureTypeId);
               ids.add(map);
           }

           return monitoringTargetTypeMapper.addOneAndMoreMeasureTypeByMonitorTargetTypeId(ids)>0?true:false;

       }
       return false;
    }

    @Override
    @Transactional
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean deleteOneAndMoreMeasureTypeByMonitorTargetTypeId(Integer id, List<Integer> list) {

        return monitoringTargetTypeMapper.deleteOneAndMoreMeasureTypeByMonitorTargetTypeId(id,list)>0?true:false;
    }

    @Override
    public List<MonitoringTargetTypeMeasureRule> findmeasureRuleByMonitorTargetTypeId(Integer id) {
        List<MonitoringTargetTypeMeasureRule> monitoringTargetTypeMeasureRules=monitoringTargetTypeMapper.findmeasureRuleByMonitorTargetTypeId(id);
        List<MonitoringTargetTypeMeasureRule> list=new ArrayList<>();
        for(MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule:monitoringTargetTypeMeasureRules){
            MeasureType measureType=measureTypeMapper.selectById(monitoringTargetTypeMeasureRule.getMeasureTypeId());
            monitoringTargetTypeMeasureRule.setMeasureType(measureType);
            list.add(monitoringTargetTypeMeasureRule);
        }
        return list;
    }

    @Override
    @Transactional
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean addMeasureRuleByMonitorTargetType(MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule,Integer id,String measureTypeName) {
        MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule1=new MonitoringTargetTypeMeasureRule();
        monitoringTargetTypeMeasureRule1.setName(monitoringTargetTypeMeasureRule.getName());
        monitoringTargetTypeMeasureRule1.setDefinition(monitoringTargetTypeMeasureRule.getDefinition());
        monitoringTargetTypeMeasureRule1.setPurpose(monitoringTargetTypeMeasureRule.getPurpose());
        Integer measureTypeId=measureTypeMapper.addMeasureType(measureTypeName);
        monitoringTargetTypeMeasureRule1.setMeasureTypeId(measureTypeId);
        if(measureTypeId==null){
            throw new UserException();
        }
        monitoringTargetTypeMeasureRule1.setMonitoringTargetTypeId(id);
        return monitoringTargetTypeMeasureRuleMapper.insert(monitoringTargetTypeMeasureRule1)==1;
    }

    @Override
    @Transactional
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean deleteMonitoringTargetTypeMeasureRule(Integer monitorTargetTypeId,Integer ruleId) {
        MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule=new MonitoringTargetTypeMeasureRule();
        monitoringTargetTypeMeasureRule.setId(ruleId);
        monitoringTargetTypeMeasureRule.setMonitoringTargetTypeId(monitorTargetTypeId);
        return monitoringTargetTypeMapper.deleteMeasureRuleByMonitoringTargetTypeIdAndMeasureRule(monitoringTargetTypeMeasureRule)==1;

    }

    @Override
    @Transactional
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean updateMonitoringTargetTypeMeasureRule(Integer monitoringTargetTypeId, Integer ruleId, MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule,String measureTypeName) {
        MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule1=new MonitoringTargetTypeMeasureRule();
        monitoringTargetTypeMeasureRule1.setName(monitoringTargetTypeMeasureRule.getName());
        monitoringTargetTypeMeasureRule1.setDefinition(monitoringTargetTypeMeasureRule.getDefinition());
        monitoringTargetTypeMeasureRule1.setPurpose(monitoringTargetTypeMeasureRule.getPurpose());
        monitoringTargetTypeMeasureRule1.setMonitoringTargetTypeId(monitoringTargetTypeId);
        monitoringTargetTypeMeasureRule1.setId(ruleId);
        MeasureType measureType=new MeasureType();
        Integer measureTypeId=monitoringTargetTypeMeasureRuleMapper.selectById(ruleId).getMeasureTypeId();
        measureType.setId(measureTypeId);
        measureType.setName(measureTypeName);
        if(measureTypeId==null){
            throw new UserException();
        }
        return monitoringTargetTypeMeasureRuleMapper.updateById(monitoringTargetTypeMeasureRule1)==1&&measureTypeMapper.updateById(measureType)==1;
    }

    private boolean checks(Integer id, List<Integer> integers) {
        MonitoringTargetType monitoringTargetType=monitoringTargetTypeMapper.selectById(id);
        if(monitoringTargetType == null) {
            return false;
        }
        for(Integer measureTypeId : integers) {
           MeasureType measureType=measureTypeMapper.selectById(measureTypeId);
            if(measureType == null) {
                throw new UserException();
            }
        }
        return true;
    }
}
