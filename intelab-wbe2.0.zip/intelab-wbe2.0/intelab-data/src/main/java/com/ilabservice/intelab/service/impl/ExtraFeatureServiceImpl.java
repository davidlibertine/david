package com.ilabservice.intelab.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.CompanyExtraFeatureMapMapper;
import com.ilabservice.intelab.mapper.CompanyMapper;
import com.ilabservice.intelab.mapper.ExtraFeatureMapper;
import com.ilabservice.intelab.model.*;
import com.ilabservice.intelab.service.ExtraFeatureService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class ExtraFeatureServiceImpl implements ExtraFeatureService {

    @Resource
    private ExtraFeatureMapper extraFeatureMapper;

    @Resource
    private CompanyMapper companyMapper;

    @Resource
    private CompanyExtraFeatureMapMapper companyExtraFeatureMapMapper;

    /**
     * 查询指定公司的所有附加功能
     * @param id
     * @return
     */
    @Override
    public List<ExtraFeature> queryAllAdditionalFeaturesOfGivenCompany(Integer id) throws UserException {
        List<ExtraFeature> extraFeatureList = Lists.newArrayList();
        Company company = companyMapper.selectById(id);
        if(company != null) {
            List<CompanyExtraFeatureMap> companyExtraFeatureMapList = companyExtraFeatureMapMapper.selectCompanyExtraListByCompanyId(id);
            for(CompanyExtraFeatureMap companyExtraFeatureMap : companyExtraFeatureMapList) {
                ExtraFeature extraFeature = extraFeatureMapper.selectById(companyExtraFeatureMap.getExtraFeatureId());
                extraFeatureList.add(extraFeature);
            }
            return extraFeatureList;
        }
        return null;
    }

    /**
     * 为一个公司增添一到多个产品功能
     * @param companyId
     * @param featuresIdList
     * @return
     */
    @Override
    public boolean addOneOrMoreProductFeaturesTCompany(Integer companyId, List<Integer> featuresIdList) {
        if(checks(companyId, featuresIdList)) {
            List list = Lists.newArrayList();
            Map<String, Integer> map = Maps.newHashMap();
            for(Integer featuresId : featuresIdList) {
                map.put("companyId", companyId);
                map.put("featuresId", featuresId);
                list.add(map);
            }
            return companyExtraFeatureMapMapper.addOneOrMoreProductFeaturesTCompany(list) > 0 ? true : false;
        }
        return false;
    }

    /**
     * 从一个公司删除一到多个产品功能
     * @param id
     * @param featuresIdList
     * @return
     */
    @Override
    public boolean deleteOneOrMoreProductFeaturesTCompany(Integer id, List<Integer> featuresIdList) {
        /**
         * 校验通过执行删除逻辑 删除出现异常直接回滚
         */
        if(!checks(id, featuresIdList)) {
            return false;
        }
        return companyExtraFeatureMapMapper.deleteOneOrMorefeaturessFromTheCompanyId(id, featuresIdList) > 0 ? true :false;
    }

    /**
     * 校验
     * @param id
     * @param integers
     * @return
     */
    private boolean checks(Integer id, List<Integer> integers) {
        Company company = companyMapper.selectById(id);
        if(company == null) {
            return false;
        }
        for(Integer featuresId : integers) {
            ExtraFeature extraFeature = extraFeatureMapper.selectById(featuresId);
            if(extraFeature == null) {
                throw new UserException();
            }
        }
        return true;
    }
}
