package com.ilabservice.intelab.vo.assemblyvo;

import com.google.common.collect.Lists;
import com.ilabservice.intelab.model.Company;
import com.ilabservice.intelab.model.User;
import com.ilabservice.intelab.vo.UserVo;

import java.util.List;

public class UserVoMapper {

    /**
     * 封裝UserVo對象,返回單個對象
     * @param user
     * @return
     */
    public static UserVo getUserVoByUserModelAndCompanyModel(User user, Company company) {

        /**
         * 需要根據用戶id查詢其公司的信息，一起封裝返回前端
         */
        UserVo userVo = new UserVo();
        userVo.setId(user.getId());
        userVo.setUsername(user.getUserName());
        userVo.setName(user.getName());
        userVo.setEmail(user.getEmail());
        userVo.setMobile(user.getMobile());
        userVo.setTelephone(user.getTelephone());
        userVo.setGender(user.getGender());
        userVo.setHeadIcon(user.getHeadIcon());
        userVo.setDepartment(user.getDepartment());
        userVo.setJob(user.getJob());
        userVo.setJobNum(user.getName());
        userVo.setCompanyDomainName(company.getDomainName());
        userVo.setBindEmail(user.getBindEmail());
        userVo.setBindMobile(user.getBindMobile());
        userVo.setAlertNotificationType(user.getAlertNotificationType());
        userVo.setLatestPasswordUpdateTime(user.getId());

        return userVo;
    }

    /**
     * 封裝UserVo對象,返回集合對象
     * @param users
     * @param company
     * @return
     */
    public static List<UserVo> getUserVoByUserModelAndCompanyModel(List<User> users, Company company) {
        List<UserVo> userVoList = Lists.newArrayList();
        for(User user : users) {
            /**
             * 需要根據用戶id查詢其公司的信息，一起封裝返回前端
             */
            UserVo userVo = new UserVo();
            userVo.setId(user.getId());
            userVo.setUsername(user.getUserName());
            userVo.setName(user.getName());
            userVo.setEmail(user.getEmail());
            userVo.setMobile(user.getMobile());
            userVo.setTelephone(user.getTelephone());
            userVo.setGender(user.getGender());
            userVo.setHeadIcon(user.getHeadIcon());
            userVo.setDepartment(user.getDepartment());
            userVo.setJob(user.getJob());
            userVo.setJobNum(user.getName());
            userVo.setCompanyDomainName(company.getDomainName());
            userVo.setBindEmail(user.getBindEmail());
            userVo.setBindMobile(user.getBindMobile());
            userVo.setAlertNotificationType(user.getAlertNotificationType());
            userVo.setLatestPasswordUpdateTime(user.getId());

            userVoList.add(userVo);
        }

        return userVoList;
    }
}
