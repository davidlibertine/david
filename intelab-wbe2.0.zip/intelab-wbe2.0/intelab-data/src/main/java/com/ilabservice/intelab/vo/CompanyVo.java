package com.ilabservice.intelab.vo;

import java.math.BigDecimal;
import java.util.List;
import com.ilabservice.intelab.model.ExtraFeature;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanyVo{
	private Integer id;
	private String name;
	private String address;
	private String email;
	private String domainName;
	private String locationName;
	private String telephone;
	private String logo;
	private String backgroundUrl;
	private BigDecimal longitude;
	private BigDecimal latitude;
	private String campusImage;
	private String managerName;
	private String locationType;
	private String managerLoginUsername;
	private List<ExtraFeature> extraFeatures;
}
