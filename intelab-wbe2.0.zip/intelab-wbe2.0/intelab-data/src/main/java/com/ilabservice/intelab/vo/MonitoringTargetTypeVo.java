package com.ilabservice.intelab.vo;

import com.ilabservice.intelab.model.MeasureType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class MonitoringTargetTypeVo {
    private Integer id;
    private String name;
    private Integer companyId;
    private String description;
    private String logoUrl;
    List<MeasureType> measureTypes;
}
