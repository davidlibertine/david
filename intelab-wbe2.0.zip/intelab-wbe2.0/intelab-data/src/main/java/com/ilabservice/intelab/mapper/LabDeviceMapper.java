package com.ilabservice.intelab.mapper;

import com.ilabservice.intelab.model.LabDevice;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-14 09:23:08
 */
@Mapper
public interface LabDeviceMapper extends BaseMapper<LabDevice> {

    /**
     * 新建监控对象设备, 需要返回主键
     * @param labDevice
     * @return
     */
    Integer addLabDevice(LabDevice labDevice);
    List<LabDevice> findLabDeviceByExample(Map<String ,Object> map);
    Integer findCountByExample(LabDevice labDevice);
	
}
