package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableField;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.ilabservice.intelab.model.BaseEntity;
import com.ilabservice.intelab.common.annotation.EnableParam;
import com.ilabservice.intelab.common.annotation.FillAuto;

import java.util.Date;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-14 09:23:08
 */
@Data
@ApiModel(value = "device_files")
@TableName("device_files")
public class DeviceFiles extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private String url;
	
    @ApiModelProperty(value = "")
    private String type;
	
    @ApiModelProperty(value = "")
    private String description;
	
    @ApiModelProperty(value = "")
    private String name;
	
    @ApiModelProperty(value = "")
    private Integer deviceId;
	
    @ApiModelProperty(value = "")
    private Date createDate;

    @TableField(exist = false)
    private LabDevice labDevice;
	

}
