package com.ilabservice.intelab.exceptions;


import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.object.object.ErrorInfo;
import com.ilabservice.intelab.object.object.ResourceBasic;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;


/**
 * 全局 Exception 处理
 * 凡是在这里处理了的 Exception, API 的返回值中的 data 是一个 json object
 * {code:, message:, data:} 其中
 * code 是 intelab 的application error code, 对于应用逻辑上的错误进行跟细致的划分. 让前端更方便的理解错误.
 * data 为自定义的与该 Exception 相关的对象, 让前端抑郁操作. data 可以为 null.
 */


@ControllerAdvice
public class GlobalExceptionHandler {
    /**
     * 此处只是一个例子函数, 用来处理 ResourceBusyException
     * 实际上一个 handler 也可以处理多种 Exception. 也可以把@ResponseStatus 放在 handler 的前面, 这样多个 Exception 可以用同一个 HTTP 返回 code
     *
     * 不一定每个 Exception 都需要专门处理, 只需要在Exception定义的前面加入@ResponseStatus 定义 HTTP 返回 code 即可.
     * @param err
     * @return
     */
    //@ResponseStatus(HttpStatus.CONFLICT)
    @ExceptionHandler(ResourceBusyException.class)
    @ResponseBody
    public ErrorInfo<ResourceBasic> handleResourceBusyException(ResourceBusyException err){
        ErrorInfo<ResourceBasic> errorInfo = new ErrorInfo<>();

        errorInfo.setCode(201);
        errorInfo.setMessage(err.getMessage());
        errorInfo.setData(err.getResourceBasic());

        return errorInfo;
    }

    /**
     * 用戶模塊全局異常信息處理
     * @param err
     * @return
     */
    @ExceptionHandler(UserException.class)
    @ResponseBody
    public ErrorInfo<Object> handleUserException(UserException err){
        ErrorInfo<Object> errorInfo = new ErrorInfo<>();

        errorInfo.setCode(err.getCode());
        errorInfo.setMessage(err.getMessage());
        errorInfo.setData(err.getData());

        return errorInfo;
    }

    /**
     * 资源未找到异常处理
     * @param err
     * @return
     */
    @ExceptionHandler(ResourcesNotFoundException.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ErrorInfo<Object> handleResourcesNotFoundException(ResourcesNotFoundException err){
        ErrorInfo<Object> errorInfo = new ErrorInfo<>();
        errorInfo.setCode(ResultErrorCode.DATA_NOT_FOUND.getCode());
        errorInfo.setMessage(err.getMessage());
        errorInfo.setData(err.getParameters());

        return errorInfo;
    }


    /**
     * 权限未找到异常处理
     * @param err
     * @return
     */
    @ExceptionHandler(PermissionsException.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.UNAUTHORIZED)
    public ErrorInfo<Object> handlePermissionsException(PermissionsException err){
        ErrorInfo<Object> errorInfo = new ErrorInfo<>();
        errorInfo.setCode(ResultErrorCode.PERMISSION_NO_ACCESS.getCode());
        errorInfo.setMessage(err.getMessage());
        errorInfo.setData(err.getParameters());
        return errorInfo;
    }
}
