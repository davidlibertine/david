package com.ilabservice.intelab.model;

import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.ilabservice.intelab.model.BaseEntity;
import com.ilabservice.intelab.common.annotation.EnableParam;
import com.ilabservice.intelab.common.annotation.FillAuto;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-09 21:06:04
 */
@Data
@ApiModel(value = "company_contract")
@TableName("company_contract")
public class CompanyContract extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    @TableField(value="company_id")
    private Integer companyId;
	
    @ApiModelProperty(value = "")
    @TableField(value="start_date")
    private Date startDate;
	
    @ApiModelProperty(value = "")
    @TableField(value="end_date")
    private Date endDate;
	
    @ApiModelProperty(value = "")
    private String description;
	
    @ApiModelProperty(value = "")
    @TableField(value="sign_date")
    private Date signDate;
	

}
