package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Data
@ApiModel(value = "monitoring_target_type_measure_rule")
@TableName("monitoring_target_type_measure_rule")
public class MonitoringTargetTypeMeasureRule extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private String name;
	
    /**
     * JSON string for the rules
     */
    @ApiModelProperty(value = "JSON string for the rules")
    private String definition;
	
    @ApiModelProperty(value = "")
    @TableField(value = "monitoring_target_type_id")
    private Integer monitoringTargetTypeId;
	
    @ApiModelProperty(value = "")
    @TableField(value = "measure_type_id")
    private Integer measureTypeId;
	
    @ApiModelProperty(value = "")
    private Integer purpose;

    @TableField(exist = false)
	private MeasureType measureType;

    @TableField(exist = false)
    private MonitoringTargetType monitoringTargetType;

}
