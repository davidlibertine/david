package com.ilabservice.intelab.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.io.Serializable;
import java.util.List;

@ResponseStatus(value = HttpStatus.UNAUTHORIZED)
public class PermissionsException extends RuntimeException {
    private List<Serializable> parameters;

    public List<Serializable> getParameters(){return parameters;}

    public PermissionsException(String message, List<Serializable> parameters){
        super(message);
        this.parameters = parameters;
    }

}
