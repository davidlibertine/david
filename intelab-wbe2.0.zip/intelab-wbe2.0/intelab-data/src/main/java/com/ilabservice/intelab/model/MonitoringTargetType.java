package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Data
@ApiModel(value = "monitoring_target_type")
@TableName("monitoring_target_type")
public class MonitoringTargetType extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private String name;
	
    @ApiModelProperty(value = "")
    private String description;
	
    @ApiModelProperty(value = "")
    @TableField(value = "logo_url")
    private String logoUrl;
	
    @ApiModelProperty(value = "")
    @TableField(value = "company_id")
    private Integer companyId;
	
    @ApiModelProperty(value = "")
    @TableField(value = "create_datetime")
    private Date createDatetime;
	
   @TableField(exist = false)
    private List<MeasureType> measureTypes;

}
