package com.ilabservice.intelab.model;

import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.ilabservice.intelab.model.BaseEntity;
import com.ilabservice.intelab.common.annotation.EnableParam;
import com.ilabservice.intelab.common.annotation.FillAuto;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-09 15:18:14
 */
@Data
@ApiModel(value = "company_extra_feature_map")
@TableName("company_extra_feature_map")
public class CompanyExtraFeatureMap extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    @TableField(value="company_id")
    private Integer companyId;
	
    @ApiModelProperty(value = "")
    @TableField(value="extra_feature_id")
    private Integer extraFeatureId;
	

}
