package com.ilabservice.intelab.vo.assemblyvo;

import com.ilabservice.intelab.model.Location;
import com.ilabservice.intelab.vo.LocationBasicVo;
import com.ilabservice.intelab.vo.LocationVo;

import java.util.stream.Collectors;

public class LocationVoMapper {

    public static LocationVo getLocationVo(Location location){
        LocationVo slv = new LocationVo();
        slv.setId(location.getId());
        slv.setName(location.getName());
        slv.setParentId(location.getParentId());
        slv.setIsLeaf(location.getIsLeaf() == 1);
        slv.setLocationType(location.getLocationType());
        slv.setDescription(location.getDescription());
        slv.setAddress(location.getAddress());
        slv.setXCoordinate(location.getXLocation() == null ? null : location.getXLocation().toString());
        slv.setYCoordinate(location.getYLocation() == null ? null : location.getYLocation().toString());
        // TODO zyclincoln: these data needs nested sql query
        slv.setMonitorTargetNum(location.getMonitorTargetNum());
        // TODO: these data needs to retrieve from influxdb
        slv.setYellowAlertCountToday(null);
        slv.setRedAlertCountToday(null);
        slv.setOnlineCount(null);
        slv.setOfflineCount(null);
        slv.setBackground(location.getBackground());
        slv.setChildLocations(location.getChildLocations() == null ? null :
                location.getChildLocations().stream().map(p -> getLocationBasicVo(p)).collect(Collectors.toList()));
        return slv;
    }

    public static LocationBasicVo getLocationBasicVo(Location location){
        LocationBasicVo lbv = new LocationBasicVo();
        lbv.setId(location.getId());
        lbv.setLocationType(location.getLocationType());
        lbv.setName(location.getName());
        lbv.setXCoordinate(location.getXLocation() == null ? null : location.getXLocation().toString());
        lbv.setYCoordinate(location.getYLocation() == null ? null : location.getYLocation().toString());

        return lbv;
    }
}
