package com.ilabservice.intelab.vo.assemblyvo;

import com.ilabservice.intelab.model.MonitoringTarget;
import com.ilabservice.intelab.vo.MonitorTargetBasicVo;

public class MonitorTargetVoMapper {

    public static MonitorTargetBasicVo getMonitorTargetBasicVo(MonitoringTarget mt){
        MonitorTargetBasicVo mtbv = new MonitorTargetBasicVo();

        mtbv.setId(mt.getId());
        mtbv.setMonitorTargetType(mt.getMonitoringTargetType().getName());
        mtbv.setName(mt.getName());
        // todo: there is not photo url, x and y coordinates in database
        mtbv.setPhotoUrl(null);
        mtbv.setXCoordinate(null);
        mtbv.setYCoordinate(null);
        return mtbv;
    }
}
