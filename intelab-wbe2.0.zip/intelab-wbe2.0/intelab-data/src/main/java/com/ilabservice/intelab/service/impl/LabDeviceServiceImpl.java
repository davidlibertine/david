package com.ilabservice.intelab.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.google.common.collect.Maps;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.*;
import com.ilabservice.intelab.model.*;
import com.ilabservice.intelab.service.LabDeviceService;
import com.ilabservice.intelab.service.base.impl.BaseServiceImpl;
import com.sun.org.apache.bcel.internal.generic.NEW;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;


@Service
public class LabDeviceServiceImpl extends BaseServiceImpl<LabDeviceMapper,LabDevice> implements LabDeviceService {

    @Resource
    private LabDeviceMapper labDeviceMapper;

    @Resource
    private UserMapper userMapper;

    @Resource
    private MonitoringTargetTypeMapper monitoringTargetTypeMapper;

    @Resource
    private MonitoringTargetMapper monitoringTargetMapper;

    @Resource
    private MonitoringTargetMeasureRuleMapper monitoringTargetMeasureRuleMapper;

    @Resource
    private DeviceFilesMapper deviceFilesMapper;

    @Resource
    private LocationMapper locationMapper;
    @Autowired
    private MeasureTypeMapper measureTypeMapper;

    /**
     * 新建监控对象设备
     * @param monitorTargetLabDevice
     * @param userId
     * @return
     */
    @Override
    @Transactional(rollbackFor = {Exception.class, RuntimeException.class})
    @Retryable(value= {Exception.class, RuntimeException.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public Map<String, Object> addLabDevice(MonitorTargetLabDevice monitorTargetLabDevice, Integer userId) throws UserException {

        /**
         * 1.解析 monitorTargetLabDevice
         * 2.插入数据返回主键
         * 3.获取companyId
         * 4.插入monitorTarget
         */
        LabDevice labDevice = new LabDevice();
        labDevice.setName(monitorTargetLabDevice.getName());
        labDevice.setModel(monitorTargetLabDevice.getModel());
        labDevice.setBrand(monitorTargetLabDevice.getBrand());
        labDevice.setAssetId(monitorTargetLabDevice.getAssetId());
        labDevice.setProductLine(monitorTargetLabDevice.getProductLine());
        labDevice.setEnableSharing(monitorTargetLabDevice.getEnableSharing());
        labDevice.setLeaseClause(monitorTargetLabDevice.getAssetId());
        labDevice.setLeasePricePerHour(monitorTargetLabDevice.getLeasePricePerHour());
        labDevice.setManufacturer(monitorTargetLabDevice.getAssetId());
        labDevice.setPurchaseDate(monitorTargetLabDevice.getPerchaseDate());
        /**
         * 获取 labDeviceId 和公司 id
         */
        Integer labDeviceId = labDeviceMapper.addLabDevice(labDevice);
        User user = userMapper.selectById(userId);
        Integer companyId = user.getCompanyId();

        /**
         * 插入MonitoringTargetType并返回主键值
         */
        MonitoringTargetType monitoringTargetType = new MonitoringTargetType();
        monitoringTargetType.setCompanyId(companyId);
        monitoringTargetType.setCreateDatetime(new Date());
        monitoringTargetType.setLogoUrl(monitorTargetLabDevice.getProfileImage());
        monitoringTargetType.setName(monitorTargetLabDevice.getName());

        Integer monitoringTargetTypeId = monitoringTargetTypeMapper.addMonitoringTargetType(monitoringTargetType);

        /**
         * 插入 MonitoringTarget
         */
        MonitoringTarget monitoringTarget = new MonitoringTarget();
        monitoringTarget.setLocationId(monitorTargetLabDevice.getLocationId());
        monitoringTarget.setMonitoringTargetTypeId(monitoringTargetTypeId);
        monitoringTarget.setCompanyId(companyId);
        monitoringTarget.setRefTable(monitorTargetLabDevice.getName());
        monitoringTarget.setRefTableId(labDeviceId);
        monitoringTarget.setCreatorId(userId);

        Integer monTargetProKey = monitoringTargetMapper.addMonitoringTarget(monitoringTarget);

        /**
         * 1.查询所需要的对象信息
         * 2.返回到controller组装vo对象，把vo对象返回给前端
         */
        LabDevice labDevice1 = labDeviceMapper.selectById(labDeviceId);
        MonitoringTargetMeasureRule measureRules = monitoringTargetMeasureRuleMapper.selectById(monitoringTargetTypeId);
        DeviceFiles deviceFiles = deviceFilesMapper.selectById(labDeviceId);
        Location location = locationMapper.selectById(monTargetProKey);
        MonitoringTarget monitoringTarget1 = monitoringTargetMapper.selectById(monTargetProKey);
        Map<String, Object> map = Maps.newHashMap();
        map.put("labDevice", labDevice1);
        map.put("measureRules", measureRules);
        map.put("deviceFiles", deviceFiles);
        map.put("location", location);
        map.put("monitoringTarget", monitoringTarget1);

        return map;
    }

    @Override
    public List<LabDevice> getUserLabDevice(Integer monitorTargetTypeId,Integer companyId, Integer locationId, LabDevice labDevice, Integer limit, Integer offset) {
//       Location location=locationMapper.selectById(locationId);
//       MonitoringTargetType monitoringTargetType=monitoringTargetTypeMapper.selectById(monitorTargetTypeId);
//       List<MonitoringTarget> monitoringTargets=monitoringTargetMapper.selectList(new EntityWrapper<MonitoringTarget>()
//       .eq("company_id",companyId).eq("monitoring_target_type_id",monitorTargetTypeId));
//        List<Integer> labDeviceIds=new ArrayList<>();
//        for(MonitoringTarget monitoringTarget:monitoringTargets){
//            labDeviceIds.add(monitoringTarget.getRefTableId());
//        }
//       if(labDevice==null){
//           Map<String,Object> map=new HashMap<>();
//           map.put("limit",limit);
//           map.put("offset",offset);
//           map.put("labDeviceIds",labDeviceIds);
//           List<LabDevice> labDevices=labDeviceMapper.findLabDeviceByExample(map);
//           for (LabDevice labDevice1:labDevices){
//               List<MonitoringTarget> monitoringTargets1=monitoringTargetMapper.selectList(new EntityWrapper<MonitoringTarget>()
//                       .eq("ref_table_id",labDevice1.getId()));
//               for(MonitoringTarget monitoringTarget:monitoringTargets1){
//                   List<MonitoringTargetMeasureRule> monitoringTargetMeasureRules=monitoringTargetMeasureRuleMapper.selectList(new EntityWrapper<MonitoringTargetMeasureRule>()
//                           .eq("monitoring_target_id",monitoringTarget.getId()));
//                   monitoringTarget.setMonitoringTargetMeasureRules(monitoringTargetMeasureRules);
//               }
//               labDevice1.setMonitoringTargets(monitoringTargets1);
//               labDevice1.setLocation(location);
//               labDevice1.setMonitoringTargetType(monitoringTargetType);
//               List<DeviceFiles> deviceFiles=deviceFilesMapper.selectList(new EntityWrapper<DeviceFiles>().eq("device_id",labDevice1.getId()));
//               labDevice1.setDeviceFiles(deviceFiles);
//           }
//           return labDevices;
//       }else {
//          Map<String,Object> map=new HashMap<>();
//           map.put("labDevice",labDevice);
//           map.put("limit",limit);
//           map.put("offset",offset);
//           map.put("labDeviceIds",labDeviceIds);
//           List<LabDevice> labDevices=labDeviceMapper.findLabDeviceByExample(map);
//           for (LabDevice labDevice1:labDevices){
//               List<MonitoringTarget> monitoringTargets1=monitoringTargetMapper.selectList(new EntityWrapper<MonitoringTarget>()
//               .eq("ref_table_id",labDevice1.getId()));
//               for(MonitoringTarget monitoringTarget:monitoringTargets1){
//                   List<MonitoringTargetMeasureRule> monitoringTargetMeasureRules=monitoringTargetMeasureRuleMapper.selectList(new EntityWrapper<MonitoringTargetMeasureRule>()
//                   .eq("monitoring_target_id",monitoringTarget.getId()));
//                   monitoringTarget.setMonitoringTargetMeasureRules(monitoringTargetMeasureRules);
//               }
//               labDevice1.setMonitoringTargets(monitoringTargets1);
//               labDevice1.setLocation(location);
//               labDevice1.setMonitoringTargetType(monitoringTargetType);
//               List<DeviceFiles> deviceFiles=deviceFilesMapper.selectList(new EntityWrapper<DeviceFiles>().eq("device_id",labDevice1.getId()));
//               labDevice1.setDeviceFiles(deviceFiles);
//           }
//           return labDevices;
//       }
        return null;
    }

    @Override
    public LabDevice findLabDeviceMonitorTargetById(Integer id) {
        LabDevice labDevice=labDeviceMapper.selectById(id);

            List<MonitoringTarget> monitoringTargets1=monitoringTargetMapper.selectList(new EntityWrapper<MonitoringTarget>()
                    .eq("ref_table_id",id));
            for(MonitoringTarget monitoringTarget:monitoringTargets1){
                List<MonitoringTargetMeasureRule> monitoringTargetMeasureRules=monitoringTargetMeasureRuleMapper.selectList(new EntityWrapper<MonitoringTargetMeasureRule>()
                        .eq("monitoring_target_id",monitoringTarget.getId()));
                monitoringTarget.setMonitoringTargetMeasureRules(monitoringTargetMeasureRules);
                Location location=locationMapper.selectById(monitoringTarget.getLocationId());
                monitoringTarget.setLocation(location);
            }
            labDevice.setMonitoringTargets(monitoringTargets1);
            List<DeviceFiles> deviceFiles=deviceFilesMapper.selectList(new EntityWrapper<DeviceFiles>().eq("device_id",id));
            labDevice.setDeviceFiles(deviceFiles);

        return labDevice;
    }

    @Override
    @Transactional(rollbackFor = {Exception.class, RuntimeException.class})
    @Retryable(value= {Exception.class, RuntimeException.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean updateLabDevice(MonitorTargetLabDevice monitorTargetLabDevice,Integer id) {
        LabDevice labDevice = new LabDevice();
        labDevice.setName(monitorTargetLabDevice.getName());
        labDevice.setModel(monitorTargetLabDevice.getModel());
        labDevice.setBrand(monitorTargetLabDevice.getBrand());
        labDevice.setProductLine(monitorTargetLabDevice.getProductLine());
        labDevice.setEnableSharing(monitorTargetLabDevice.getEnableSharing());
        labDevice.setLeaseClause(monitorTargetLabDevice.getLeaseCause().toString());
        labDevice.setLeasePricePerHour(monitorTargetLabDevice.getLeasePricePerHour());
        labDevice.setManufacturer(monitorTargetLabDevice.getManufacture());
        labDevice.setPurchaseDate(monitorTargetLabDevice.getPerchaseDate());
        return labDeviceMapper.update(labDevice,new EntityWrapper<LabDevice>().eq("id",id))==1;
    }

    @Override
    @Transactional(rollbackFor = {Exception.class, RuntimeException.class})
    @Retryable(value= {Exception.class, RuntimeException.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean deleteMonitoringTargetAndLabDeviceById(Integer id) {
        if(monitoringTargetMapper.delete(new EntityWrapper<MonitoringTarget>().eq("ref_table_id",id))>0&&deviceFilesMapper.delete(new EntityWrapper<DeviceFiles>()
        .eq("device_id",id))>0&&labDeviceMapper.deleteById(id)>0){
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteDeviceFile(Integer id, Integer fileId) {

        return deviceFilesMapper.delete(new EntityWrapper<DeviceFiles>().eq("id",fileId).eq("device_id",id))==1;
    }

    @Override
    public List<DeviceFiles> findDeviceFiles(Integer id) {
        List<DeviceFiles> deviceFiles=deviceFilesMapper.selectList(new EntityWrapper<DeviceFiles>().eq("device_id",id));
        return deviceFiles;
    }

    @Override
    @Transactional(rollbackFor = {Exception.class, RuntimeException.class})
    @Retryable(value= {Exception.class, RuntimeException.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean addDeviceFilesImage(String url,Integer id) {
        DeviceFiles deviceFiles=new DeviceFiles();
        deviceFiles.setDeviceId(id);
        deviceFiles.setUrl(url);

        return deviceFilesMapper.insert(deviceFiles)==1;
    }

    @Override
    public LabDevice getLabDeviceById(Integer id) {
        LabDevice labDevice=labDeviceMapper.selectById(id);
        return labDevice;
    }

    @Override
    @Transactional(rollbackFor = {Exception.class, RuntimeException.class})
    @Retryable(value= {Exception.class, RuntimeException.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean updateLabDeviceImage(LabDevice labDevice) {
        return labDeviceMapper.updateById(labDevice)==1;
    }

    @Override
    @Transactional(rollbackFor = {Exception.class, RuntimeException.class})
    @Retryable(value= {Exception.class, RuntimeException.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean deleteMonitoringTargetRule(Integer monitorTargetId, Integer ruleId) {
        return monitoringTargetMeasureRuleMapper.delete(new EntityWrapper<MonitoringTargetMeasureRule>().eq("id",ruleId)
        .eq("monitoring_target_id",monitorTargetId))==1;
    }

    @Override
    @Transactional(rollbackFor = {Exception.class, RuntimeException.class})
    @Retryable(value= {Exception.class, RuntimeException.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean updateMonitorTargetMeasureTypeRule(Integer monitorTargetId, Integer ruleId, MonitoringTargetMeasureRule monitoringTargetMeasureRule, String measureTypeName) {

        MonitoringTargetMeasureRule monitoringTargetMeasureRule11=monitoringTargetMeasureRuleMapper.selectById(ruleId);
        Integer measureTypeId=monitoringTargetMeasureRule11.getMeasureTypeId();
        if(measureTypeId==null){
            throw  new UserException();
        }
        MeasureType measureType=new MeasureType();
        measureType.setId(measureTypeId);
        measureType.setName(measureTypeName);


        return monitoringTargetMeasureRuleMapper.update(monitoringTargetMeasureRule,new EntityWrapper<MonitoringTargetMeasureRule>()
                .eq("id",ruleId).eq("monitoring_target_id",monitorTargetId))==1&&measureTypeMapper.updateById(measureType)==1;
    }
}
