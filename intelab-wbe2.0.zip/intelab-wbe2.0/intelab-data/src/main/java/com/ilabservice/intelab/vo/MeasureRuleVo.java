package com.ilabservice.intelab.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MeasureRuleVo {
    private Integer id;
    private String name;
    private String measureTypeName;
    private String definition;
    private Integer purpose;

}
