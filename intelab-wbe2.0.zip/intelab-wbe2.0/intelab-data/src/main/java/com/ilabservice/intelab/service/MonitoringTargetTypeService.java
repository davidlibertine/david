package com.ilabservice.intelab.service;

import com.ilabservice.intelab.model.MonitoringTargetType;
import com.ilabservice.intelab.model.MonitoringTargetTypeMeasureRule;
import com.ilabservice.intelab.service.base.BaseService;
import com.ilabservice.intelab.vo.MeasureRuleVo;

import java.util.List;

public interface MonitoringTargetTypeService extends BaseService<MonitoringTargetType> {
        List<MonitoringTargetType> findListAllMonitoringTargetType(Integer limit, Integer offset);
        MonitoringTargetType addMonitoringTargetType(List<Integer> measureTypes,MonitoringTargetType monitoringTargetType,String logoUrl);
        int monitoringTargetTypeCount();
        List<MonitoringTargetType>  findUserMonitoringTargetTypeByCompanyId(Integer companyId, Integer limit, Integer offset);
        MonitoringTargetType findLoginUserMonitoringTargetTypeById(Integer id, Integer companyId);
        MonitoringTargetType findAdminMonitoringTargetTypeById(Integer id);
        boolean deleteAdminMonitoringTargetTypeById(Integer id);
        boolean updateAdminMonitoringTargetTypeById(Integer id, MonitoringTargetType monitoringTargetType);
        MonitoringTargetType getMonitoringTargetTypeById(Integer id);
        boolean updateMonitoringTargetType(MonitoringTargetType monitoringTargetType);
        List<Integer> getMeasureTypeByMonitorTargetTypeId(Integer id);
        boolean addOneAndMoreMeasureTypeByMonitorTargetTypeId(Integer id, List<Integer> list);
        boolean deleteOneAndMoreMeasureTypeByMonitorTargetTypeId(Integer id,List<Integer> list);
        List<MonitoringTargetTypeMeasureRule> findmeasureRuleByMonitorTargetTypeId(Integer id);
        boolean addMeasureRuleByMonitorTargetType(MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule,Integer id,String measureTypeName);
        boolean deleteMonitoringTargetTypeMeasureRule( Integer monitorTargetTypeId,Integer ruleId);
        boolean updateMonitoringTargetTypeMeasureRule(Integer monitoringTargetTypeId,Integer ruleId,MonitoringTargetTypeMeasureRule monitoringTargetTypeMeasureRule,String measureTypeName);

}
