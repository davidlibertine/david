package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Data
@ApiModel(value = "event")
@TableName("event")
public class Event extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private Integer iotTerminalId;
	
    @ApiModelProperty(value = "")
    private Integer monitoringTargetMeasureRuleId;
	
    @ApiModelProperty(value = "")
    private Integer counts;
	
    @ApiModelProperty(value = "")
    private Date startDatetime;
	
    @ApiModelProperty(value = "")
    private Date endDatetime;
	
    @ApiModelProperty(value = "")
    private String diagnoseReason;
	
    @ApiModelProperty(value = "")
    private String correctiveAction;
	
    @ApiModelProperty(value = "")
    private String processStatus;
	
    @ApiModelProperty(value = "")
    private Date lastProcessDatetime;

    @TableField(exist = false)
    private IotTerminal iotTerminal;

    @TableField(exist = false)
    private MonitoringTargetMeasureRule monitoringTargetMeasureRule;
}
