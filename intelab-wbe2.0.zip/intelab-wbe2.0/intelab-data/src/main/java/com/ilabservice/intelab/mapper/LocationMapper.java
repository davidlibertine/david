package com.ilabservice.intelab.mapper;

import com.ilabservice.intelab.model.Location;
import com.ilabservice.intelab.model.MonitoringTarget;
import com.baomidou.mybatisplus.mapper.BaseMapper;

import java.io.Serializable;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-09 21:06:04
 */
@Mapper
public interface LocationMapper extends BaseMapper<Location> {
	Location findLocationByUserId(Serializable userId);
	Location findLocationByROleId(Serializable roleId);
	Location findLocationById(Serializable locationId);
	List<MonitoringTarget> findMonitoringTargetByLocationId(Serializable locationId);
	Location getRootLocationsByCompanyId(Serializable companyId);
	List<MonitoringTarget> getMonitoringTargetByLocationIdAndUserId(@Param("locationId") Serializable locationId,
                                                                    @Param("userId") Serializable userId);
	Integer updateLocation(Location location);
}
