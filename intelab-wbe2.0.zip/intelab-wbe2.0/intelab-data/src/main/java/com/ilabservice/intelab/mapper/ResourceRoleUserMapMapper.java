package com.ilabservice.intelab.mapper;

import com.ilabservice.intelab.model.MonitoringTarget;
import com.ilabservice.intelab.model.ResourceRoleUserMap;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:09
 */
@Mapper
public interface ResourceRoleUserMapMapper extends BaseMapper<ResourceRoleUserMap> {

    ResourceRoleUserMap selectByUserId(@Param("userId") Integer userId);
	
}
