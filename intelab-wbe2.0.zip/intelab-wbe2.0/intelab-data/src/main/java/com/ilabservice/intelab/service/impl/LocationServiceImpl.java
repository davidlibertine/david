package com.ilabservice.intelab.service.impl;

import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.exceptions.ResourcesNotFoundException;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.LocationMapper;
import com.ilabservice.intelab.model.Location;
import com.ilabservice.intelab.model.MonitoringTarget;
import com.ilabservice.intelab.service.LocationService;
import com.ilabservice.intelab.service.base.impl.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.util.*;

@Service
public class LocationServiceImpl extends BaseServiceImpl<LocationMapper,Location> implements LocationService {

    @Autowired
    LocationMapper locationMapper;

    @Override
    public Location getRootLocationsByCompanyId(Serializable companyId){
        Location location = locationMapper.getRootLocationsByCompanyId(companyId);
        if(location == null)
            throw new ResourcesNotFoundException("not found location with company id",
                                                 Collections.singletonList(companyId));
        return location;
    }

    @Override
    public Location getLocationById(Serializable locationId){
        Location location = locationMapper.findLocationById(locationId);
        if(location == null)
            throw new ResourcesNotFoundException("not found location with location id",
                                                 Collections.singletonList(locationId));
        return location;
    }

    private List<MonitoringTarget> getMonitoringTargetByLocationId(Serializable locationId, Serializable userId){
        return locationMapper.getMonitoringTargetByLocationIdAndUserId(locationId, userId);
    }

    @Override
    public void fillLocationWithMonitoringTarget(Location location, Serializable userId){
        location.setMonitoringTargets(getMonitoringTargetByLocationId(location.getId(), userId));
    }



    @Override
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public void updateLocation(Location location){
        locationMapper.updateLocation(location);
    }


    @Override
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public void insertChildLocation(Location location){
        Location parentLocation = locationMapper.selectById(location.getParentId());
        if(parentLocation == null){
            throw new UserException(ResultErrorCode.PARAMS_IS_INVALID.getCode(), "parent location doesn't exist", null);
        }
        if(parentLocation.getIsLeaf() == 1){
            parentLocation.setIsLeaf(0);
            locationMapper.updateLocation(parentLocation);
        }
        location.setIsLeaf(1);
        location.setIsRoot(0);
        location.setCompanyId(parentLocation.getCompanyId());
        location.setCreateDatetime(new Date());
        locationMapper.insert(location);
    }

    @Override
    @Retryable(value= {Exception.class}, backoff = @Backoff(delay=100, maxDelay = 500))
    public void deleteLocationAndChild(Serializable locationId){
        Location location = locationMapper.findLocationById(locationId);
        if(location == null){
            throw new ResourcesNotFoundException("not found location with location id",
                    Collections.singletonList(locationId));
        }
        Serializable parentId = location.getIsRoot() == 1 ? null : location.getParentId();
        locationMapper.deleteById(locationId);
        if(parentId != null){
            Location parentLocation = locationMapper.findLocationById(parentId);
            if(parentLocation.getChildLocations() == null || parentLocation.getChildLocations().isEmpty()){
                parentLocation.setIsLeaf(1);
                locationMapper.updateLocation(parentLocation);
            }
        }
    }

}
