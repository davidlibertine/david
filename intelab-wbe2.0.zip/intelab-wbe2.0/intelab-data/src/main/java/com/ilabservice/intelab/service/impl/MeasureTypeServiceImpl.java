package com.ilabservice.intelab.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.ilabservice.intelab.mapper.MeasureTypeMapper;
import com.ilabservice.intelab.model.MeasureType;
import com.ilabservice.intelab.service.MeasureTypeService;
import com.ilabservice.intelab.service.base.impl.BaseServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class MeasureTypeServiceImpl extends BaseServiceImpl<MeasureTypeMapper,MeasureType> implements MeasureTypeService {


    @Resource
    private MeasureTypeMapper measureTypeMapper;

    /**
     * 根据 id 查询监控参数
     * @param id
     * @return
     */
    @Override
    public MeasureType getMeasureTypeById(Integer id) {
        MeasureType measureType = measureTypeMapper.selectById(id);
        return measureType != null ? measureType : null;
    }

    /**
     * 获取所有的监控参数
     * @return
     */
    @Override
    public List<MeasureType> getAllMeasureType() {
        List<MeasureType> measureTypes = measureTypeMapper.selectList(new EntityWrapper<MeasureType>());
        return measureTypes != null ? measureTypes : null;
    }

    /**
     * 根据 id 删除监控参数
     * @param id
     * @return
     */
    @Override
    public boolean deleteMeasureTypeById(Integer id) {
        Integer result = measureTypeMapper.deleteById(id);
        return result > 0 ? true : false;
    }

    /**
     * 根据 id 更新监控参数
     * @param id
     * @param newMeasureType
     * @return
     */
    @Override
    public boolean updateMeasureTypeById(Integer id, MeasureType newMeasureType) {
        MeasureType measureType = new MeasureType();
        measureType.setId(id);
        measureType.setCode(newMeasureType.getCode());
        measureType.setName(newMeasureType.getName());
        measureType.setUnit(newMeasureType.getUnit());

        Integer result = measureTypeMapper.updateById(measureType);
        return result > 0 ? true : false;
    }

    /**
     * 新增监控参数
     * @param newMeasureType
     * @return
     */
    @Override
    public boolean addMeasureTyp(MeasureType newMeasureType) {
        Integer result = measureTypeMapper.insert(newMeasureType);
        return result > 0 ? true : false;
    }

}
