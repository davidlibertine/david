package com.ilabservice.intelab.mapper;

import com.ilabservice.intelab.model.CompanyContract;
import com.baomidou.mybatisplus.mapper.BaseMapper;

import java.io.Serializable;

import org.apache.ibatis.annotations.Mapper;
/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-09 21:06:04
 */
@Mapper
public interface CompanyContractMapper extends BaseMapper<CompanyContract> {
	  public  int addCompanyContract(CompanyContract companyContract);
	
}
