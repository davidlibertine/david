package com.ilabservice.intelab.service;


import com.github.pagehelper.PageInfo;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.User;
import com.ilabservice.intelab.service.base.BaseService;
import com.ilabservice.intelab.vo.LoginUserRolesVo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 
 *
 * @author RedWall
 * @email walkmanlucas@gmail.com
 * @date 2018-04-18 14:41:05
 */
public interface UserService extends BaseService<User> {

    /**
     * 根据用户ID获取用户信息和其角色及权限
     *
     * */
    User getUserIdAndPasswordByUserName(Serializable userName);

    User getUserDetailInfo(Serializable id);

    boolean addRoleToUser(Role role, User user);

    boolean deleteRoleFromUser(Role role, User user);

    /**
     * 獲取登陸用戶信息
     * @return
     */
    User getLoginUserInfoByUserId(Integer userId);

    /**
     * 更新當前用戶信息並返回更新后的信息
     */
    User updateOldUserInfoReturnNewUserInfo(User oldUser, Integer userId);

    /**
     * 更新當前登陸用戶的頭像
     * @param userId
     * @param imgUrl
     * @return
     */
    String updateLoginUserHeadIcon(Integer userId, String imgUrl);

    /**
     * 修改密碼
     */
    boolean updateLoginUserPassword(Integer userId, String newPwd);

    /**
     * 獲取該用戶所在公司的全部用戶，該用戶必須是管理員
     * @param limit
     * @param offset
     * @return
     */
    PageInfo getLoginUserCompanyUser(Integer limit, Integer offset, Integer userId);

    /**
     * 為該公司添加一個用戶
     * @param user
     * @param userId
     * @return
     */
    Map<String, Object> addUserForCompany(User user, Integer userId);

    /**
     * 根据id查询用户
     * @param userId
     * @return
     */
    Map<String, Object> getUserInfoByUserId(Integer userId);

    /**
     * 根据id删除用户
     * @param userId
     * @return
     */
    boolean delectUserById(Integer userId);

    /**
     * 根据id更新指定用户
     * @param id
     * @return
     */
    Map<String, Object> updateUserInfoById(Integer id, User user, Integer loginUserId);

    /**
     * 给指定用户添加角色
     * @param roleId
     * @param userId
     * @return
     */
    Boolean addRoleToSpecifiedUser(Integer roleId, Integer userId);

    /**
     * 从指定用户删除一个角色
     * @param roleId
     * @param userId
     * @return
     */
    Boolean deleteRoleToSpecifiedUser(Integer roleId, Integer userId);

    /**
     * 获取登陆用户的角色和权限
     * @param id
     * @return
     */
    List<LoginUserRolesVo> getLoginUserRolesAndPermissions(Integer id);
}