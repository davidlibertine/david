package com.ilabservice.intelab.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.io.Serializable;
import java.util.List;

@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class ResourcesNotFoundException extends RuntimeException {

    private List<Serializable> parameters;

    public List<Serializable> getParameters(){return parameters;}

    public ResourcesNotFoundException(String message, List<Serializable> parameters){
        super(message);
        this.parameters = parameters;
    }
}
