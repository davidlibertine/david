package com.ilabservice.intelab.model;

import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-09 15:42:09
 */
@Data
@ApiModel(value = "location")
@TableName("location")
public class Location extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    @TableField(value="parent_id")
    private Integer parentId;
	
    @ApiModelProperty(value = "")
    private String name;
	
    @ApiModelProperty(value = "")
    private String description;
	
    @ApiModelProperty(value = "")
    private String address;
	
    @ApiModelProperty(value = "")
    @TableField(value="location_type")
    private String locationType;
	
    @ApiModelProperty(value = "")
    private String timezone;
	
    @ApiModelProperty(value = "")
    private BigDecimal latitude;
	
    @ApiModelProperty(value = "")
    private BigDecimal longtitude;
	
    @ApiModelProperty(value = "")
    @TableField(value="create_datetime")
    private Date createDatetime;
	
    @ApiModelProperty(value = "")
    @TableField(value="x_location" )
    private Float xLocation;
	
    @ApiModelProperty(value = "")
    @TableField(value="y_location")
    private Float yLocation;
	
    @ApiModelProperty(value = "")
    @TableField(value="is_root")
    private Integer isRoot;
	
    @ApiModelProperty(value = "")
    @TableField(value="is_leaf")
    private Integer isLeaf;

    @ApiModelProperty(value = "")
    private Integer companyId;

    @ApiModelProperty(value = "")
    private String background;
    /**
     * ????, ???????? false ??
     */
    @ApiModelProperty(value = "????, ???????? false ??")
    @TableField(value="is_enabled")
    private Integer isEnabled;

    @TableField(exist=false)
    private List<Location> childLocations;
    @TableField(exist=false)
    private List<MonitoringTarget> monitoringTargets;
    @TableField(exist=false)
    private Integer monitorTargetNum;
    @TableField(exist=false)
    private Integer yellowAlertCountToday;
    @TableField(exist=false)
    private Integer redAlertCountToday;
    @TableField(exist=false)
    private Integer onlineCount;
    @TableField(exist=false)
    private Integer offlineCount;

}
