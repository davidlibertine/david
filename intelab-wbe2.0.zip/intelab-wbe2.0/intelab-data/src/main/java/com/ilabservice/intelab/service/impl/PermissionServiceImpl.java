package com.ilabservice.intelab.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ilabservice.intelab.mapper.PermissionMapper;
import com.ilabservice.intelab.mapper.RolePermissionMapMapper;
import com.ilabservice.intelab.model.Permission;
import com.ilabservice.intelab.service.PermissionService;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class PermissionServiceImpl implements PermissionService {

    @Resource
    private PermissionMapper permissionMapper;

    @Resource
    private RolePermissionMapMapper rolePermissionMapMapper;

    /**
     * 获取所有数据库中现存的权限
     * @return
     */
    @Override
    public PageInfo getAllPermission(Integer limit, Integer offset) {
        List<Permission> permissionList = permissionMapper.getAllPermission();
        if(permissionList.size() > 0) {
            PageHelper.startPage(limit, offset);
            PageInfo pageInfo = new PageInfo();
            pageInfo.setList(permissionList);
            return pageInfo;
        }
        return null;
    }

    /**
     * 新增一个权限
     * @param permission
     * @return
     */
    @Override
    public Permission addPermission(Permission permission) {
        permission.setCreateDatetime(new Date());
        if(permissionMapper.insert(permission) > 0) {
            Permission newPermission = permissionMapper.getPermissionByPermissionId(permission.getId());
            return newPermission != null ? newPermission : null;
        }
        return null;
    }

    /**
     * 通过id删除一个权限
     * @param id
     * @return
     */
    @Override
    @Transactional(rollbackFor = {Exception.class,RuntimeException.class})
    @Retryable(value= {Exception.class,RuntimeException.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public Boolean deletePermission(Integer id) {
        /**
         * 判断权限是否存在
         */
        Permission permission = permissionMapper.selectById(id);
        if(permission == null) {
            return null;
        }
        /**
         * 查询该权限是否已经绑定了角色，如果有則不允許刪除
         */
        if(rolePermissionMapMapper.getRolePermissionMapListByPermissionId(id) != null) {
            return false;
        }
        if(permissionMapper.deleteById(id)> 0) {
            return true;
        }
        return false;
    }

    /**
     * 修改权限
     * @param id
     * @return
     */
    @Override
    @Transactional(rollbackFor = {Exception.class,RuntimeException.class})
    @Retryable(value= {Exception.class,RuntimeException.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public Boolean updatePermission(Integer id, Permission permission) {
        /**
         * 判断权限是否存在
         */
        Permission permissionExits = permissionMapper.selectById(id);
        if(permission == null) {
            return null;
        }
        permission.setId(id);
        return permissionMapper.updateById(permission) > 0 ? true : false;
    }
}
