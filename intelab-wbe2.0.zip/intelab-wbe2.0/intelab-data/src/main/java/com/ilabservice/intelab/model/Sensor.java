package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Data
@ApiModel(value = "sensor")
@TableName("sensor")
public class Sensor extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private String serialNo;
	
    @ApiModelProperty(value = "")
    private Integer deviceId;
	
    @ApiModelProperty(value = "")
    private Integer sampleFrequency;

    @ApiModelProperty(value = "")
    private String sampleTimeUnit;
	
    @ApiModelProperty(value = "")
    private BigDecimal zeroDrift;
	
    @ApiModelProperty(value = "")
    private String calibrationFrequency;
	
    @ApiModelProperty(value = "")
    private Date lastCalibrationDate;
	
    @ApiModelProperty(value = "")
    private Float inputHigh;
	
    @ApiModelProperty(value = "")
    private Float inputLow;
	
    @ApiModelProperty(value = "")
    private Float outputHigh;
	
    @ApiModelProperty(value = "")
    private Float outputLow;
	
    @ApiModelProperty(value = "")
    private Date createDatetime;

    @TableField(exist = false)
    private IotTerminal iotTerminal;

}
