package com.ilabservice.intelab.mapper;

import com.ilabservice.intelab.model.Permission;
import com.ilabservice.intelab.model.RolePermissionMap;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface RolePermissionMapMapper extends BaseMapper<RolePermissionMap> {

    public List<Permission> getPermissionByRoleId(@Param("roleId") Integer roleId);

    List<RolePermissionMap> getRolePermissionMapListByPermissionId(@Param("permissionId") Integer permissionId);

    Integer deletePermissionAndRoleByPermissionId(@Param("permissionId") Integer permissionId);

    RolePermissionMap getUserRolePermissionMapByRoleId(@Param("roleId") Integer roleId);

    Integer deleteOneOrMorePermissionsFromTheSpecifiedRole(@Param("roleId") Integer roleId, @Param("permissionIdList") List<Integer> permissionIdList);

    Integer addOneToMultiplePermissionsToGivenRole(@Param("list") List list);
}