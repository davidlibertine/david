package com.ilabservice.intelab.service;

import com.ilabservice.intelab.model.Role;

import java.util.List;

public interface RoleService {

    /**
     * 查询所有用户角色
     * @return
     */
    List<Role> getAllUserRoles();

    /**
     * 删除指定角色
     * @param id
     * @return
     */
    Boolean deleteRoleByRoleId(Integer id);

    /**
     * 更新指定角色
     * @param id
     * @return
     */
    Boolean updateRoleByRoleId(Integer id, Role role);

    /**
     * 新增角色
     * @param role
     * @return
     */
    Role addRole(Role role);

    /**
     * 从指定角色删除一到多个权限
     * @param roleId
     * @param permissionIdList
     * @return
     */
    Boolean deleteOneOrMorePermissionsFromTheSpecifiedRole(Integer roleId, List<Integer> permissionIdList);

    /**
     * 给指定角色添加一到多个权限
     * @param roleId
     * @param permissionIdList
     * @return
     */
    Boolean addOneToMultiplePermissionsToGivenRole(Integer roleId, List<Integer> permissionIdList);

}
