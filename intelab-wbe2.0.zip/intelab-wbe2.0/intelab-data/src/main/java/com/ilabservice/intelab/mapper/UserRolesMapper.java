package com.ilabservice.intelab.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ilabservice.intelab.model.Role;
import com.ilabservice.intelab.model.User;
import com.ilabservice.intelab.model.UserRolesMap;

import java.io.Serializable;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface UserRolesMapper extends BaseMapper<UserRolesMap> {

    int add(UserRolesMap userRolesMap);
    public User findUserByRoleId(Serializable roleId);
    public List<Role> findListRoleByUserId(Serializable userId);
    /**
     * 查詢該用戶的角色id
     */
    public List<Role> getLoginRoleIdByLoginUserId(@Param("userId") Integer userId);

    List<UserRolesMap> findListRoleIdByUserId(@Param("userId") String userId);

    Integer deleteRoleToSpecifiedUser(@Param("roleId") String roleId, @Param("userId") String userId);

    UserRolesMap getUserRolesMapByRoleId(@Param("roleId") Integer roleId);
    
}
