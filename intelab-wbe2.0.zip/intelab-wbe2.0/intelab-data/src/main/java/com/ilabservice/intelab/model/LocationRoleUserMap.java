package com.ilabservice.intelab.model;

import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.ilabservice.intelab.model.BaseEntity;
import com.ilabservice.intelab.common.annotation.EnableParam;
import com.ilabservice.intelab.common.annotation.FillAuto;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-09 15:42:09
 */
@Data
@ApiModel(value = "location_role_user_map")
@TableName("location_role_user_map")
public class LocationRoleUserMap extends BaseEntity{

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    @TableField(value="location_id")
    private Integer locationId;
	
    @ApiModelProperty(value = "")
    @TableField(value="user_id")
    private Integer userId;
	
    @ApiModelProperty(value = "")
    @TableField(value="role_id")
    private Integer roleId;
	
    @ApiModelProperty(value = "")
    @TableField(value="create_datetime")
    private Date createDatetime;
	

}
