package com.ilabservice.intelab.service.impl;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ilabservice.intelab.common.ResultErrorCode;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.model.*;
import com.ilabservice.intelab.storage.FileUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ilabservice.intelab.mapper.CompanyContractMapper;
import com.ilabservice.intelab.mapper.CompanyExtraFeatureMapMapper;
import com.ilabservice.intelab.mapper.CompanyMapper;
import com.ilabservice.intelab.mapper.ExtraFeatureMapper;
import com.ilabservice.intelab.mapper.LocationMapper;
import com.ilabservice.intelab.mapper.UserMapper;
import com.ilabservice.intelab.service.CompanyService;
import com.ilabservice.intelab.service.base.impl.BaseServiceImpl;
import com.ilabservice.intelab.utils.DateUtil;
import com.ilabservice.intelab.utils.MD5Utils;
import com.ilabservice.intelab.utils.UUIDUtils;
import com.ilabservice.intelab.vo.CompanyContractVo;
import com.ilabservice.intelab.vo.CompanyVo;
import com.sun.tools.corba.se.idl.StringGen;

@Service
public class CompanyServiceImpl extends BaseServiceImpl<CompanyMapper, Company> implements CompanyService{
    @Autowired
    private  CompanyMapper companyMapper;
    @Autowired
    private CompanyContractMapper companyConstractMapper;
    @Autowired
    private LocationMapper locationMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private  CompanyExtraFeatureMapMapper companyExtraFeatureMapMapper;
    @Autowired
	FileUploadService fileUploadService;
	@Override
	public Company selectCompanyAndExtraFeatureById(Serializable companyId) {
		Company company=companyMapper.selectCompanyById(companyId);
		List<ExtraFeature> extraFeatures=companyMapper.findListExtraFeatureByCompanyId(company.getId());
		company.setExtraFeatures(extraFeatures);
		return company;
	}
	@Override
	public int findCompanyCount() {
		return companyMapper.findCompanyCount();
	}

	@Override
	public Company getCompanyById(Integer id) {
		Company company=companyMapper.selectById(id);
		return company;

	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	@Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
	public void updateCompany(Company company) {
		companyMapper.updateById(company);
	}

	@Override
	public List<Company> getAdminCompanysPage(Integer limit, Integer offset) {
		List<Company> companies=companyMapper.selectPage(new Page<>(offset, limit), new EntityWrapper<>());
		return companies;
	}
	@Override
	@Transactional(rollbackFor = Exception.class)
	@Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
	public Company createCompanyInfo(MultipartFile file,List<Integer> featureIdList, CompanyExtend companyExtend) {
		Company company=new Company();
		company.setName(companyExtend.getName());
		company.setAddress(companyExtend.getAddress());
		company.setEmail(companyExtend.getEmail());
		company.setDomainName(companyExtend.getDomainName());
		company.setTelephone(companyExtend.getTelephone());
		company.setCreateDatetime(new Date());
		Integer companyId=companyMapper.createCompany(company);
		if(companyId==null){
			throw  new UserException(null,ResultErrorCode.COMPANY_CREATE_FAIL.getValue(),ResultErrorCode.COMPANY_CREATE_FAIL.getCode());
		}
		String url = fileUploadService.uploadFile(file, "company" + companyId.toString(),
				"building/" + file.getName(), null);
		Company company1=companyMapper.selectById(companyId);
		company1.setBackgroundUrl(url);
		companyMapper.updateById(company1);
		User user=new User();
		user.setName(companyExtend.getManagerName());
		user.setUserName(companyExtend.getManagerLoginUsername());
		user.setCompanyId(companyId);
		user.setPassword(MD5Utils.md5Encode("ilabservice", "utf-8"));
		user.setCreateDatetime(new Date());
		userMapper.insert(user);
		Location location=new Location();
		location.setLongtitude(companyExtend.getLongitude());
		location.setLatitude(companyExtend.getLatitude());
		location.setCompanyId(companyId);
		location.setName(companyExtend.getName());
		location.setIsLeaf(1);
		location.setCreateDatetime(new Date());
		if(url==null) {
			location.setLocationType("map");
            location.setIsRoot(0);
		}else{
			location.setLocationType("campus");
            location.setIsRoot(1);
		}
		locationMapper.insert(location);
		List list = Lists.newArrayList();
        Map<String, Integer> map = Maps.newHashMap();
        for(Integer featuresId : featureIdList) {
            map.put("companyId", companyId);
            map.put("featuresId", featuresId);
            list.add(map);
        }
	    companyExtraFeatureMapMapper.addOneOrMoreProductFeaturesTCompany(list);
		return this.selectCompanyAndExtraFeatureById(companyId);
	
	}
	@Override
	@Transactional(rollbackFor = Exception.class)
	@Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
	public Company  updateCompanyInfo(MultipartFile file, CompanyExtend companyExtend,Integer id) throws Exception{
		Company company=new Company();
		company.setId(id);
		company.setAddress(companyExtend.getAddress());
		company.setEmail(companyExtend.getEmail());
		company.setDomainName(companyExtend.getDomainName());
		company.setTelephone(companyExtend.getTelephone());
		String oldName=companyMapper.selectById(id).getBackgroundUrl();
		String url = fileUploadService.uploadFile(file, "company" + id.toString(),
				"building/" + file.getName(), oldName);
		company.setBackgroundUrl(url);
		companyMapper.updateById(company);
		Location location=new Location();
		location.setLongtitude(companyExtend.getLongitude());
		location.setLatitude(companyExtend.getLatitude());
		location.setCompanyId(id);
		companyMapper.updateCompanyInfo(location);
		return this.selectCompanyAndExtraFeatureById(id);
	}
	@Override
	public List<CompanyContract> findListCompanyContractByCompanyId(Serializable companyId) {
		List<CompanyContract> companyContracts=companyMapper.findListCompanyContractByCompanyId(companyId);
		return companyContracts;
	}
	@Override
	@Transactional(rollbackFor = Exception.class)
	@Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
	public CompanyContract addCompanyContract(CompanyContractExtend companyContractExtend,Serializable companyId) throws Exception {
		CompanyContract companyContract=new CompanyContract();
		companyContract.setCompanyId(Integer.parseInt(companyId.toString()));
		companyContract.setStartDate(DateUtil.formatTimestampDate(companyContractExtend.getStartDate()));
		companyContract.setEndDate(DateUtil.formatTimestampDate(companyContractExtend.getEndDate()));
		companyContract.setSignDate(DateUtil.formatTimestampDate(companyContractExtend.getSignDate()));
		companyContract.setDescription(companyContractExtend.getDescription());
		Integer id=companyConstractMapper.addCompanyContract(companyContract);
		if(id==null){
			throw  new UserException(null,ResultErrorCode.COMPANYCONTRACT_INSERT_FAIL.getValue(),ResultErrorCode.COMPANYCONTRACT_INSERT_FAIL.getCode());
		}
		return companyConstractMapper.selectById(id);
	}
	@Override
	@Transactional(rollbackFor = Exception.class)
	@Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
	public boolean updateCompanyContract(CompanyContractExtend companyContractExtend,Serializable contractId) throws Exception {
		CompanyContract companyContract=new CompanyContract();
		companyContract.setId(Integer.parseInt(contractId.toString()));
		companyContract.setCompanyId(companyContractExtend.getCompanyId());
		companyContract.setStartDate(DateUtil.formatTimestampDate(companyContractExtend.getStartDate()));
		companyContract.setEndDate(DateUtil.formatTimestampDate(companyContractExtend.getEndDate()));
		companyContract.setSignDate(DateUtil.formatTimestampDate(companyContractExtend.getSignDate()));
		companyContract.setDescription(companyContractExtend.getDescription());
		return companyConstractMapper.updateById(companyContract)==1;
	}


}
