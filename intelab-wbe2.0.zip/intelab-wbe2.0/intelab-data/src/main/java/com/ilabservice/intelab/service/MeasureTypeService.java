package com.ilabservice.intelab.service;

import com.ilabservice.intelab.model.MeasureType;

import java.util.List;

public interface MeasureTypeService {

    /**
     * 根据 id 查询监控参数
     * @param id
     * @return
     */
    MeasureType getMeasureTypeById(Integer id);

    /**
     * 获取所有的监控参数
     * @return
     */
    List<MeasureType> getAllMeasureType();

    /**
     * 根据 id 删除监控参数
     * @param id
     * @return
     */
    boolean deleteMeasureTypeById(Integer id);

    /**
     * 根据 id 更新监控参数
     * @param id
     * @param newMeasureType
     * @return
     */
    boolean updateMeasureTypeById(Integer id, MeasureType newMeasureType);

    /**
     * 新增监控参数
     * @param newMeasureType
     * @return
     */
    boolean addMeasureTyp(MeasureType newMeasureType);
}