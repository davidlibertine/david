package com.ilabservice.intelab.service;

import com.ilabservice.intelab.model.DeviceFiles;
import com.ilabservice.intelab.model.LabDevice;
import com.ilabservice.intelab.model.MonitorTargetLabDevice;
import com.ilabservice.intelab.model.MonitoringTargetMeasureRule;
import com.ilabservice.intelab.vo.LabDeviceVo;

import java.util.List;
import java.util.Map;

public interface LabDeviceService {

    /**
     * 新建监控对象设备
     * @param monitorTargetLabDevice
     * @param userId
     * @return
     */
    Map<String, Object> addLabDevice(MonitorTargetLabDevice monitorTargetLabDevice, Integer userId);
   List<LabDevice> getUserLabDevice(Integer monitorTargetTypeId,Integer companyId,Integer locationId,LabDevice labDevice,Integer limit,Integer offset);
    LabDevice findLabDeviceMonitorTargetById(Integer id);
    boolean updateLabDevice(MonitorTargetLabDevice monitorTargetLabDevice,Integer id);
    boolean deleteMonitoringTargetAndLabDeviceById(Integer id);
    boolean deleteDeviceFile(Integer id,Integer fileId);
    List<DeviceFiles> findDeviceFiles(Integer id);
    boolean addDeviceFilesImage(String url,Integer id);
    LabDevice getLabDeviceById(Integer id);
    boolean updateLabDeviceImage(LabDevice labDevice);
    boolean deleteMonitoringTargetRule(Integer monitorTargetId,Integer ruleId);
    boolean updateMonitorTargetMeasureTypeRule(Integer monitorTargetId, Integer ruleId, MonitoringTargetMeasureRule monitoringTargetMeasureRule,String measureTypeName);
}
