package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableField;
import lombok.Data;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;


@Data
@ApiModel(value = "role_permission_map")
@TableName("role_permission_map")
public class RolePermissionMap extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;

    @ApiModelProperty(value = "")
    private Integer roleId;

    @ApiModelProperty(value = "")
    private Integer permissionId;

    @TableField(exist = false)
    private Permission permission;

    @TableField(exist = false)
    private Role role;


}