package com.ilabservice.intelab.vo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LocationBasicVo {
    private Integer id;
    private String name;
    private String locationType;
    private String xCoordinate;
    private String yCoordinate;
}
