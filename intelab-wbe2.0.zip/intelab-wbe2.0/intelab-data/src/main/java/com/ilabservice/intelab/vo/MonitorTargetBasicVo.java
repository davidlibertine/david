package com.ilabservice.intelab.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MonitorTargetBasicVo {
    private Integer id;
    private String name;
    private String monitorTargetType;
    private String photoUrl;
    private String xCoordinate;
    private String yCoordinate;
}
