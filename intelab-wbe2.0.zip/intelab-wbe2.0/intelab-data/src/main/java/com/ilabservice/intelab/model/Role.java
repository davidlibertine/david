package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 *
 * @author RedWall
 * @email walkmanlucas@gmail.com
 * @date 2018-04-20
 * @desc 用户角色
 */
@Data
@TableName("role")
public class Role extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId("id")
    private Integer id;

    @TableField(value = "name")
    private String name;

    @TableField(value = "description")
    private String description;

    @TableField(value = "role_type")
    private String roleType;

    @TableField(value = "create_datetime")
    private Date createDatetime;

    @TableField(exist = false)
    private List<Permission> permissions;

}
