package com.ilabservice.intelab.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanyContractExtend {
    private Integer id;
    private Integer companyId;
    private Long startDate;
    private Long endDate;
    private Long signDate;
    private String description;

}
