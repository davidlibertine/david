package com.ilabservice.intelab.service.impl;


import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ilabservice.intelab.exceptions.UserException;
import com.ilabservice.intelab.mapper.*;
import com.ilabservice.intelab.model.*;
import com.ilabservice.intelab.service.base.impl.BaseServiceImpl;
import com.ilabservice.intelab.service.UserService;
import com.ilabservice.intelab.vo.LoginUserRolesVo;
import com.ilabservice.intelab.vo.UserVo;
import com.ilabservice.intelab.vo.assemblyvo.UserVoMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 
 *
 * @author RedWall
 * @email walkmanlucas@gmail.com
 * @date 2018-04-18 14:41:05*/

@Service
public class UserServiceImpl extends BaseServiceImpl<UserMapper,User> implements UserService {

    @Autowired
    UserMapper userMapper;

    @Autowired
    RoleMapper rolesMapper;

    @Autowired
    PermissionMapper permissionMapper;

    @Autowired
    UserRolesMapper userRolesMapper;

    @Resource
    private CompanyMapper companyMapper;

    @Resource
    private UserLocationMonitoringTargetMapper userLocationMonitoringTargetMapper;

    @Resource
    private LocationRoleUserMapMapper locationRoleUserMapMapper;

    @Resource
    private ResourceTypeRoleUserMapMapper resourceTypeRoleUserMapMapper;

    @Resource
    private LeaseRecordMapper leaseRecordMapper;

    @Resource
    private MonitoringTargetMapper monitoringTargetMapper;

    @Resource
    private ResourceRoleUserMapMapper resourceRoleUserMapMapper;


    /**
     * 删除用户需要同时把用户和角色的关联关系删除
     * 其他有关联关系的同样操作几张表即可
     * */
    /**
     * @Retryable注解
     * 被注解的方法发生异常时会重试
        value			指定发生的异常进行重试
        include			和value一样，默认空，当exclude也为空时，所有异常都重试
        exclude 		指定异常不重试，默认空，当include也为空时，所有异常都重试
        maxAttemps:  	重试次数，默认3
        backoff   		重试补偿机制，默认没有
        RetryOperations定义了重试的API，RetryTemplate提供了模板实现，线程安全的，
        同于Spring 一贯的API风格，RetryTemplate将重试、熔断功能封装到模板中，提供健壮和不易出错的API供大家使用。
        backoff 重试机制有很多种
                1：固定时间重试
                2：随机时间重试
                3：渐变式重试  比如一开始1秒钟重试一次，再5秒重试一次，等等类似等差或者等比数列这种
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    @Retryable(value = { Exception.class }, maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay=500))
    public boolean deleteById(Serializable id){
        return userMapper.deleteById(id) == 1;
    }


    @Recover
    public boolean recover(Exception e,Serializable id) {
        /**
         * 重试方法中的参数必须和原方法的参数一致
         * */
        return false;
    }


    @Override
    public User getUserDetailInfo(Serializable id){
        User user = userMapper.getUserById(id);
        return user;
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    @Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean updateById(User user){
        return userMapper.updateById(user) == 1;
    }


    @Recover
    public boolean recover(Exception e, User user){
        return false;
    }


    @Override
    public User getUserIdAndPasswordByUserName(Serializable userName){
        User user = userMapper.getUserIdAndPasswordByUserName(userName);
        return user;
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    @Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean addRoleToUser(Role role, User user){
        UserRolesMap userRolesMap = new UserRolesMap();
        userRolesMap.setUserID(user.getId().toString());
        userRolesMap.setRoleID(role.getId().toString());
        return userRolesMapper.add(userRolesMap) == 1;
    }


    @Recover
    public boolean recover(Exception e, Role role, User user){
        return false;
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    @Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean deleteRoleFromUser(Role role, User user) {
        UserRolesMap userRolesMap = new UserRolesMap();
        userRolesMap.setRoleID(role.getId().toString());
        userRolesMap.setUserID(user.getId().toString());
        return userRolesMapper.delete(new EntityWrapper<>(userRolesMap)) == 1;
    }

    /**
     * 獲取當前登陸用戶的信息
     * @return
     */
    @Override
    public User getLoginUserInfoByUserId(Integer userId) throws UserException {
        User user = userMapper.selectById(userId);
        return user != null ? user : null;
    }

    /**
     * 更新當前用戶的信息並返回更新後的信息
     * @param oldUser
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    @Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public User updateOldUserInfoReturnNewUserInfo(User oldUser, Integer userId) throws UserException {
        /**
         * set userId
         * set updateTime
         */
        oldUser.setId(userId);
        oldUser.setUpdateDatetime(new Date());
        /**
         * 如果返回結果大於0，更新成功,失敗直接返回null，由controller處理
         */
        if(userMapper.updateUserByPrimaryKeySelective(oldUser) > 0) {
            /**
             * 查詢新的信息，重新封裝
             */
            User newUser = userMapper.selectById(oldUser.getId());
            return newUser != null ? newUser : null;
        }
        return null;
    }

    /**
     * 更新當前登陸用戶的頭像
     * @param userId
     * @param imgUrl
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    @Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public String updateLoginUserHeadIcon(Integer userId, String imgUrl) throws UserException {
        /**
         * 查詢當前用戶的個人信息,重新設置頭像路徑,更新用戶信息
         */
        User oldUser = userMapper.getUserById(userId);
        oldUser.setHeadIcon(imgUrl);
        if(userMapper.updateUserByPrimaryKeySelective(oldUser) > 0) {
            /**
             * 查詢新的信息，重新封裝
             */
            User newUser = userMapper.selectById(oldUser.getId());
            return newUser != null ? newUser.getHeadIcon() : null;
        }

        return null;
    }

    /**
     * 修改密碼
     * @param userId
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    @Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean updateLoginUserPassword(Integer userId, String newPwd) throws UserException {
        User user = userMapper.selectById(userId);
        user.setPassword(newPwd);
        user.setLatestPasswordUpdateTime(new Date());
        return userMapper.updateUserByPrimaryKeySelective(user) > 0 ? true : false;
    }

    /**
     * 獲取該用戶所在公司的全部用戶，該用戶必須是管理員
     * @param limit
     * @param offset
     * @return
     */
    @Override
    public PageInfo getLoginUserCompanyUser(Integer limit, Integer offset, Integer userId) throws UserException {
        List<Company> companies = Lists.newArrayList();
        Integer companyId = userMapper.selectById(userId).getCompanyId();
        Company company = companyMapper.selectById(companyId);
        /**
         * 查出該公司的所有用戶
         */
        List<User> users = userMapper.getUserListByCompanyId(companyId);
        if(users != null) {
            List<UserVo> userVoList = UserVoMapper.getUserVoByUserModelAndCompanyModel(users, company);
            PageHelper.startPage(limit, offset);
            PageInfo pageInfo = new PageInfo(users);
            pageInfo.setList(userVoList);
            return pageInfo;
        }
        return null;
    }

    /**
     * 為該公司添加一個用戶
     * @param newUser
     * @param userId
     * @return
     */
    @Override
    public Map<String, Object> addUserForCompany(User newUser, Integer userId)  throws UserException {
        Map<String, Object> map = Maps.newHashMap();
        User user = userMapper.getUserById(userId);
        /**
         * 设置新用户的companyId和创建时间
         */
        newUser.setCompanyId(user.getCompanyId());
        newUser.setCreateDatetime(new Date());
        /**
         * 如果添加成功，把该用户的companyDomainName和user一起返回给前端
         */
        if(userMapper.insert(newUser) > 0) {
            Company company = companyMapper.selectById(user.getCompanyId());
            map.put("userInfo", newUser);
            map.put("company", company);
            return map;
        }
        return null;
    }

    /**
     * 根据id查询用户
     * @param userId
     * @return
     */
    @Override
    public Map<String, Object> getUserInfoByUserId(Integer userId)  throws UserException {
        Map<String, Object> map = Maps.newHashMap();
        User user = userMapper.getUserById(userId);
        if(user != null) {
            Company company = companyMapper.selectById(user.getCompanyId());
            map.put("userInfo", user);
            map.put("company", company);
            return map;
        }
        return null;
    }

    /**
     * 根据id删除用户
     * @param userId
     * @return
     */
    @Override
    @Transactional(rollbackFor = {Exception.class, RuntimeException.class})
    @Retryable(value= {Exception.class, RuntimeException.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public boolean delectUserById(Integer userId)  throws UserException {
        /**
         * 校验该用户是否存在
         */
        User user = userMapper.getUserById(userId);
        if(user != null) {
            /**
             * 校验一下该user是否与其他表之间存在关系，如果存在则不允许删除
             */
            UserLocationMonitoringTarget userLocationMonitoringTarget = userLocationMonitoringTargetMapper.selectByUserId(userId);
            LocationRoleUserMap locationRoleUserMap = locationRoleUserMapMapper.selectByUserId(userId);
            ResourceTypeRoleUserMap resourceTypeRoleUserMap = resourceTypeRoleUserMapMapper.selectByUserId(userId);
            LeaseRecord leaseRecord = leaseRecordMapper.selectByUserId(userId);
            MonitoringTarget monitoringTarget = monitoringTargetMapper.selectByUserId(userId);
            ResourceRoleUserMap resourceRoleUserMap = resourceRoleUserMapMapper.selectByUserId(userId);
            if(userLocationMonitoringTarget != null || locationRoleUserMap != null
                    || resourceTypeRoleUserMap != null || leaseRecord != null
                    || monitoringTarget != null || resourceRoleUserMap != null) {
                return false;
            }
            /**
             * 允许删除用户
             */
            return userMapper.deleteById(userId) > 0 ? true : false;
        }
        return false;
    }

    /**
     * 根据id更新指定用户
     * @param id
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    @Retryable(value= {Exception.class} , maxAttempts = 3, backoff = @Backoff(delay=100, maxDelay = 500))
    public Map<String, Object> updateUserInfoById(Integer id, User user, Integer loginUserId)  throws UserException {
        Map<String, Object> map = Maps.newHashMap();
        user.setId(id);
        user.setUpdateDatetime(new Date());
        Company company = companyMapper.selectById(
                userMapper.getUserById(loginUserId).getCompanyId()
        );
        user.setCompanyId(company.getId());
        if(userMapper.updateUserByPrimaryKeySelective(user) > 0) {
            map.put("userInfo", user);
            map.put("company", company);
            return map;
        }
        return null;
    }

    /**
     * 给指定用户添加角色
     * @param roleId
     * @param userId
     * @return
     */
    @Override
    public Boolean addRoleToSpecifiedUser(Integer roleId, Integer userId)  throws UserException {
        UserRolesMap userRolesMap = new UserRolesMap();
        /**
         * role_id → id
         * role_id 是否存在于role表中，如果不存在，由于主外键关系的存在，不允许直接添加
         */
        Role roleExits = rolesMapper.selectById(roleId);
        if(roleExits == null) {
            return false;
        }
        /**
         * 查看一下该用户是否已经拥有了此角色,如果有则不允许添加
         */
        List<UserRolesMap> userRolesMapList = userRolesMapper.findListRoleIdByUserId(userId.toString());
        for(UserRolesMap userRolesMap1 : userRolesMapList) {
            if(StringUtils.equals(userRolesMap1.getRoleID(), roleId.toString())) {
                return false;
            }
        }
        /**
         * 给该用户赋予角色
         */
        userRolesMap.setUserID(userId.toString());
        userRolesMap.setRoleID(roleId.toString());
        return userRolesMapper.add(userRolesMap) > 0 ? true :false;
    }

    /**
     * 从指定用户删除一个角色
     * @param roleId
     * @param userId
     * @return
     */
    @Override
    public Boolean deleteRoleToSpecifiedUser(Integer roleId, Integer userId)  throws UserException {
        /**
         * 先校验该用户是否拥有该角色,如果没有该角色，无法正确删除
         */
        List<UserRolesMap> userRolesMapList = userRolesMapper.findListRoleIdByUserId(userId.toString());
        for(UserRolesMap userRolesMap1 : userRolesMapList) {
            if(StringUtils.equals(userRolesMap1.getRoleID(), roleId.toString())) {
                return userRolesMapper.deleteRoleToSpecifiedUser(roleId.toString(), userId.toString()) > 0 ? true : false;
            }
        }
        return false;
    }

    /**
     * 获取登陆用户的角色和权限
     * @param id
     * @return
     */
    @Override
    public List<LoginUserRolesVo> getLoginUserRolesAndPermissions(Integer id) throws UserException {
        List<LoginUserRolesVo> loginUserRolesVos = Lists.newArrayList();
        LoginUserRolesVo loginUserRolesVo = new LoginUserRolesVo();
        /**
         * 根据userId查询role
         */
        List<Role> roles = userMapper.listAllRolesByUserid(id);
        for(Role role : roles) {
            loginUserRolesVo.setRoles(role);
            List<Permission> permissions = userMapper.listAllPermissionsByRoleid(role.getId());
            loginUserRolesVo.setPermissions(permissions);
            loginUserRolesVos.add(loginUserRolesVo);
        }
        return loginUserRolesVos;
    }


}