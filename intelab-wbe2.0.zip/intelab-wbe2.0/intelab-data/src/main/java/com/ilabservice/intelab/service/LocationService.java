package com.ilabservice.intelab.service;

import com.ilabservice.intelab.model.Location;
import com.ilabservice.intelab.service.base.BaseService;

import java.io.Serializable;

public interface LocationService extends BaseService<Location> {

    Location getRootLocationsByCompanyId(Serializable companyId);

    void fillLocationWithMonitoringTarget(Location location, Serializable userId);

    void updateLocation(Location location);

    void insertChildLocation(Location location);

    Location getLocationById(Serializable locationId);

    void deleteLocationAndChild(Serializable locationId);

}
