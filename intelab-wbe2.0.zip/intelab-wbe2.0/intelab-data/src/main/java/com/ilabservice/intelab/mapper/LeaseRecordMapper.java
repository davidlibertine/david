package com.ilabservice.intelab.mapper;

import com.ilabservice.intelab.model.LeaseRecord;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ilabservice.intelab.model.ResourceTypeRoleUserMap;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Mapper
public interface LeaseRecordMapper extends BaseMapper<LeaseRecord> {

    LeaseRecord selectByUserId(@Param("userId") Integer userId);
}
