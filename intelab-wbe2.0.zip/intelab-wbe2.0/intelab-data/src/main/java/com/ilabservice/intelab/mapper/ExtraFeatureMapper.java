package com.ilabservice.intelab.mapper;

import com.ilabservice.intelab.model.ExtraFeature;
import com.baomidou.mybatisplus.mapper.BaseMapper;

import java.io.Serializable;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-09 21:06:04
 */
@Mapper
public interface ExtraFeatureMapper extends BaseMapper<ExtraFeature> {
	public List<ExtraFeature> findListExtraFeature(Serializable id);
	
}
