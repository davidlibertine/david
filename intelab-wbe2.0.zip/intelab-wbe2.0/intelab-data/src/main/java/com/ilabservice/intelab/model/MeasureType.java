package com.ilabservice.intelab.model;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-10 11:14:10
 */
@Data
@ApiModel(value = "measure_type")
@TableName("measure_type")
public class MeasureType extends BaseEntity {

	private static final long serialVersionUID = 1L;
	
    @ApiModelProperty(value = "")
    @TableId(value = "id")
    private Integer id;
	
    @ApiModelProperty(value = "")
    private String name;
	
    @ApiModelProperty(value = "")
    private String code;
	
    @ApiModelProperty(value = "")
    private String unit;
	
    @ApiModelProperty(value = "")
    private String measurement;
	

}
