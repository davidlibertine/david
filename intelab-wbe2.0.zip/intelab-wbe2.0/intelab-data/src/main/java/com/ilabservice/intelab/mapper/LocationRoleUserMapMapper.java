package com.ilabservice.intelab.mapper;

import com.ilabservice.intelab.model.LocationRoleUserMap;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 
 *
 * @author Wang Meng
 * @email walkmanlucas@gmail.com
 * @date 2018-05-09 21:06:04
 */
@Mapper
public interface LocationRoleUserMapMapper extends BaseMapper<LocationRoleUserMap> {

    LocationRoleUserMap selectByUserId(@Param("userId") Integer userId);
}
