package com.ilabservice.intelab.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class LocationVo {

    private Integer id;
    private String name;
    private Integer parentId;
    private Boolean isLeaf;
    private String locationType;
    private String description;
    private String address;
    private String xCoordinate;
    private String yCoordinate;
    private Integer monitorTargetNum;
    private Integer yellowAlertCountToday;
    private Integer redAlertCountToday;
    private Integer onlineCount;
    private Integer offlineCount;
    private String background;
    private List<LocationBasicVo> childLocations;
    private List<MonitorTargetBasicVo> monitorTargets;
}
