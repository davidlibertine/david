-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema ilabservice
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `ilabservice` ;

-- -----------------------------------------------------
-- Schema ilabservice
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `ilabservice` DEFAULT CHARACTER SET utf8mb4 ;
USE `ilabservice` ;

-- -----------------------------------------------------
-- Table `ilabservice`.`company`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`company` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`company` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `domain_name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `address` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `email` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `telephone` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `background_url` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  `login_url` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `update_datetime` DATETIME NULL DEFAULT NULL,
  `block_chain_address` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `is_enabled` TINYINT(1) NULL DEFAULT NULL COMMENT 'After deletion operation, it becomes false, only for admin analysis',
  PRIMARY KEY (`id`),
  UNIQUE INDEX `sys_code_UNIQUE` (`domain_name` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 2;


-- -----------------------------------------------------
-- Table `ilabservice`.`user`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`user` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`user` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `company_id` INT(11) NOT NULL,
  `user_name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `password` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `head_icon` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `mobile` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `telephone` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `gender` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `email` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `department` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `job` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `job_number` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `bind_mobile` INT(11) NULL DEFAULT NULL,
  `bind_email` INT(11) NULL DEFAULT NULL,
  `verify` INT(11) NULL DEFAULT NULL,
  `create_datetime` DATETIME NOT NULL,
  `update_datetime` DATETIME NULL DEFAULT NULL,
  `last_password_error_date` DATE NULL DEFAULT NULL,
  `password_error_retry_times` INT(11) NULL DEFAULT '0',
  `latest_password_update_time` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  `alert_notification_type` INT(11) NULL DEFAULT '0',
  `block_chain_address` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_user_company` (`company_id` ASC),
  CONSTRAINT `FK_user_company`
    FOREIGN KEY (`company_id`)
    REFERENCES `ilabservice`.`company` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 4;


-- -----------------------------------------------------
-- Table `ilabservice`.`location`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`location` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`location` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `parent_id` INT(11) NULL DEFAULT NULL,
  `name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `description` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `address` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `location_type` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `timezone` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `latitude` DECIMAL(12,9) NULL DEFAULT NULL,
  `longtitude` DECIMAL(12,9) NULL DEFAULT NULL,
  `create_datetime` DATETIME NOT NULL,
  `x_location` FLOAT(24,0) NULL DEFAULT NULL,
  `y_location` FLOAT(24,0) NULL DEFAULT NULL,
  `is_root` TINYINT(1) NOT NULL,
  `is_leaf` TINYINT(1) NOT NULL,
  `is_enabled` TINYINT(1) NULL DEFAULT NULL COMMENT '是否有效, 被删除的资产处于 false 状态',
  `company_id` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `SelfKey` (`parent_id` ASC),
  INDEX `FK_location_company_idx` (`company_id` ASC),
  CONSTRAINT `FK_location_company`
    FOREIGN KEY (`company_id`)
    REFERENCES `ilabservice`.`company` (`id`)
    ON UPDATE CASCADE,
  CONSTRAINT `SelfKey`
    FOREIGN KEY (`parent_id`)
    REFERENCES `ilabservice`.`location` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 8;


-- -----------------------------------------------------
-- Table `ilabservice`.`monitoring_target_type`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`monitoring_target_type` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`monitoring_target_type` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `description` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `logo_url` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `company_id` INT(11) NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_monitoring_target_type_company_id` (`company_id` ASC),
  CONSTRAINT `FK_monitoring_target_type_company_id`
    FOREIGN KEY (`company_id`)
    REFERENCES `ilabservice`.`company` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3;


-- -----------------------------------------------------
-- Table `ilabservice`.`monitoring_target`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`monitoring_target` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`monitoring_target` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `location_id` INT(11),
  `serial_no` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `monitoring_target_type_id` INT(11) NOT NULL,
  `ref_table` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `ref_table_id` INT(11) NOT NULL,
  `name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `owner_id` INT(11) NULL DEFAULT NULL,
  `creator_id` INT(11) NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  `is_enabled` TINYINT(1) NULL DEFAULT NULL,
  `status` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `latest_running_status` INT(11) NULL DEFAULT NULL,
  `company_id` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_monitoring_target_location` (`location_id` ASC),
  INDEX `FK_monitoring_target_monitoring_target_type` (`monitoring_target_type_id` ASC),
  INDEX `FK_monitoring_target_user` (`creator_id` ASC),
  INDEX `FK_monitoring_target_owner` (`owner_id` ASC),
  INDEX `FK_monitoring_target_company_idx` (`company_id` ASC),
  CONSTRAINT `FK_monitoring_target_company`
    FOREIGN KEY (`company_id`)
    REFERENCES `ilabservice`.`company` (`id`),
  CONSTRAINT `FK_monitoring_target_creator`
    FOREIGN KEY (`creator_id`)
    REFERENCES `ilabservice`.`user` (`id`),
  CONSTRAINT `FK_monitoring_target_location`
    FOREIGN KEY (`location_id`)
    REFERENCES `ilabservice`.`location` (`id`)
    ON DELETE SET NULL
    ON UPDATE SET NULL,
  CONSTRAINT `FK_monitoring_target_monitoring_target_type`
    FOREIGN KEY (`monitoring_target_type_id`)
    REFERENCES `ilabservice`.`monitoring_target_type` (`id`),
  CONSTRAINT `FK_monitoring_target_owner`
    FOREIGN KEY (`owner_id`)
    REFERENCES `ilabservice`.`user` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3;


-- -----------------------------------------------------
-- Table `ilabservice`.`camera_list`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`camera_list` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`camera_list` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `monitoring_target_id` INT(11) NOT NULL,
  `serial_no` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `play_url` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `description` VARCHAR(255) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_camera_list_monitoring_target` (`monitoring_target_id` ASC),
  CONSTRAINT `FK_camera_list_monitoring_target`
    FOREIGN KEY (`monitoring_target_id`)
    REFERENCES `ilabservice`.`monitoring_target` (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`common_lookup`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`common_lookup` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`common_lookup` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `category_name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `category_desc` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `code` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `value` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `sort_order` INT(11) NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 14;


-- -----------------------------------------------------
-- Table `ilabservice`.`company_contract`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`company_contract` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`company_contract` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `company_id` INT(11) NULL DEFAULT NULL,
  `start_date` DATE NULL DEFAULT NULL,
  `end_date` DATE NULL DEFAULT NULL,
  `description` VARCHAR(1024) NULL DEFAULT NULL,
  `sign_date` DATE NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_company_contract_company_idx` (`company_id` ASC),
  CONSTRAINT `FK_company_contract_company`
    FOREIGN KEY (`company_id`)
    REFERENCES `ilabservice`.`company` (`id`)
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`extra_feature`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`extra_feature` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`extra_feature` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(160) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `description` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `category` VARCHAR(160) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `tier` INT(3) NOT NULL,
  `parent_feature_id` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `SK_extra_feature_parent_feature_id_id` (`parent_feature_id` ASC),
  CONSTRAINT `SK_extra_feature_parent_feature_id_id`
    FOREIGN KEY (`parent_feature_id`)
    REFERENCES `ilabservice`.`extra_feature` (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`company_extra_feature_map`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`company_extra_feature_map` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`company_extra_feature_map` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `company_id` INT(11) NOT NULL,
  `extra_feature_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_company_extra_feature_map_company_id` (`company_id` ASC),
  INDEX `FK_company_extra_feature_map_extra_feature_id` (`extra_feature_id` ASC),
  CONSTRAINT `FK_company_extra_feature_map_company_id`
    FOREIGN KEY (`company_id`)
    REFERENCES `ilabservice`.`company` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FK_company_extra_feature_map_extra_feature_id`
    FOREIGN KEY (`extra_feature_id`)
    REFERENCES `ilabservice`.`extra_feature` (`id`)
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`lab_device`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`lab_device` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`lab_device` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `purchase_date` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `photo` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `manufacturer` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `model` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `health_score` FLOAT(24,0) NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  `asset_id` VARCHAR(45) NULL DEFAULT NULL,
  `product_line` VARCHAR(45) NULL DEFAULT NULL,
  `brand` VARCHAR(45) NULL DEFAULT NULL,
  `block_chain_key` VARCHAR(255) NULL DEFAULT NULL,
  `enable_sharing` TINYINT(1) NULL DEFAULT NULL,
  `lease_clause` TEXT NULL DEFAULT NULL,
  `lease_price_per_hour` FLOAT NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`device_files`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`device_files` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`device_files` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `url` VARCHAR(255) NULL DEFAULT NULL,
  `type` VARCHAR(64) NULL DEFAULT NULL,
  `description` VARCHAR(255) NULL DEFAULT NULL,
  `name` VARCHAR(255) NULL DEFAULT NULL,
  `device_id` INT(11) NULL DEFAULT NULL,
  `create_date` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_device_file_lab_device_idx` (`device_id` ASC),
  CONSTRAINT `FK_device_file_lab_device`
    FOREIGN KEY (`device_id`)
    REFERENCES `ilabservice`.`lab_device` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`iot_terminal`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`iot_terminal` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`iot_terminal` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `serial_no` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `battery_status` FLOAT(24,0) NULL DEFAULT NULL,
  `is_online` TINYINT(1) NULL DEFAULT NULL,
  `model` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `firmware_version` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3;


-- -----------------------------------------------------
-- Table `ilabservice`.`measure_type`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`measure_type` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`measure_type` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `code` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `unit` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `measurement` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT 'measurement',
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 48;


-- -----------------------------------------------------
-- Table `ilabservice`.`monitoring_target_measure_rule`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`monitoring_target_measure_rule` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`monitoring_target_measure_rule` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `definition` VARCHAR(1024) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL COMMENT 'JSON string for the rules',
  `monitoring_target_id` INT(11) NULL DEFAULT NULL,
  `measure_type_id` INT(11) NULL DEFAULT NULL,
  `purpose` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_monitoring_target_measure_rule_monitoring_target_idx` (`monitoring_target_id` ASC),
  INDEX `FK_monitoring_target_measure_rule_measure` (`measure_type_id` ASC),
  CONSTRAINT `FK_monitoring_target_measure_rule_measure`
    FOREIGN KEY (`measure_type_id`)
    REFERENCES `ilabservice`.`measure_type` (`id`)
    ON UPDATE CASCADE,
  CONSTRAINT `FK_monitoring_target_measure_rule_monitoring_target`
    FOREIGN KEY (`monitoring_target_id`)
    REFERENCES `ilabservice`.`monitoring_target` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 5;


-- -----------------------------------------------------
-- Table `ilabservice`.`event`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`event` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`event` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `iot_terminal_id` INT(11) NOT NULL,
  `monitoring_target_measure_rule_id` INT(11) NOT NULL,
  `counts` INT(11) NOT NULL,
  `start_datetime` DATETIME NOT NULL,
  `end_datetime` DATETIME NOT NULL,
  `diagnose_reason` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `corrective_action` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `process_status` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `last_process_datetime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_iot_terminal_id` (`iot_terminal_id` ASC),
  INDEX `FK_event_monitoring_target_meaure_rule_idx` (`monitoring_target_measure_rule_id` ASC),
  CONSTRAINT `FK_event_iot_terminal`
    FOREIGN KEY (`iot_terminal_id`)
    REFERENCES `ilabservice`.`iot_terminal` (`id`),
  CONSTRAINT `FK_event_monitoring_target_rule`
    FOREIGN KEY (`monitoring_target_measure_rule_id`)
    REFERENCES `ilabservice`.`monitoring_target_measure_rule` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3;


-- -----------------------------------------------------
-- Table `ilabservice`.`event_action`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`event_action` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`event_action` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `action_name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `description` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `is_enabled` TINYINT(1) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3;


-- -----------------------------------------------------
-- Table `ilabservice`.`event_type`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`event_type` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`event_type` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `description` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `name_UNIQUE` (`name` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`iot_terminal_monitoring_target_map`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`iot_terminal_monitoring_target_map` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`iot_terminal_monitoring_target_map` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `iot_terminal_id` INT(11) NOT NULL,
  `monitoring_target_id` INT(11) NOT NULL,
  `start_time` DATETIME NULL DEFAULT NULL,
  `end_time` DATETIME NULL DEFAULT NULL,
  `is_current` TINYINT(1) NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_iot_terminal_monitoring_target_map_iot_terminal` (`iot_terminal_id` ASC),
  INDEX `FK_iot_terminal_monitoring_target_map_monitoring_target` (`monitoring_target_id` ASC),
  CONSTRAINT `FK_iot_terminal_monitoring_target_map_iot_terminal`
    FOREIGN KEY (`iot_terminal_id`)
    REFERENCES `ilabservice`.`iot_terminal` (`id`),
  CONSTRAINT `FK_iot_terminal_monitoring_target_map_monitoring_target`
    FOREIGN KEY (`monitoring_target_id`)
    REFERENCES `ilabservice`.`monitoring_target` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 2;


-- -----------------------------------------------------
-- Table `ilabservice`.`lease_clause`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`lease_clause` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`lease_clause` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `content` VARCHAR(255) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`lease_record`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`lease_record` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`lease_record` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `monitoring_target_id` INT(11) NOT NULL,
  `lessor_id` INT(11) NOT NULL,
  `lessee_id` INT(11) NOT NULL,
  `price` DOUBLE NOT NULL,
  `begin_time` DATETIME NOT NULL,
  `end_time` DATETIME NOT NULL,
  `aggrement` VARCHAR(300) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `status` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_lease_record_monitoring_target` (`monitoring_target_id` ASC),
  INDEX `FK_lease_record_lessee` (`lessee_id` ASC),
  INDEX `FK_lease_record_lessor` (`lessor_id` ASC),
  CONSTRAINT `FK_lease_record_lessee`
    FOREIGN KEY (`lessee_id`)
    REFERENCES `ilabservice`.`user` (`id`),
  CONSTRAINT `FK_lease_record_lessor`
    FOREIGN KEY (`lessor_id`)
    REFERENCES `ilabservice`.`user` (`id`),
  CONSTRAINT `FK_lease_record_monitoring_target`
    FOREIGN KEY (`monitoring_target_id`)
    REFERENCES `ilabservice`.`monitoring_target` (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`role` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`role` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `description` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `role_type` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `create_datetime` DATETIME NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 8;


-- -----------------------------------------------------
-- Table `ilabservice`.`location_role_user_map`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`location_role_user_map` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`location_role_user_map` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `location_id` INT(11) NULL DEFAULT NULL,
  `user_id` INT(11) NULL DEFAULT NULL,
  `role_id` INT(11) NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_location_role_user_map_monitoring_target_type` (`location_id` ASC),
  INDEX `FK_location_role_user_map_role` (`role_id` ASC),
  INDEX `FK_location_role_user_map_user` (`user_id` ASC),
  CONSTRAINT `FK_location_role_user_map_location`
    FOREIGN KEY (`location_id`)
    REFERENCES `ilabservice`.`location` (`id`)
    ON UPDATE CASCADE
    ON DELETE CASCADE,
  CONSTRAINT `FK_location_role_user_map_role`
    FOREIGN KEY (`role_id`)
    REFERENCES `ilabservice`.`role` (`id`),
  CONSTRAINT `FK_location_role_user_map_user`
    FOREIGN KEY (`user_id`)
    REFERENCES `ilabservice`.`user` (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`monitoring_target_disable_sharing_strategy`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`monitoring_target_disable_sharing_strategy` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`monitoring_target_disable_sharing_strategy` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `monitoring_target_id` INT(11) NOT NULL,
  `strategy_type` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `content` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_monitoring_target_disable_sharing_strategy_monitoring_target` (`monitoring_target_id` ASC),
  CONSTRAINT `FK_monitoring_target_disable_sharing_strategy_monitoring_target`
    FOREIGN KEY (`monitoring_target_id`)
    REFERENCES `ilabservice`.`monitoring_target` (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`monitoring_target_group`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`monitoring_target_group` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`monitoring_target_group` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `group_name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `group_desc` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `is_dynamic` INT(11) NULL DEFAULT NULL,
  `dynamic_group_rule` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `parent_group_id` INT(11) NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`monitoring_target_group_static_map`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`monitoring_target_group_static_map` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`monitoring_target_group_static_map` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `group_id` INT(11) NULL DEFAULT NULL,
  `monitoring_target_id` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_monitoring_target_group_static_map_monitoring_target` (`monitoring_target_id` ASC),
  INDEX `FK_monitoring_target_group_static_map_monitoring_target_group` (`group_id` ASC),
  CONSTRAINT `FK_monitoring_target_group_static_map_monitoring_target`
    FOREIGN KEY (`monitoring_target_id`)
    REFERENCES `ilabservice`.`monitoring_target` (`id`),
  CONSTRAINT `FK_monitoring_target_group_static_map_monitoring_target_group`
    FOREIGN KEY (`group_id`)
    REFERENCES `ilabservice`.`monitoring_target_group` (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`monitoring_target_measure_type_map`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`monitoring_target_measure_type_map` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`monitoring_target_measure_type_map` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `monitoring_target_id` INT(11) NULL DEFAULT NULL,
  `measure_type_id` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_mtmt_map_monitoring_target_type_idx` (`monitoring_target_id` ASC),
  INDEX `FK_mtmt_map_measure_type_idx` (`measure_type_id` ASC),
  CONSTRAINT `FK_mtmt_map_measure_type_idx`
    FOREIGN KEY (`measure_type_id`)
    REFERENCES `ilabservice`.`measure_type` (`id`)
    ON UPDATE CASCADE,
  CONSTRAINT `FK_mtmt_map_monitoring_target_idx`
    FOREIGN KEY (`monitoring_target_id`)
    REFERENCES `ilabservice`.`monitoring_target` (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`monitoring_target_type_measure_rule`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`monitoring_target_type_measure_rule` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`monitoring_target_type_measure_rule` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `definition` VARCHAR(1024) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL COMMENT 'JSON string for the rules',
  `monitoring_target_type_id` INT(11) NOT NULL,
  `measure_type_id` INT(11) NULL DEFAULT NULL,
  `purpose` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_event_rule_measure_type_id` (`measure_type_id` ASC),
  INDEX `FK_event_rule_monitoring_target_type` (`monitoring_target_type_id` ASC),
  CONSTRAINT `FK_event_rule_measure_type_id`
    FOREIGN KEY (`measure_type_id`)
    REFERENCES `ilabservice`.`measure_type` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FK_event_rule_monitoring_target_type`
    FOREIGN KEY (`monitoring_target_type_id`)
    REFERENCES `ilabservice`.`monitoring_target_type` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 5;


-- -----------------------------------------------------
-- Table `ilabservice`.`monitoring_target_type_measure_type_map`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`monitoring_target_type_measure_type_map` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`monitoring_target_type_measure_type_map` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `monitoring_target_type_id` INT(11) NULL DEFAULT NULL,
  `measure_type_id` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_mtmt_map_monitoring_target_type_idx` (`monitoring_target_type_id` ASC),
  INDEX `FK_mtmt_map_measure_type_idx` (`measure_type_id` ASC),
  CONSTRAINT `FK_mttmt_map_measure_type`
    FOREIGN KEY (`measure_type_id`)
    REFERENCES `ilabservice`.`measure_type` (`id`)
    ON UPDATE CASCADE,
  CONSTRAINT `FK_mttmt_map_monitoring_target_type`
    FOREIGN KEY (`monitoring_target_type_id`)
    REFERENCES `ilabservice`.`monitoring_target_type` (`id`)
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`permission`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`permission` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`permission` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `permission_type` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `name` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `description` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 24;


-- -----------------------------------------------------
-- Table `ilabservice`.`pt100`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`pt100` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`pt100` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `temperature` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `resistance` DECIMAL(6,2) NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`resource_role_user_map`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`resource_role_user_map` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`resource_role_user_map` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `resource_type` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `resource_id` INT(11) NULL DEFAULT NULL,
  `role_id` INT(11) NULL DEFAULT NULL,
  `user_id` INT(11) NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_resource_role_user_map_monitoring_target` (`resource_id` ASC),
  INDEX `FK_resource_role_user_map_role` (`role_id` ASC),
  INDEX `FK_resource_role_user_map_user` (`user_id` ASC),
  CONSTRAINT `FK_resource_role_user_map_monitoring_target`
    FOREIGN KEY (`resource_id`)
    REFERENCES `ilabservice`.`monitoring_target` (`id`),
  CONSTRAINT `FK_resource_role_user_map_role`
    FOREIGN KEY (`role_id`)
    REFERENCES `ilabservice`.`role` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FK_resource_role_user_map_user`
    FOREIGN KEY (`user_id`)
    REFERENCES `ilabservice`.`user` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 3;


-- -----------------------------------------------------
-- Table `ilabservice`.`resource_type_role_user_map`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`resource_type_role_user_map` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`resource_type_role_user_map` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `resource_type_id` INT(11) NULL DEFAULT NULL,
  `user_id` INT(11) NULL DEFAULT NULL,
  `role_id` INT(11) NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_resource_type_role_user_map_monitoring_target_type` (`resource_type_id` ASC),
  INDEX `FK_resource_type_role_user_map_role` (`role_id` ASC),
  INDEX `FK_resource_type_role_user_map_user` (`user_id` ASC),
  CONSTRAINT `FK_resource_type_role_user_map_monitoring_target_type`
    FOREIGN KEY (`resource_type_id`)
    REFERENCES `ilabservice`.`monitoring_target_type` (`id`),
  CONSTRAINT `FK_resource_type_role_user_map_role`
    FOREIGN KEY (`role_id`)
    REFERENCES `ilabservice`.`role` (`id`),
  CONSTRAINT `FK_resource_type_role_user_map_user`
    FOREIGN KEY (`user_id`)
    REFERENCES `ilabservice`.`user` (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`role_permission_map`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`role_permission_map` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`role_permission_map` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `role_id` INT(11) NOT NULL,
  `permission_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_role_permssion_map_permission` (`permission_id` ASC),
  INDEX `FK_role_permssion_map_role` (`role_id` ASC),
  CONSTRAINT `FK_role_permssion_map_permission`
    FOREIGN KEY (`permission_id`)
    REFERENCES `ilabservice`.`permission` (`id`),
  CONSTRAINT `FK_role_permssion_map_role`
    FOREIGN KEY (`role_id`)
    REFERENCES `ilabservice`.`role` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 39;


-- -----------------------------------------------------
-- Table `ilabservice`.`running_status`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`running_status` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`running_status` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NULL DEFAULT NULL,
  `level` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`sensor`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`sensor` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`sensor` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `serial_no` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `device_id` INT(11) NOT NULL,
  `sample_frequency` INT(11) NULL DEFAULT NULL,
  `sample_time_unit` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `zero_drift` DECIMAL(8,6) NULL DEFAULT NULL,
  `calibration_frequency` VARCHAR(255) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NULL DEFAULT NULL,
  `last_calibration_date` DATE NULL DEFAULT NULL,
  `input_high` FLOAT(24,0) NULL DEFAULT NULL,
  `input_low` FLOAT(24,0) NULL DEFAULT NULL,
  `output_high` FLOAT(24,0) NULL DEFAULT NULL,
  `output_low` FLOAT(24,0) NULL DEFAULT NULL,
  `create_datetime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_sensor_iot_terminal` (`device_id` ASC),
  CONSTRAINT `FK_sensor_iot_terminal`
    FOREIGN KEY (`device_id`)
    REFERENCES `ilabservice`.`iot_terminal` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 5;


-- -----------------------------------------------------
-- Table `ilabservice`.`sensor_measure_type_map`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`sensor_measure_type_map` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`sensor_measure_type_map` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `sensor_id` INT(11) NULL DEFAULT NULL,
  `measure_type_id` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_sensor_measure_type_map_measure_type` (`measure_type_id` ASC),
  INDEX `FK_sensor_measure_type_map_sensor` (`sensor_id` ASC),
  CONSTRAINT `FK_sensor_measure_type_map_measure_type`
    FOREIGN KEY (`measure_type_id`)
    REFERENCES `ilabservice`.`measure_type` (`id`),
  CONSTRAINT `FK_sensor_measure_type_map_sensor`
    FOREIGN KEY (`sensor_id`)
    REFERENCES `ilabservice`.`sensor` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 5;


-- -----------------------------------------------------
-- Table `ilabservice`.`site_role_user_map`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`site_role_user_map` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`site_role_user_map` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `role_id` INT(11) NOT NULL,
  `user_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_site_role_map_user_role` (`role_id` ASC),
  INDEX `FK_site_role_map_user_user` (`user_id` ASC),
  CONSTRAINT `FK_site_role_map_user_role`
    FOREIGN KEY (`role_id`)
    REFERENCES `ilabservice`.`role` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FK_site_role_map_user_user`
    FOREIGN KEY (`user_id`)
    REFERENCES `ilabservice`.`user` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 4;


-- -----------------------------------------------------
-- Table `ilabservice`.`sysdiagrams`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`sysdiagrams` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`sysdiagrams` (
  `name` VARCHAR(160) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci' NOT NULL,
  `principal_id` INT(11) NOT NULL,
  `diagram_id` INT(11) NOT NULL AUTO_INCREMENT,
  `version` INT(11) NULL DEFAULT NULL,
  `definition` LONGBLOB NULL DEFAULT NULL,
  PRIMARY KEY (`diagram_id`),
  UNIQUE INDEX `UK_principal_name` (`principal_id` ASC, `name` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ilabservice`.`user_location_monitoring_target`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ilabservice`.`user_location_monitoring_target` ;

CREATE TABLE IF NOT EXISTS `ilabservice`.`user_location_monitoring_target` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `location_id` INT(11) NOT NULL,
  `target_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `user_id_and_location_id` (`user_id` ASC, `location_id` ASC),
  INDEX `FK_user_location_monitoring_target_location_id` (`location_id` ASC),
  INDEX `FK_user_location_monitoring_target_target_id` (`target_id` ASC),
  CONSTRAINT `FK_user_location_monitoring_target_location_id`
    FOREIGN KEY (`location_id`)
    REFERENCES `ilabservice`.`location` (`id`)
    ON UPDATE CASCADE
    ON DELETE CASCADE,
  CONSTRAINT `FK_user_location_monitoring_target_target_id`
    FOREIGN KEY (`target_id`)
    REFERENCES `ilabservice`.`monitoring_target` (`id`),
  CONSTRAINT `FK_user_location_monitoring_target_user_id`
    FOREIGN KEY (`user_id`)
    REFERENCES `ilabservice`.`user` (`id`))
ENGINE = InnoDB;

USE `ilabservice` ;

-- -----------------------------------------------------
-- View `ilabservice`.`view_user_site_role_permissions`
-- -----------------------------------------------------
DROP VIEW IF EXISTS `ilabservice`.`view_user_site_role_permissions` ;
USE `ilabservice`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ilabservice`.`view_user_site_role_permissions` AS select `u`.`id` AS `user_id`,`u`.`user_name` AS `login_name`,`u`.`name` AS `full_name`,`r`.`name` AS `role_name`,`r`.`role_type` AS `role_type`,`p`.`name` AS `permission_name` from ((((`ilabservice`.`user` `u` left join `ilabservice`.`site_role_user_map` `ru` on((`u`.`id` = `ru`.`user_id`))) left join `ilabservice`.`role` `r` on((`ru`.`role_id` = `r`.`id`))) left join `ilabservice`.`role_permission_map` `rp` on((`rp`.`role_id` = `r`.`id`))) left join `ilabservice`.`permission` `p` on((`rp`.`permission_id` = `p`.`id`))) order by `u`.`id`,`r`.`id`,`p`.`id`;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
