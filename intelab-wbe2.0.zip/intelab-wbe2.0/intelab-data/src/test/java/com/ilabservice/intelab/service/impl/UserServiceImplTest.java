package com.ilabservice.intelab.service.impl;

import com.ilabservice.intelab.Application;
import com.ilabservice.intelab.model.User;
import com.ilabservice.intelab.service.UserService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
* UserServiceImpl Tester.
*
* @author <Authors name>
* @since <pre>五月 19, 2018</pre>
* @version 1.0
*/
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {Application.class})
public class UserServiceImplTest {


    @Autowired
    UserService userService;


@Before
public void before() throws Exception {

}

@After
public void after() throws Exception {
}

/**
*
* Method: deleteById(Serializable id)
*
*/
@Test
public void testDeleteById() throws Exception {
//TODO: Test goes here...

}

/**
*
* Method: recover(Exception e, Serializable id)
*
*/
@Test
public void testRecoverForEId() throws Exception {
//TODO: Test goes here...
}

/**
*
* Method: getUserDetailInfo(Serializable id)
*
*/
@Test
public void testGetUserDetailInfo() throws Exception {
//TODO: Test goes here...
}

/**
*
* Method: updateById(User user)
*
*/
@Test
public void testUpdateById() throws Exception {
//TODO: Test goes here...
}

/**
*
* Method: recover(Exception e, User user)
*
*/
@Test
public void testRecoverForEUser() throws Exception {
//TODO: Test goes here...
}

/**
*
* Method: getUserIdAndPasswordByUserName(Serializable userName)
*
*/
@Test
public void testGetUserIdAndPasswordByUserName() throws Exception {
//TODO: Test goes here...
    User user = userService.getUserIdAndPasswordByUserName("hahahahahh");
    Assert.assertNotNull(user);
}

/**
*
* Method: addRoleToUser(Role role, User user)
*
*/
@Test
public void testAddRoleToUser() throws Exception {
//TODO: Test goes here...
}

/**
*
* Method: recover(Exception e, Role role, User user)
*
*/
@Test
public void testRecoverForERoleUser() throws Exception {
//TODO: Test goes here...
}

/**
*
* Method: deleteRoleFromUser(Role role, User user)
*
*/
@Test
public void testDeleteRoleFromUser() throws Exception {
//TODO: Test goes here...
}


}
